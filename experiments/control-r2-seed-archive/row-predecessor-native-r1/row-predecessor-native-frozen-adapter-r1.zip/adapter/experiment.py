"""Draft only by default; root admissions and terminal batch cleanup precede any extraction or native work."""
import argparse,datetime as dt,hashlib,importlib.util,json,math,os,re,shutil,subprocess,sys,zipfile
from pathlib import Path
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
LAB=BASE.parents[2]
PRIOR=LAB/'builds/shienryu-oldprofile-r2-seeds03-10-batch-r1'
PIN='7e987bb9ef0361356be22be13551e4626902f3a7'
VARIANT='73ca65c64ef89e037e3995ca1faa56e3f7b8a1480b1a2f20190fb3d17b41ef57'
TASK='CoreLab-Shienryu-RowPredecessor-Seed04-FullAndSTA-Q251-R1'
PRIOR_TASK='CoreLab-Shienryu-OldProfile-R2-Seeds03-10-Batch-Q251-R1'
PS='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
PYTHON=Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
QUARTUS=Path('C:/altera_lite/25.1std/quartus')
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
GIB=1024**3
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,tree_rss_bytes=9*GIB,
    admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)
MAP_NAMES=['db/STV_DS.db_info','db/STV_DS.map.cdb','db/STV_DS.map.hdb','db/STV_DS.map.rdb']
GENERATED=['build_id.v','jtag.cdf']
PRIMARY='db/STV_DS.cmp.cdb'
BINARIES=['output_files/STV_DS.rbf','output_files/STV_DS.sof']

def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,value):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def no_overlap():
    v=subprocess.check_output([PS,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not v or not json.loads(v),'Quartus active; no extraction/copy/launch'
def snapshot(tree):
    result={}
    for p in sorted(tree.rglob('*')):
        assert not p.is_symlink()
        if p.is_file():result[p.relative_to(tree).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p))
    return result
def safe_name(name):
    assert name and not Path(name).is_absolute() and '\\' not in name and all(x not in ('','.','..') for x in name.split('/'))
    return name
def check_snapshot(tree,index):assert snapshot(tree)==index,'Preserved checkpoint changed: '+str(tree)
def template_pins():
    pins=load(BASE/'template-pins.json')
    for n,h in pins.items():assert sha(BASE/safe_name(n))==h,'Draft file changed: '+n
    assert sha(BASE/'quartus_job_guard.py')==sha(LAB/'scripts/quartus_job_guard.py')==GUARD_SHA
    p=load(BASE/'provenance.json')
    for path,h in p['external_bound_files'].items():assert sha(path)==h,'Reference evidence changed: '+path
    for path,h in load(BASE/'tool-bindings.json').items():assert sha(path)==h,'Tool changed: '+path
    assert sha(BASE/'proposed/ascal.vhd')==VARIANT
    return pins
def completed_batch(a):
    proofs=a['prior_batch_terminal_evidence_sha256']
    assert set(proofs)=={'batch-result.json','terminal-task-cleanup.json','scheduler-action-exit.json'}
    for n,h in proofs.items():assert sha(PRIOR/n)==h
    r=load(PRIOR/'batch-result.json');c=load(PRIOR/'terminal-task-cleanup.json')
    assert r['exit_code']==0 and r['state'] in ('EXHAUSTED_SEEDS03_10_NO_CLEAN_CANDIDATE','STOPPED_FIRST_QUALIFIED_CLEAN_CANDIDATE_REQUIRES_ROOT_REVIEW')
    assert c['task_name']==PRIOR_TASK and c['exact_registered_action_verified'] and c['exact_task_unregistered']
    assert c['all_job_processes_terminal'] and c['all_handles_closed'] and c['last_task_result']==0
    assert c['errors']==[] and c['remaining_owned_or_quartus_processes']==[]
    assert load(PRIOR/'scheduler-action-exit.json')['exit_code']==0
def committed_source(a):
    path=Path(a['source_commit_receipt']['path']);digest=a['source_commit_receipt']['sha256']
    assert path.is_absolute() and re.fullmatch('[0-9a-f]{64}',digest) and sha(path)==digest
    r=load(path);assert r['reviewer']=='root' and r['decision']=='COMMITTED_ISOLATED_ROW_PREDECESSOR_SOURCE_VERIFIED'
    assert re.fullmatch('[0-9a-f]{40}',r['source_commit']) and r['source_commit']!=PIN and r['source_commit']==a['source_commit']
    assert r['base_commit']==PIN and r['source_branch'].startswith('lab/') and r['integration_after_batch_terminal'] is True
    assert r['worktree_clean'] is True and r['variant_exact_sha256']==VARIANT
    expected=load(BASE/'source-index.json');files=r['files'];assert len(files)==203 and set(files)==set(expected)
    for n,row in expected.items():
        allowed={row['sha256'],row['base_sha256']} if n=='STV_DS.qsf' else {row['sha256']}
        assert files[n]['sha256'] in allowed,'Committed source differs from proposed source: '+n
    return r
def admission(path,digest):
    assert Path(path).is_absolute() and re.fullmatch('[0-9a-f]{64}',digest or '') and sha(path)==digest
    a=load(path);assert a['reviewer']=='root' and a['decision']=='ACCEPTED_ROW_PREDECESSOR_SEED04_FULLFLOW_DRAFT'
    assert a['base_commit']==PIN and a['variant_exact_sha256']==VARIANT and a['seed']==4 and a['BUILD_DATE']=='261025'
    assert a['template_pins_sha256']==sha(BASE/'template-pins.json') and a['source_index_sha256']==sha(BASE/'source-index.json')
    assert a['limits']==LIMITS and a['further_variant_trial_authorized'] is True
    assert a['approve_exact_known_qsf_metadata_rewrite'] is True
    assert a['simulation_reset_and_shared_SIM_limits_reviewed'] is True
    assert a['timing_acceptance'] is False and a['hardware_acceptance'] is False
    completed_batch(a);committed_source(a);return a
def freeze(path,digest):
    template_pins();a=admission(path,digest);committed=committed_source(a);no_overlap()
    for n in ('stages','upstream-inputs.zip','input-manifest.json','frozen-pins.json','experiment-result.json'):
        assert not (BASE/n).exists(),'Occupied experiment: never overwrite or guess resume'
    p=load(BASE/'provenance.json');archive=Path(p['base_archive']);assert sha(archive)==p['base_archive_sha256']
    entries=load(p['base_archive_receipt'])['files'];expected=load(BASE/'source-index.json')
    assert len(entries)==len(expected)==203
    with archive.open('rb') as src,(BASE/'upstream-inputs.zip').open('xb') as dst:shutil.copyfileobj(src,dst)
    tree=BASE/'stages/full/tree';tree.mkdir(parents=True)
    with zipfile.ZipFile(BASE/'upstream-inputs.zip') as z:
        names=[x.filename for x in z.infolist() if not x.is_dir()]
        assert len(names)==len(set(names))==203 and set(names)==set(entries)
        for name in names:
            safe_name(name);raw=z.read(name);row=entries[name]
            assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
            assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob_sha1']
            if name=='sys/ascal.vhd':raw=(BASE/'proposed/ascal.vhd').read_bytes()
            if name=='STV_DS.qsf':raw=(BASE/'proposed/STV_DS.qsf').read_bytes()
            assert len(raw)==expected[name]['bytes'] and hashlib.sha256(raw).hexdigest()==expected[name]['sha256']
            dst=tree/name;assert dst.resolve().is_relative_to(tree.resolve());dst.parent.mkdir(parents=True,exist_ok=True)
            with dst.open('xb') as f:f.write(raw)
    assert set(snapshot(tree))==set(expected)
    checks=module(BASE/'checks.py','row_native_checks_freeze')
    reference=checks.reference(PRIOR/'seeds/seed-04/sta/reports');save(BASE/'coverage-reference.json',reference)
    m=dict(base_commit=PIN,source_commit=committed['source_commit'],source_branch=committed['source_branch'],
        source_commit_receipt=a['source_commit_receipt'],variant_exact_sha256=VARIANT,
        source_identity=committed['source_commit']+' with explicit QSFseed4 experimental setting',
        seed=4,BUILD_DATE='261025',limits=LIMITS,root_admission=str(Path(path).resolve()),root_admission_sha256=digest,
        template_pins_sha256=sha(BASE/'template-pins.json'),source_files=expected,tool_bindings=load(BASE/'tool-bindings.json'),
        source_archive_sha256=sha(BASE/'upstream-inputs.zip'),coverage_reference_sha256=sha(BASE/'coverage-reference.json'))
    save(BASE/'input-manifest.json',m)
    save(BASE/'frozen-pins.json',{**template_pins(),**{n:sha(BASE/n) for n in ('input-manifest.json','coverage-reference.json','upstream-inputs.zip')}})
    return dict(state='FROZEN_NO_TASK_OR_NATIVE_JOB',frozen_pins_sha256=sha(BASE/'frozen-pins.json'))
def validate():
    template_pins();pins=load(BASE/'frozen-pins.json')
    for n,h in pins.items():assert sha(BASE/n)==h
    m=load(BASE/'input-manifest.json');admission(m['root_admission'],m['root_admission_sha256'])
    assert m['base_commit']==PIN and m['variant_exact_sha256']==VARIANT and m['seed']==4 and m['BUILD_DATE']=='261025' and m['limits']==LIMITS
    return m
def frozen_review(path,digest):
    assert Path(path).is_absolute() and re.fullmatch('[0-9a-f]{64}',digest or '') and sha(path)==digest
    r=load(path);assert r['reviewer']=='root' and r['decision']=='ACCEPTED_FROZEN_ROW_PREDECESSOR_NATIVE_FOR_LAUNCH'
    assert r['task_name']==TASK and r['frozen_pins_sha256']==sha(BASE/'frozen-pins.json')
    assert r['source_commit']==load(BASE/'input-manifest.json')['source_commit']
def resources():
    g=module(BASE/'quartus_job_guard.py','row_native_resources');api=g.Windows();v=g.Performance(cb=g.C.sizeof(g.Performance))
    api.checked(api.p.GetPerformanceInfo(g.C.byref(v),v.cb),'GetPerformanceInfo')
    free=(v.limit-v.commit)*v.page;return dict(free_commit_bytes=free,admission_pass=free>=LIMITS['admission_free_commit_bytes'])
def terminal(stage):
    r=load(stage/'result.json')
    assert r['state']=='terminal' and r['flow_exit_code']==0 and r['launcher_success'] and r['errors']==[]
    assert r['all_job_processes_terminal'] and r['all_handles_closed'] and r['final_job_active_processes']==0
    return r
def guarded(stage,kind,names,m):
    no_overlap();tree=stage/'tree';g=module(BASE/'quartus_job_guard.py','row_native_'+kind)
    static={str(BASE/n):sha(BASE/n) for n in load(BASE/'frozen-pins.json')}
    static.update({p:sha(p) for p in m['tool_bindings']});static[m['root_admission']]=m['root_admission_sha256']
    static[m['source_commit_receipt']['path']]=m['source_commit_receipt']['sha256']
    provenance=load(BASE/'provenance.json');static.update(provenance['external_bound_files'])
    static[provenance['base_archive']]=provenance['base_archive_sha256']
    for n in ('frozen-pins.json','launch-admission.json','scheduler-action-start.json','registered-task.xml'):static[str(BASE/n)]=sha(BASE/n)
    launch=load(BASE/'launch-admission.json');static[launch['review_path']]=launch['review_sha256']
    if kind=='sta':
        tcl=stage/'sta_all_corners.tcl'
        with tcl.open('xb') as f:f.write((BASE/'sta_all_corners.tcl').read_bytes())
        static[str(tcl)]=sha(tcl)
    def inputs():return {**{n:sha(tree/n) for n in names},**{p:sha(p) for p in static}}
    before=inputs();exe=QUARTUS/'bin64'/('quartus_sh.exe' if kind=='full' else 'quartus_sta.exe')
    command=[str(exe),'--flow','compile','STV_DS','-c','STV_DS'] if kind=='full' else [str(exe),'-t',str(tcl)]
    g.LAB=LAB;g.BASE=stage;g.TREE=tree;g.BASELINE=m['source_commit'];g.QUARTUS=QUARTUS;g.EXE=exe
    g.COMMAND=command;g.RUN_KIND='row-predecessor-seed04-'+kind+'-no-wall';g.LIMITS=dict(LIMITS);g.inputs=inputs
    save(stage/'stage-manifest.json',dict(command=command,limits=LIMITS,bound_inputs=before,
        root_admission_sha256=m['root_admission_sha256'],generated_by='experiment-controller-not-manual-root-review'))
    assert g.run(before)==0,'Guard/native failure; do not advance'
    r=terminal(stage);no_overlap()
    assert all(sha(p)==h for p,h in static.items()),'Adapter/tool/admission changed'
    return r
def full_qualification(stage,m):
    tree=stage/'tree';r=terminal(stage);p=load(BASE/'provenance.json');source=m['source_files']
    changes={n:dict(before=row['sha256'],after=sha(tree/n)) for n,row in source.items() if sha(tree/n)!=row['sha256']}
    assert set(changes)<={'STV_DS.qsf'},'Protected source changed'
    qsf_sha=sha(tree/'STV_DS.qsf')
    assert qsf_sha in (p['qsf_precompile_sha256'],p['qsf_exact_known_compiler_metadata_after_sha256'])
    assert (tree/'build_id.v').read_bytes()==b'`define BUILD_DATE "261025"','Generated date differs from controlled seed4 date'
    qualifier=module(LAB/'builds/shienryu-oldprofile-r2-seed02-fit-r1/run_fit.py','row_native_fit_parser')
    report=tree/'output_files/STV_DS.fit.rpt';log=(stage/'fullflow.log').read_text(errors='replace')
    q=qualifier.fit_report_qualification(report.read_text(encoding='latin-1'),(tree/'output_files/STV_DS.fit.summary').read_text(encoding='latin-1'),log)
    for key in ('actual_seed_is2','fitter_only','child_reads_stored_settings_without_export','stored_seed2_readback','passed'):q.pop(key)
    modules=re.findall(r'Info: Running Quartus Prime ([^\r\n]+)',log)
    q['full_fresh_pipeline']=modules==['Shell','Shell','Analysis & Synthesis','Fitter','Assembler','Timing Analyzer']
    q['actual_seed_matches4']=q['actual_placement_seed']==4
    q['source_differences']=changes;q['generated_date_exact261025']=True
    started=dt.datetime.fromisoformat(r['started_utc']).timestamp()
    fresh=MAP_NAMES+[PRIMARY]+BINARIES+['output_files/STV_DS.map.rpt','output_files/STV_DS.fit.rpt','output_files/STV_DS.asm.rpt']
    q['new_map_fit_programming_outputs']=all((tree/n).stat().st_size>0 and (tree/n).stat().st_mtime>=started-2 for n in fresh)
    q['native_map_reads_stored_settings']=bool(re.search(r'Info: Command: quartus_map --read_settings_files=on --write_settings_files=off STV_DS -c STV_DS(?:\r?\n|$)',log))
    q['native_fit_uses_this_flow_map']=bool(re.search(r'Info: Command: quartus_fit --read_settings_files=off --write_settings_files=off STV_DS -c STV_DS(?:\r?\n|$)',log))
    q['passed']=all(q[k] for k in ('full_fresh_pipeline','actual_seed_matches4','no_post_fit_input','zero_requested_and_achieved_placement_and_routing','fitter_successful','new_map_fit_programming_outputs','native_map_reads_stored_settings','native_fit_uses_this_flow_map'))
    assert q['passed'],'Full synthesis/map/fit/ASM mechanism qualification failed'
    return q
def copy_checkpoint(parent,target,index):
    no_overlap();check_snapshot(parent,index);assert not target.exists()
    assert shutil.disk_usage(BASE).free>=sum(r['bytes'] for r in index.values())+2*GIB
    target.mkdir(parents=True)
    for n,row in index.items():
        dst=target/safe_name(n);dst.parent.mkdir(parents=True,exist_ok=True)
        with (parent/n).open('rb') as src,dst.open('xb') as out:shutil.copyfileobj(src,out)
        assert sha(dst)==row['sha256']
    check_snapshot(parent,index);check_snapshot(target,index)
def row_coverage(stage):
    c=module(BASE/'checks.py','row_native_target_rows');rows=c.rows(stage/'reports/row-predecessor-check-coverage.tsv')
    assert len(rows)==16 and {(int(r['corner']),r['check']) for r in rows}=={(i,k) for i in range(1,9) for k in ('setup','hold')}
    complete=True
    for r in rows:
        assert r['source_expression']=='ascal|o_vacpt_minus1*' and r['destination_expression']=='ascal|o_adrs_pre*'
        if r['returned_path_count']=='0':
            complete=False;assert r['worst_slack_ns']=='NA'
            assert r['classification'] in ('NO_MATCHING_KEEPERS_REQUIRES_REVIEW','NO_PATHS_REQUIRES_REVIEW');continue
        assert r['returned_path_count']=='1' and math.isfinite(float(r['worst_slack_ns']))
        assert r['classification']=='PATH_FOUND_REQUIRES_TIMING_REVIEW'
        assert int(r['source_count'])>0 and int(r['destination_count'])>0
        assert (stage/'reports'/r['report_file']).is_file()
    return dict(rows=rows,all16_target_paths_present=complete,no_empty_path_is_a_pass=True)
def run():
    m=validate();launch=load(BASE/'launch-admission.json');frozen_review(launch['review_path'],launch['review_sha256'])
    a=load(BASE/'scheduler-action-start.json');assert a['pid']==os.getppid() and a['parent_name'].lower() in ('svchost.exe','taskeng.exe')
    assert not (BASE/'experiment-result.json').exists()
    summary=dict(state='RUNNING',base_commit=PIN,source_commit=m['source_commit'],variant_exact_sha256=VARIANT,seed=4,BUILD_DATE='261025',
        root_admission_sha256=m['root_admission_sha256'],timing_acceptance=False,hardware_acceptance=False,task_cleanup_pending=True)
    code=1
    try:
        no_overlap();assert dt.date.today()==dt.date(2026,10,25),'Unchanged date-generating preflow requires261025; review a date-pinning method if delayed'
        full=BASE/'stages/full';tree=full/'tree';expected=m['source_files']
        assert snapshot(tree)=={n:dict(bytes=r['bytes'],sha256=r['sha256']) for n,r in expected.items()},'Require fresh source-only tree: no inherited map/fit/database/output'
        guarded(full,'full',list(expected),m);q=full_qualification(full,m);save(full/'qualification.json',q)
        checkpoint=snapshot(tree);save(full/'checkpoint.json',checkpoint)
        sta=BASE/'stages/sta';copy_checkpoint(tree,sta/'tree',checkpoint);(sta/'reports').mkdir()
        fit_caches=[n for n in checkpoint if n.startswith('db/STV_DS.tiscmp.') and n.endswith('.ddb')]
        assert fit_caches,'Fresh fitted timing caches missing'
        protected=list(expected)+GENERATED+MAP_NAMES+[PRIMARY]+BINARIES
        guarded(sta,'sta',protected+fit_caches,m)
        assert all(sha(sta/'tree'/n)==checkpoint[n]['sha256'] for n in protected),'STA changed source/date/map/primary fit/programming output'
        check_snapshot(tree,checkpoint)
        checks=module(BASE/'checks.py','row_native_timing');timing=checks.timing(sta,load(BASE/'coverage-reference.json'))
        target=row_coverage(sta);timing['qualified_clean_candidate']=timing['qualified_clean_candidate'] and target['all16_target_paths_present']
        save(sta/'qualification.json',dict(**timing,row_predecessor_coverage=target))
        summary.update(state='COMPLETED_MEASUREMENT_REQUIRES_ROOT_REVIEW',full_qualification=q,**timing,row_predecessor_coverage=target,
            RBF=dict(bytes=(tree/BINARIES[0]).stat().st_size,sha256=sha(tree/BINARIES[0])),SOF=dict(bytes=(tree/BINARIES[1]).stat().st_size,sha256=sha(tree/BINARIES[1])))
        code=0
    except Exception as error:summary.update(state='STOPPED_INFRASTRUCTURE_OR_INTEGRITY_REQUIRES_ROOT_REVIEW',error=repr(error))
    finally:
        try:
            no_overlap()
            for result in (BASE/'stages').glob('*/result.json'):
                r=load(result);assert r['state']=='terminal' and r['all_job_processes_terminal'] and r['all_handles_closed'] and r['final_job_active_processes']==0
            save(BASE/'preservation-index.json',dict(members=snapshot(BASE/'stages'),root_admission_sha256=m['root_admission_sha256'],
                source_identity=m['source_identity'],tool_bindings=m['tool_bindings'],limits=LIMITS,
                restore='Exact programming binaries/full map+fitted checkpoint retained; identical rebuild unproven',manual_root_review=False))
            summary['preservation_index_sha256']=sha(BASE/'preservation-index.json')
        except Exception as error:summary['preservation_pending_safe_terminal_proof']=repr(error);code=1
        summary.update(exit_code=code,ended_utc=dt.datetime.now(dt.timezone.utc).isoformat());save(BASE/'experiment-result.json',summary)
    return code
def main():
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group();g.add_argument('--freeze');g.add_argument('--run',action='store_true');p.add_argument('--admission-sha256');a=p.parse_args()
    assert Path(sys.executable).resolve()==PYTHON.resolve()
    if a.freeze:print(json.dumps(freeze(a.freeze,a.admission_sha256),indent=2));return 0
    if a.run:return run()
    template_pins();print(json.dumps(dict(state='DRAFT_ONLY_NO_EXTRACTION_FREEZE_DB_TASK_OR_NATIVE_JOB',seed=4,variant_exact_sha256=VARIANT,
        BUILD_DATE='261025',limits=LIMITS,template_pins_sha256=sha(BASE/'template-pins.json'))));return 0
if __name__=='__main__':raise SystemExit(main())
