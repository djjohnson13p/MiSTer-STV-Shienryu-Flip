"""One fixed old-profile seed2 fitter-only job. Default plans only until root freezes a terminal copy."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
TREE=BASE/'tree'
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
TCL_SHA='6c3fd4b498c7ef89cd80304ed2692aee4a1dfc450da5215d975e6fd47b0b2bec'
PIN='7e987bb9ef0361356be22be13551e4626902f3a7'
POWERSHELL='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
GIB=1024**3
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,
    tree_rss_bytes=9*GIB,admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def names(tree):return {p.relative_to(tree).as_posix() for p in tree.rglob('*') if p.is_file()}

def no_overlap():
    text=subprocess.check_output([POWERSHELL,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not text or not json.loads(text),'Quartus overlap; no seed2 fit admitted'

def validate():
    no_overlap()
    pins=json.loads((BASE/'frozen-pins.json').read_text())
    for name,digest in pins.items():assert sha(BASE/name)==digest,'Frozen seed2 input changed: '+name
    m=json.loads((BASE/'fit-manifest.json').read_text());original=Path(m['fitted_directory'])
    assert m['source_commit']==PIN and m['seed']==2 and m['project']==m['revision']=='STV_DS'
    assert m['limits']==LIMITS and sha(BASE/'quartus_job_guard.py')==m['guard_sha256']==GUARD_SHA
    assert sha(BASE/'fit_only.tcl')==m['fit_tcl_sha256']==TCL_SHA
    for key in ('fit_review','source_review','seed_review','seed1_allcorner_review','seed_plan'):assert sha(m[key+'_path'])==m[key+'_sha256']
    for name,digest in m['fitted_evidence_sha256'].items():assert sha(original/name)==digest,'Original fullfit evidence changed: '+name
    for name,digest in m['seed1_sta_evidence_sha256'].items():assert sha(Path(m['seed1_sta_directory'])/name)==digest,'Seed1 all-corner evidence changed: '+name
    for path,digest in m['tool_bindings'].items():assert sha(path)==digest
    copied=json.loads((BASE/'copied-files.json').read_text());start=json.loads((BASE/'seed-start-files.json').read_text())
    assert sha(BASE/'copied-files.json')==m['copied_manifest_sha256'] and len(copied)==m['copied_file_count']
    assert sha(BASE/'seed-start-files.json')==m['seed_start_manifest_sha256'] and set(start)==set(copied)
    delta={name:dict(before_sha256=row['sha256'],after_sha256=start[name]['sha256']) for name,row in copied.items() if start[name]['sha256']!=row['sha256']}
    assert set(delta)=={'STV_DS.qsf'} and delta==m['intentional_seed_delta']
    assert names(original/'tree')==set(copied) and names(TREE)==set(start)
    for name,row in copied.items():
        assert sha(original/'tree'/name)==row['sha256'],'Original fullfit file changed: '+name
        assert sha(TREE/name)==start[name]['sha256'],'Seed-start file changed: '+name
    qsf=(TREE/'STV_DS.qsf').read_bytes();assert len(re.findall(rb'^set_global_assignment -name SEED 2\r?$',qsf,re.M))==1
    for key in ('action_source','registration_source'):assert sha(BASE/m['scheduler'][key])==m['scheduler'][key+'_sha256']
    return m,pins

def validate_pristine(m):
    assert names(TREE)==set(json.loads((BASE/'seed-start-files.json').read_text()))

def read_resources():
    # Read-only native memory sample; never creates a Job, task or compiler process.
    spec = importlib.util.spec_from_file_location('shienryu_resource_probe_guard', BASE / 'quartus_job_guard.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    api = module.Windows()
    value = module.Performance(cb=module.C.sizeof(module.Performance))
    api.checked(api.p.GetPerformanceInfo(module.C.byref(value), value.cb), 'GetPerformanceInfo')
    free = (value.limit - value.commit) * value.page
    threshold = 12 * 1024**3
    return dict(observed_utc=module.stamp(), free_commit_bytes=free, admission_free_commit_bytes=threshold,
        admission_pass=free >= threshold, committed_bytes=value.commit*value.page,
        commit_limit_bytes=value.limit*value.page, physical_available_bytes=value.available*value.page,
        physical_total_bytes=value.physical*value.page, no_job_or_task_created=True)




def fit_report_qualification(report,summary,log):
    cells=lambda line:[x.strip() for x in line.strip().strip(';').split(';')]
    seeds=[cells(line)[1] for line in report.splitlines() if line.lstrip().startswith('; Fitter Initial Placement Seed')]
    assert len(seeds)==1,'Actual fitter seed row missing/ambiguous'
    part=report.split('; Incremental Compilation Partition Settings',1)[1].split('; Incremental Compilation Placement Preservation',1)[0]
    lines=[cells(line) for line in part.splitlines() if line.lstrip().startswith(';')]
    header=next(row for row in lines if 'Netlist Type Used' in row);index=header.index('Netlist Type Used')
    types=[row[index] for row in lines if len(row)==len(header) and row!=header]
    assert types,'Actual partition netlist types missing'
    section=report.split('; Incremental Compilation Preservation Summary',1)[1].split('; Incremental Compilation Partition Settings',1)[0]
    preserve=[cells(line) for line in section.splitlines() if line.lstrip().startswith(';') and ('-- Requested' in line or '-- Achieved' in line)]
    assert len(preserve)==4,'Placement/routing requested+achieved rows missing/ambiguous'
    counts=[re.findall(r'([0-9.]+)\s*%\s*\(\s*([0-9,]+)\s*/',line) for row in preserve for line in row[1:]]
    assert counts and all(len(row)==1 for row in counts),'Preservation percentages/numerators not fully parsed'
    zero=all(float(row[0][0])==0.0 and int(row[0][1].replace(',',''))==0 for row in counts)
    modules=re.findall(r'Info: Running Quartus Prime ([^\r\n]+)',log)
    command=bool(re.search(r'Info: Command: quartus_fit --read_settings_files=on --write_settings_files=off STV_DS -c STV_DS(?:\r?\n|$)',log))
    q=dict(actual_placement_seed=int(seeds[0]),actual_seed_is2=int(seeds[0])==2,
        actual_partition_netlist_types=types,no_post_fit_input=all('postfit' not in re.sub(r'[-_ ]','',value.lower()) for value in types),
        preservation_summary_rows=preserve,zero_requested_and_achieved_placement_and_routing=zero,
        native_modules=modules,fitter_only=(modules.count('Fitter')==1 and all(value in ('Shell','Fitter') for value in modules)),
        child_reads_stored_settings_without_export=command,
        stored_seed2_readback='SHIENRYU_SEED02_STORED_SEED_READBACK=2' in log,
        fitter_successful='Fitter Status : Successful' in summary and 'Timing Models : Final' in summary)
    q['passed']=all(q[key] for key in ('actual_seed_is2','no_post_fit_input','zero_requested_and_achieved_placement_and_routing','fitter_only','child_reads_stored_settings_without_export','stored_seed2_readback','fitter_successful'))
    return q

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
    if not (BASE/'frozen-pins.json').exists():
        assert not args.run,'Root-accepted complete seed2 copy not prepared'
        print(json.dumps(dict(state='template-only-no-live-tree-read-no-task-no-fit',seed=2)));return 0
    m,pins=validate();original=Path(m['fitted_directory']);copied=json.loads((BASE/'copied-files.json').read_text());start=json.loads((BASE/'seed-start-files.json').read_text())
    spec=importlib.util.spec_from_file_location('shienryu_control_r2_seed02_fit_guard',BASE/'quartus_job_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
    bound_names=sorted(set(m['source_names']+m['generated_names']+m['map_database_names']))
    def inputs():return {name:sha(TREE/name) for name in bound_names}
    assert inputs()=={name:start[name]['sha256'] for name in bound_names},'Guard inputs must match seed-start hashes'
    guard.LAB=BASE.parents[1];guard.BASE=BASE;guard.TREE=TREE;guard.BASELINE=PIN
    guard.QUARTUS=Path('C:/altera_lite/25.1std/quartus');guard.EXE=guard.QUARTUS/'bin64/quartus_sh.exe'
    guard.COMMAND=[str(guard.EXE),'-t',str(BASE/'fit_only.tcl')];guard.LIMITS=dict(LIMITS);guard.inputs=inputs
    guard.RUN_KIND='shienryu-oldprofile-r2-seed02-fitter-only-native-qualification-no-wall'
    assert guard.COMMAND==m['command'] and guard.LIMITS==m['limits']
    plan=dict(state='prepared-dry-run-no-native-job',source_commit=PIN,seed=2,command=guard.COMMAND,cwd=str(TREE),limits=LIMITS,
        bound_source_generated_map_inputs=len(bound_names),frozen_pins_sha256=sha(BASE/'frozen-pins.json'),scheduler=m['scheduler'],
        inherited_RBF_STA_not_seed02_results=True,prior_fit_caches_present=True,timing_acceptance=False)
    if not args.run:print(json.dumps(plan,indent=2));return 0
    validate_pristine(m)
    for name in ('prelaunch.json','fullflow.log','live.json','result.json','preservation-readback.json'):assert not (BASE/name).exists(),'Previous attempt exists: '+name
    action=json.loads((BASE/'scheduler-action-start.json').read_text(encoding='utf-8-sig'))
    assert action['pid']==os.getppid() and action['parent_name'].lower() in ('svchost.exe','taskeng.exe')
    no_overlap();plan['scheduler_action_start']=action;guard.save(BASE/'prelaunch.json',plan);code=guard.run(inputs())
    original_names=names(original/'tree');working=names(TREE)
    original_changed=[name for name,row in copied.items() if name not in original_names or sha(original/'tree'/name)!=row['sha256']]
    original_added=sorted(original_names-set(copied))
    raw_changes={name:dict(before=row['sha256'],after=sha(TREE/name) if name in working else None) for name,row in copied.items() if name not in working or sha(TREE/name)!=row['sha256']}
    seed_changes={name:dict(before=row['sha256'],after=sha(TREE/name) if name in working else None) for name,row in start.items() if name not in working or sha(TREE/name)!=row['sha256']}
    protected={name:row for name,row in seed_changes.items() if name in bound_names}
    expected=m['intentional_seed_delta']['STV_DS.qsf'];seed_delta_ok=raw_changes.get('STV_DS.qsf')==dict(before=expected['before_sha256'],after=expected['after_sha256'])
    qualification={};qualification_error=None
    try:
        rpt=TREE/'output_files/STV_DS.fit.rpt';summary=TREE/'output_files/STV_DS.fit.summary'
        qualification=fit_report_qualification(rpt.read_text(encoding='latin-1'),summary.read_text(encoding='latin-1'),(BASE/'fullflow.log').read_text(encoding='utf-8',errors='replace'))
        qualification['fit_report_sha256']=sha(rpt);qualification['fit_summary_sha256']=sha(summary)
        qualification['fit_report_changed_from_inherited_seed1']=sha(rpt)!=copied['output_files/STV_DS.fit.rpt']['sha256']
        qualification['passed']=qualification['passed'] and qualification['fit_report_changed_from_inherited_seed1']
    except Exception as error:qualification_error=str(error)
    readback=dict(original_fitted_files_changed=original_changed,original_fitted_files_added=original_added,
        raw_local_changes_against_original=raw_changes,seed_start_working_changes=seed_changes,
        local_files_added={name:sha(TREE/name) for name in sorted(working-set(copied))},
        protected_source_generated_map_changes=protected,intentional_seed_delta=m['intentional_seed_delta'],intentional_seed_delta_matches=seed_delta_ok,
        generated_hashes={name:sha(TREE/name) for name in m['generated_names'] if name in working},
        build_id_sha256=sha(TREE/'build_id.v') if 'build_id.v' in working else None,
        native_fit_qualification=qualification,native_fit_qualification_error=qualification_error,
        inherited_RBF_STA_not_seed02_results=True,prior_fit_caches_present=True,
        qualification_failure_is_not_timing_failure=True,fitter_exit_is_not_timing_acceptance=True,timing_acceptance=False)
    readback['adapter_success']=code==0 and not original_changed and not original_added and not protected and seed_delta_ok and not qualification_error and qualification.get('passed',False)
    guard.save(BASE/'preservation-readback.json',readback)
    return 0 if readback['adapter_success'] else 1

if __name__=='__main__':raise SystemExit(main())
