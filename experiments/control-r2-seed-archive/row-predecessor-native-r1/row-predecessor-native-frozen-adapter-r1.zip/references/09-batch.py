"""Fixed 7e9 seeds3..10 only. Default is template-only; never reads a fitted tree."""
import argparse
import csv
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
LAB=BASE.parents[1]
PIN='7e987bb9ef0361356be22be13551e4626902f3a7'
TASK='CoreLab-Shienryu-OldProfile-R2-Seeds03-10-Batch-Q251-R1'
PYTHON=Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
PS='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
QUARTUS=Path('C:/altera_lite/25.1std/quartus')
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
SOURCE_REVIEW_SHA='735286ac878d801091284690091dbd6cbd12ad92d2ebe4c473234129048d06f3'
SEED1=BASE.parent/'shienryu-oldprofile-q251-candidate-r2'
FIT2=BASE.parent/'shienryu-oldprofile-r2-seed02-fit-r1'
ASM2=BASE.parent/'shienryu-oldprofile-r2-seed02-asm-r1'
STA2=BASE.parent/'shienryu-oldprofile-r2-seed02-sta-all-corners-r1'
SEED1_FILES_SHA='7bd644fb86eca6ee83f995e94b9d014a369d89a1e173fb5f755e2d353c57c901'
GIB=1024**3
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,
    tree_rss_bytes=9*GIB,admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)
FILES=('batch.py','checks.py','launch_task.py','quartus_job_guard.py','fit_only.tcl','asm_only.tcl',
    'sta_all_corners.tcl','scheduler-action-inline.ps1','register-start-inline.ps1','PLAN.md','reuse-provenance.json','reuse-adapter.diff')

def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def load(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')

def stamp():return dt.datetime.now(dt.timezone.utc).isoformat()

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def no_overlap():
    value=subprocess.check_output([PS,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not value or not json.loads(value),'Quartus active: no parent-tree access/copy or next stage'

def snapshot(tree):
    result={}
    for p in sorted(tree.rglob('*')):
        assert not p.is_symlink(),'Symlink forbidden'
        if p.is_file():result[p.relative_to(tree).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p))
    return result

def check_snapshot(tree,expected):assert snapshot(tree)==expected,'Immutable checkpoint changed: '+str(tree)

def safe_name(name):
    assert isinstance(name,str) and name and not Path(name).is_absolute() and '\\' not in name
    assert all(part not in ('','.','..') for part in name.split('/'));return name

def copy_checkpoint(parent,target,expected):
    no_overlap();check_snapshot(parent,expected)
    assert not target.exists(),'Never replay/overwrite a seed or stage'
    assert shutil.disk_usage(BASE).free>=sum(x['bytes'] for x in expected.values())+2*GIB,'Copy disk headroom below2GiB'
    target.mkdir(parents=True)
    for name,row in expected.items():
        safe_name(name);dst=target/name;dst.parent.mkdir(parents=True,exist_ok=True)
        with (parent/name).open('rb') as a,dst.open('xb') as b:shutil.copyfileobj(a,b)
        assert sha(dst)==row['sha256']
    check_snapshot(parent,expected);check_snapshot(target,expected)

def template_pins():
    pins=load(BASE/'template-pins.json');assert set(pins)==set(FILES)
    for name,digest in pins.items():assert sha(BASE/name)==digest,'Template changed: '+name
    assert sha(BASE/'quartus_job_guard.py')==sha(LAB/'scripts/quartus_job_guard.py')==GUARD_SHA
    proof=load(BASE/'reuse-provenance.json')
    for path,digest in proof['reused_external_files'].items():assert sha(path)==digest,'Reference helper changed'
    return pins

def terminal(directory):
    r=load(directory/'result.json')
    assert r['state']=='terminal' and r['flow_exit_code']==0 and r['launcher_success'] and r['errors']==[]
    assert r['all_job_processes_terminal'] and r['all_handles_closed'] and r['final_job_active_processes']==0
    return r

def cleaned(directory):
    r=load(directory/'terminal-task-cleanup.json')
    assert r['exact_task_unregistered'] and r['all_job_processes_terminal'] and r['all_handles_closed']
    assert r['errors']==[] and r['remaining_owned_or_quartus_processes']==[] and r['last_task_result']==0

def admission(path,digest):
    assert re.fullmatch('[0-9a-f]{64}',digest or '') and sha(path)==digest
    a=load(path)
    assert a['reviewer']=='root' and a['decision']=='ACCEPTED_FIXED_7E9_SEEDS03_10_BATCH'
    assert a['source_commit']==PIN and a['seeds']==list(range(3,11)) and a['limits']==LIMITS
    assert a['template_pins_sha256']==sha(BASE/'template-pins.json') and a['seed2_mechanism_qualified'] is True
    assert a['seed2_all_eight_conditions_reviewed'] is True and a['further_seed_needed'] is True
    assert a['timing_acceptance'] is False and a['hardware_acceptance'] is False
    expected={'fit':FIT2,'asm':ASM2,'sta':STA2}
    for kind,directory in expected.items():
        evidence=a['seed2_evidence'][kind]
        assert Path(evidence['directory']).resolve()==directory.resolve()
        required={'result.json','preservation-readback.json','terminal-task-cleanup.json','scheduler-action-exit.json'}
        required|={'frozen-pins.json',{'fit':'fit-manifest.json','asm':'asm-manifest.json','sta':'sta-manifest.json'}[kind]}
        if kind=='fit':required|={'copied-files.json','seed-start-files.json'}
        else:required|={'copied-parent-files.json'}
        assert required<=set(evidence['files'])
        for name,h in evidence['files'].items():assert sha(directory/safe_name(name))==h
        terminal(directory);cleaned(directory)
        assert load(directory/'scheduler-action-exit.json')['exit_code']==0
    fq=load(FIT2/'preservation-readback.json');aq=load(ASM2/'preservation-readback.json');sq=load(STA2/'preservation-readback.json')
    assert fq['adapter_success'] and fq['native_fit_qualification']['passed'] and fq['native_fit_qualification']['actual_placement_seed']==2
    assert aq['adapter_success'] and aq['assembly_qualification']['passed']
    assert not sq['original_fitted_files_changed'] and not sq['original_fitted_files_added']
    assert sq['protected_source_generated_map_primary_cmp_changes']=={} and sq['coverage_error'] is None
    for key in ('required_eight_conditions_complete','complete_dynamic_row_counts','constraints_and_mpw_reports_present',
                'old_mode_complete_dynamic_rows','old_mode_diagnostic_reports_complete','fixed_profile_mode_paths_present'):
        assert sq['coverage'][key] is True
    bound_reports={name for name in a['seed2_evidence']['sta']['files'] if name.startswith('reports/')}
    assert bound_reports=={'reports/'+p.name for p in (STA2/'reports').iterdir() if p.is_file()},'Root must bind every actual seed2 report'
    return a

def freeze(path,digest):
    no_overlap();pins=template_pins();a=admission(path,digest)
    assert not any((BASE/n).exists() for n in ('batch-manifest.json','frozen-pins.json','seeds','batch-result.json'))
    source=load(FIT2/'fit-manifest.json');assert source['source_commit']==PIN and source['source_review_sha256']==SOURCE_REVIEW_SHA
    assert Path(source['fitted_directory']).resolve()==SEED1.resolve() and sha(source['source_review_path'])==SOURCE_REVIEW_SHA
    assert sha(FIT2/'copied-files.json')==SEED1_FILES_SHA
    original=load(FIT2/'copied-files.json');assert len(original)==1051
    no_overlap();check_snapshot(SEED1/'tree',original)
    roles={k:source[k] for k in ('source_names','generated_names','map_database_names','fit_database_names','primary_cmp_names')}
    assert all(roles.values()) and all(len(v)==len(set(v)) for v in roles.values())
    for names in roles.values():
        for name in names:assert safe_name(name) in original
    assert sha(PYTHON)==a['tool_bindings'][str(PYTHON)]
    for exe in ('quartus_sh.exe','quartus_fit.exe','quartus_asm.exe','quartus_sta.exe'):
        p=QUARTUS/'bin64'/exe;assert sha(p)==a['tool_bindings'][str(p)]
    checks=module(BASE/'checks.py','batch_checks_freeze')
    reference=checks.reference(STA2/'reports')
    save(BASE/'seed1-files.json',original);save(BASE/'coverage-reference.json',reference)
    manifest=dict(batch=TASK,source_commit=PIN,seeds=list(range(3,11)),limits=LIMITS,root_admission=str(Path(path).resolve()),
        root_admission_sha256=digest,template_pins_sha256=sha(BASE/'template-pins.json'),roles=roles,
        seed1_files_sha256=sha(BASE/'seed1-files.json'),coverage_reference_sha256=sha(BASE/'coverage-reference.json'),
        tool_bindings=a['tool_bindings'],source_review_path=source['source_review_path'],source_review_sha256=SOURCE_REVIEW_SHA,
        prior_fit_caches_present=True,generated_audits_are_not_manual_root_reviews=True)
    save(BASE/'batch-manifest.json',manifest)
    save(BASE/'frozen-pins.json',{**pins,**{n:sha(BASE/n) for n in ('batch-manifest.json','seed1-files.json','coverage-reference.json')}})
    return dict(state='frozen-no-tree-copy-task-or-native-job',frozen_pins_sha256=sha(BASE/'frozen-pins.json'),root_frozen_review_still_required=True)

def validate():
    template_pins();pins=load(BASE/'frozen-pins.json')
    for name,h in pins.items():assert sha(BASE/name)==h
    m=load(BASE/'batch-manifest.json');assert m['source_commit']==PIN and m['seeds']==list(range(3,11)) and m['limits']==LIMITS
    admission(m['root_admission'],m['root_admission_sha256'])
    for p,h in m['tool_bindings'].items():assert sha(p)==h
    assert sha(m['source_review_path'])==SOURCE_REVIEW_SHA
    return m

def frozen_review(path,digest):
    assert re.fullmatch('[0-9a-f]{64}',digest or '') and sha(path)==digest
    r=load(path);assert r['reviewer']=='root' and r['decision']=='ACCEPTED_FROZEN_FIXED_7E9_BATCH_FOR_LAUNCH'
    assert r['batch']==TASK and r['source_commit']==PIN and r['frozen_pins_sha256']==sha(BASE/'frozen-pins.json')
    return r

def resources():
    g=module(BASE/'quartus_job_guard.py','batch_resource_guard');api=g.Windows();v=g.Performance(cb=g.C.sizeof(g.Performance))
    api.checked(api.p.GetPerformanceInfo(g.C.byref(v),v.cb),'GetPerformanceInfo')
    free=(v.limit-v.commit)*v.page;return dict(free_commit_bytes=free,admission_pass=free>=LIMITS['admission_free_commit_bytes'])

def guarded(stage,kind,seed,roles):
    no_overlap();tree=stage/'tree';keys=('source_names','generated_names','map_database_names')
    if kind=='asm':keys+=('primary_cmp_names',)
    if kind=='sta':keys+=('fit_database_names',)
    bound=sorted(set().union(*(set(roles[k]) for k in keys)))
    def inputs():return {name:sha(tree/name) for name in bound}
    before=inputs();g=module(BASE/'quartus_job_guard.py',f'batch_{seed}_{kind}_guard')
    exe='quartus_sta.exe' if kind=='sta' else 'quartus_sh.exe';tcl='sta_all_corners.tcl' if kind=='sta' else kind+'_only.tcl'
    # Keep proven native -t invocation unchanged; render the stored-seed literal locally.
    # STA writes beside its own script and is always byte-identical.
    tcl_path=stage/tcl;raw_tcl=(BASE/tcl).read_bytes()
    if kind!='sta':
        assert raw_tcl.count(b'@SEED@')==2
        raw_tcl=raw_tcl.replace(b'@SEED@',str(seed).encode('ascii'))
    with tcl_path.open('xb') as f:f.write(raw_tcl)
    assert tcl_path.read_bytes()==raw_tcl
    command=[str(QUARTUS/'bin64'/exe),'-t',str(tcl_path)]
    g.LAB=LAB;g.BASE=stage;g.TREE=tree;g.BASELINE=PIN;g.QUARTUS=QUARTUS;g.EXE=QUARTUS/'bin64'/exe
    g.COMMAND=command;g.RUN_KIND=f'fixed7e9-batch-seed{seed:02d}-{kind}-no-wall';g.LIMITS=dict(LIMITS);g.inputs=inputs
    save(stage/'stage-manifest.json',dict(batch=TASK,seed=seed,stage=kind,command=command,limits=LIMITS,bound_inputs=before,
        tcl_sha256=sha(tcl_path),root_admission_sha256=load(BASE/'batch-manifest.json')['root_admission_sha256'],generated_by='batch-controller-not-manual-root-review'))
    assert g.run(before)==0,'Guard/native stage failed; do not advance'
    result=terminal(stage);no_overlap()
    after_inputs=inputs();changes={name for name in before if after_inputs[name]!=before[name]}
    allowed=set(roles['fit_database_names'])-set(roles['primary_cmp_names']) if kind=='sta' else set()
    assert changes<=allowed,'Native changed protected source/generated/map/date/primary CMP'
    return result

def preserve_seed(folder,seed,m,complete):
    index=folder/'preservation-index.json';assert not index.exists()
    save(index,dict(batch=TASK,seed=seed,source_commit=PIN,members=snapshot(folder),completed_native_sequence=complete,
        root_admission_sha256=m['root_admission_sha256'],tool_bindings=m['tool_bindings'],limits=LIMITS,
        restore='Exact emitted binary/full fit checkpoint is preserved; identical future rebuild is unproven',
        index_excludes_itself=True,no_overwrite_or_delete=True,manual_root_review=False))
    return sha(index)

def run():
    m=validate();launch=load(BASE/'launch-admission.json');frozen_review(launch['review_path'],launch['review_sha256'])
    action=load(BASE/'scheduler-action-start.json');assert action['pid']==os.getppid() and action['parent_name'].lower() in ('svchost.exe','taskeng.exe')
    assert not (BASE/'seeds').exists() and not (BASE/'batch-result.json').exists(),'No automatic retries or resumption'
    no_overlap();original=load(BASE/'seed1-files.json');check_snapshot(SEED1/'tree',original)
    checks=module(BASE/'checks.py','batch_checks_run');qualifier=module(FIT2/'run_fit.py','proven_seed02_fit_qualifier')
    summary=dict(batch=TASK,source_commit=PIN,root_admission=m['root_admission'],root_admission_sha256=m['root_admission_sha256'],
        frozen_review_sha256=launch['review_sha256'],started_utc=stamp(),seeds=[],state='running',hardware_acceptance=False,
        timing_acceptance=False,generated_by='batch-controller-not-manual-root-review',task_cleanup_pending=True)
    code=1
    try:
        for seed in range(3,11):
            folder=BASE/'seeds'/f'seed-{seed:02d}';fit=folder/'fit';asm=folder/'asm';sta=folder/'sta'
            assert not folder.exists(),'Occupied seed output: never delete, overwrite or guess a resume'
            copy_checkpoint(SEED1/'tree',fit/'tree',original)
            qsf=fit/'tree/STV_DS.qsf';raw=qsf.read_bytes();needle=b'set_global_assignment -name SEED 1'
            assert len(re.findall(rb'^set_global_assignment -name SEED 1\r?$',raw,re.M))==1 and raw.count(needle)==1
            changed=raw.replace(needle,b'set_global_assignment -name SEED '+str(seed).encode(),1);qsf.write_bytes(changed)
            start=snapshot(fit/'tree');assert set(start)==set(original)
            assert {n for n in original if start[n]!=original[n]}=={'STV_DS.qsf'}
            save(fit/'seed-start-files.json',start);guarded(fit,'fit',seed,m['roles']);fit_end=snapshot(fit/'tree')
            protected=set().union(*(set(m['roles'][k]) for k in ('source_names','generated_names','map_database_names')))
            assert all(fit_end[n]==start[n] for n in protected),'Fit changed source/generated/map/date'
            fq=checks.fit(fit,seed,qualifier);assert fq['passed'],'Native fitter mechanism failed'
            check_snapshot(SEED1/'tree',original);save(fit/'checkpoint.json',fit_end)
            save(fit/'qualification.json',dict(batch=TASK,seed=seed,qualification=fq,root_admission_sha256=m['root_admission_sha256'],manual_root_review=False))
            copy_checkpoint(fit/'tree',asm/'tree',fit_end);pre=checks.output_stats(asm/'tree')
            ar=guarded(asm,'asm',seed,m['roles']);asm_end=snapshot(asm/'tree')
            immutable=protected|set(m['roles']['primary_cmp_names']);assert all(asm_end[n]==fit_end[n] for n in immutable)
            aq=checks.assembly(asm,seed,ar,pre,fit_end);assert aq['passed'],'Fresh assembler-only qualification failed'
            check_snapshot(fit/'tree',fit_end);save(asm/'checkpoint.json',asm_end);save(asm/'qualification.json',dict(batch=TASK,seed=seed,qualification=aq,manual_root_review=False))
            copy_checkpoint(asm/'tree',sta/'tree',asm_end);(sta/'reports').mkdir();guarded(sta,'sta',seed,m['roles'])
            after=snapshot(sta/'tree');assert all(after[n]==asm_end[n] for n in immutable),'STA changed source/generated/map/primary CMP'
            check_snapshot(fit/'tree',fit_end);check_snapshot(asm/'tree',asm_end);check_snapshot(SEED1/'tree',original)
            sq=checks.timing(sta,load(BASE/'coverage-reference.json'));save(sta/'qualification.json',dict(batch=TASK,seed=seed,
                root_admission_sha256=m['root_admission_sha256'],manual_root_review=False,**sq))
            index_sha=preserve_seed(folder,seed,m,True)
            summary['seeds'].append(dict(seed=seed,fit_qualified=True,asm_qualified=True,**sq,
                RBF=aq['outputs']['output_files/STV_DS.rbf'],SOF=aq['outputs']['output_files/STV_DS.sof'],
                preservation_index_sha256=index_sha,fit_checkpoint_sha256=sha(fit/'checkpoint.json')))
            # Earlier seeds are never source parents, and remain exact while later seeds run.
            for previous in summary['seeds']:
                old=BASE/'seeds'/f"seed-{previous['seed']:02d}";index=old/'preservation-index.json'
                assert sha(index)==previous['preservation_index_sha256']
                observed=snapshot(old);observed.pop('preservation-index.json')
                assert observed==load(index)['members'],'Preserved earlier seed changed'
            if sq['qualified_clean_candidate']:
                summary.update(state='STOPPED_FIRST_QUALIFIED_CLEAN_CANDIDATE_REQUIRES_ROOT_REVIEW',selected_seed=seed);code=0;break
        else:summary['state']='EXHAUSTED_SEEDS03_10_NO_CLEAN_CANDIDATE';code=0
    except Exception as error:
        summary.update(state='STOPPED_INFRASTRUCTURE_OR_INTEGRITY_FAILURE',error=repr(error));code=1
        if 'folder' in locals() and folder.exists():
            summary['partial_seed_directory']=str(folder)
            try:
                no_overlap()
                for result in folder.glob('*/result.json'):
                    proof=load(result)
                    if proof.get('state')=='deferred-before-launch' and proof.get('no_child_launched') is True:continue
                    assert proof['state']=='terminal' and proof['all_job_processes_terminal'] and proof['all_handles_closed'] and proof['final_job_active_processes']==0
                if not (folder/'preservation-index.json').exists():summary['partial_seed_preservation_index_sha256']=preserve_seed(folder,seed,m,False)
            except Exception as preservation_error:
                summary['partial_seed_index_pending_safe_terminal_proof']=repr(preservation_error)
    finally:
        summary.update(ended_utc=stamp(),exit_code=code,task_cleanup_pending=True)
        save(BASE/'batch-result.json',summary)
    return code

def main():
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group();g.add_argument('--freeze');g.add_argument('--run',action='store_true')
    p.add_argument('--admission-sha256');a=p.parse_args();assert Path(sys.executable).resolve()==PYTHON.resolve()
    if a.freeze:print(json.dumps(freeze(a.freeze,a.admission_sha256),indent=2));return 0
    if a.run:return run()
    pins=template_pins();print(json.dumps(dict(state='UNFROZEN_TEMPLATE_ONLY_NO_PARENT_DB_READ_COPY_TASK_OR_NATIVE_JOB',source_commit=PIN,seeds=list(range(3,11)),
        limits=LIMITS,template_pins_sha256=sha(BASE/'template-pins.json'),files=len(pins),frozen_manifest_present=(BASE/'frozen-pins.json').exists()),indent=2));return 0

if __name__=='__main__':raise SystemExit(main())
