"""Template plan by default. --freeze extracts the exact accepted canonical old-profile source archive; never launches a task or compiler."""
import argparse
import datetime as dt
import hashlib
import json
import re
import shutil
from pathlib import Path
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
LAB = BASE.parents[1]
PIN = '7e987bb9ef0361356be22be13551e4626902f3a7'
SOURCE_IDENTITY = '7e987bb9ef0361356be22be13551e4626902f3a7'
ARCHIVE = LAB / 'research/shienryu-timing-20261024/oldprofile-control-r2-source-7e987bb-canonical.zip'
ARCHIVE_SHA = '4747ff94e65a56e8e44c3f4c8b9fbcb5d1ea415523abb55dab3d8747742d605b'
ARCHIVE_RECEIPT = LAB / 'research/shienryu-timing-20261024/OLDPROFILE-CONTROL-R2-SOURCE-ARCHIVE.json'
ARCHIVE_RECEIPT_SHA = '0a37cb8fc3903588076221caea06254e15935e9604b9ca19a2eb184749b74bbe'
SOURCE_REVIEW = LAB / 'research/shienryu-timing-20261024/ROOT-OLDPROFILE-CONTROL-R2-SOURCE-REVIEW.json'
SOURCE_REVIEW_SHA = '735286ac878d801091284690091dbd6cbd12ad92d2ebe4c473234129048d06f3'
R1_STA = LAB / 'builds/shienryu-oldprofile-sta-all-corners-r1'
R1_PIN = 'b75f7c175dad7fcc9c685ba776f6aa673e2a4d6e'
R1_ROOT_RESULT_SHA = 'e95d09c9c103d717d735c9b04713b3ea586d911fd524ce87f743b251ecafd931'
POWERSHELL = 'C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
GUARD_SHA = '5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
PYTHON = Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
QUARTUS = Path('C:/altera_lite/25.1std/quartus')
GIB = 1024 ** 3
LIMITS = dict(wall_seconds=None, cleanup_reserve_seconds=20, job_private_bytes=10*GIB,
              tree_rss_bytes=9*GIB, admission_free_commit_bytes=12*GIB,
              continuous_free_commit_floor_bytes=2*GIB)
COMMAND = [str(QUARTUS / 'bin64/quartus_sh.exe'), '--flow', 'compile', 'STV_DS', '-c', 'STV_DS']
SCRIPTS = ('prepare.py', 'run_flow.py', 'launch_task.py', 'quartus_job_guard.py',
           'scheduler-action-inline.ps1', 'register-start-inline.ps1', 'PLAN.md', 'template-reuse-provenance.json')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def no_overlap():
    reply = subprocess.check_output([POWERSHELL, '-NoProfile', '-NonInteractive', '-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"], text=True).strip()
    assert not reply or not json.loads(reply), 'Quartus overlap; no archive extraction or native job'


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freeze', action='store_true')
    parser.add_argument('--source-review')
    parser.add_argument('--source-review-sha256')
    args = parser.parse_args()
    assert Path(sys.executable).resolve() == PYTHON.resolve(), 'Use pinned Python'
    assert sha(LAB / 'scripts/quartus_job_guard.py') == sha(BASE / 'quartus_job_guard.py') == GUARD_SHA
    tools = [PYTHON] + [QUARTUS / 'bin64' / (name + '.exe')
        for name in ('quartus_sh', 'quartus_map', 'quartus_fit', 'quartus_sta', 'quartus_asm')]
    tool_bindings = {str(path): sha(path) for path in tools}
    plan = dict(state='template-only-no-source-archive-read-no-extraction-no-freeze-no-task-no-compile',
        source_commit=PIN, source_code_identity=SOURCE_IDENTITY, source_archive=str(ARCHIVE), source_archive_sha256=ARCHIVE_SHA,
        source_archive_receipt=str(ARCHIVE_RECEIPT), source_archive_receipt_sha256=ARCHIVE_RECEIPT_SHA,
        project='STV_DS', revision='STV_DS', command=COMMAND, limits=LIMITS,
        guard_sha256=GUARD_SHA, tool_bindings=tool_bindings, tracked_source_files=203,
        excluded_top_paths=['install', 'packages', 'releases'],
        freeze_requires='Root source/base-decision acceptance, b75 R1 all-corner STA terminal/cleanup/root timing-result acceptance, then no Quartus overlap before archive extraction',
        scope='One synchronized/frame-held old Shienryu HDMI control-R2 fullflow; only ascal differs from b75; seed1/effort2/clocks/SDC/QSF unchanged; no sweep here',
        timing_acceptance=False, mode_paths_fully_timed=True)
    if not args.freeze:
        print(json.dumps(plan, indent=2))
        return 0
    assert re.fullmatch('[0-9a-f]{64}', args.source_review_sha256 or ''), 'Root source/base-decision review SHA256 required'
    review_path = Path(args.source_review or '').resolve()
    assert review_path == SOURCE_REVIEW.resolve() and args.source_review_sha256 == SOURCE_REVIEW_SHA
    assert review_path.is_file() and sha(review_path) == args.source_review_sha256
    review = json.loads(review_path.read_text(encoding='utf-8-sig'))
    assert review['reviewer'] == 'root' and review['decision'] == 'ACCEPTED_OLD_GAME_HDMI_CONTROL_R2_FOR_COMPILE'
    assert review['base_decision'] == 'MEASURE_SYNCHRONIZED_FRAME_FLIP_PROFILE_NEXT'
    assert review['source_commit'] == PIN and review['source_code_identity'] == SOURCE_IDENTITY and review['source_archive_sha256'] == ARCHIVE_SHA
    references = review['reference_evidence_sha256']
    required = {'research/shienryu-timing-20261024/OLDPROFILE-CONTROL-R2-SOURCE-ARCHIVE.json',
        'research/shienryu-timing-20261024/ROOT-OLD-FLIP-CONTROL-REVIEW-R1.json',
        'research/shienryu-timing-20261024/OLD-FLIP-CONTROL-SIMULATION-REVIEW-R1.json',
        'research/shienryu-timing-20261024/PRESERVATION-REVALIDATED.json',
        'research/shienryu-preservation-20261024/inventory.json',
        'builds/shienryu-oldprofile-sta-all-corners-r1/result.json',
        'builds/shienryu-oldprofile-sta-all-corners-r1/terminal-task-cleanup.json',
        'builds/shienryu-oldprofile-sta-all-corners-r1/ROOT-TIMING-RESULT.json'}
    assert required <= set(references)
    for name, digest in references.items():
        assert not Path(name).is_absolute() and (LAB / name).resolve().is_relative_to(LAB.resolve())
        assert re.fullmatch('[0-9a-f]{64}', digest) and sha(LAB / name) == digest, 'Bound evidence changed: ' + name
    terminal = json.loads((R1_STA / 'result.json').read_text(encoding='utf-8-sig'))
    cleanup = json.loads((R1_STA / 'terminal-task-cleanup.json').read_text(encoding='utf-8-sig'))
    assert terminal['state'] == 'terminal' and terminal['baseline_commit'] == R1_PIN and terminal['flow_exit_code'] == 0
    assert terminal['all_job_processes_terminal'] and terminal['all_handles_closed'] and not terminal['errors']
    assert terminal['final_job_active_processes'] == 0 and terminal['held_processes_all_signaled'] and terminal['root_signaled']
    assert cleanup['task_name'] == 'CoreLab-Shienryu-OldProfile-STA-AllCorners-Q251-R1'
    assert cleanup['exact_task_unregistered'] and cleanup['all_job_processes_terminal'] and cleanup['all_handles_closed']
    assert not cleanup['errors'] and not cleanup['remaining_owned_or_quartus_processes']
    assert cleanup['last_task_result'] == 0 and cleanup['native_flow_exit_code'] == 0
    assert sha(R1_STA / 'ROOT-TIMING-RESULT.json') == R1_ROOT_RESULT_SHA
    prior_review = json.loads((R1_STA / 'ROOT-TIMING-RESULT.json').read_text(encoding='utf-8-sig'))
    assert prior_review['reviewer'] == 'root' and prior_review['decision'] == 'ACCEPTED_EXPERIMENTAL_OLD_PROFILE_R1_TIMING_IMPROVEMENT_NOT_CLEAN_CLOSURE'
    assert prior_review['source_commit'] == R1_PIN and prior_review['native_exit_code'] == 0
    assert prior_review['all_job_processes_terminal'] and prior_review['all_handles_closed'] and prior_review['exact_task_removed']
    assert prior_review['timing_acceptance'] is False and prior_review['hardware_acceptance'] is False
    for name in ('result.json','terminal-task-cleanup.json','frozen-pins.json'):
        assert sha(R1_STA / name) == prior_review['evidence_sha256'][name]

    assert sha(ARCHIVE_RECEIPT) == ARCHIVE_RECEIPT_SHA and sha(ARCHIVE) == ARCHIVE_SHA
    receipt = json.loads(ARCHIVE_RECEIPT.read_text(encoding='utf-8-sig'))
    assert receipt['reviewer'] == 'root' and receipt['commit'] == PIN and receipt['source_code_identity'] == SOURCE_IDENTITY
    assert receipt['archive_sha256'] == ARCHIVE_SHA and receipt['file_count'] == len(receipt['files']) == 203
    assert set(receipt['excluded_binary_distribution_directories']) == {'install', 'packages', 'releases'}
    assert receipt['decision'] == 'EXACT_COMMITTED_OLD_PROFILE_CONTROL_R2_SOURCE_ARCHIVE_VERIFIED'
    assert receipt['every_other_parent_file_byte_identical'] and receipt['alias_byte_identical_to_q17']
    assert receipt['base_commit'] == 'b75f7c175dad7fcc9c685ba776f6aa673e2a4d6e' and receipt['approved_changed_paths'] == ['sys/ascal.vhd']
    entries = receipt['files']
    assert 'STV_DS.qsf' in entries and 'STV_DS.qpf' in entries and 'sys/pll_q25.qip' in entries
    no_overlap()
    for name in ('tree', 'upstream-inputs.zip', 'input-manifest.json', 'frozen-pins.json'):
        assert not (BASE / name).exists(), 'Preserve existing preparation: ' + name
    archive = BASE / 'upstream-inputs.zip'
    with ARCHIVE.open('rb') as original, archive.open('xb') as destination:
        shutil.copyfileobj(original, destination)
    assert sha(archive) == sha(ARCHIVE) == ARCHIVE_SHA
    tree = BASE / 'tree'
    tree.mkdir()
    baseline = {}
    with zipfile.ZipFile(archive) as source:
        archive_files = [entry.filename for entry in source.infolist() if not entry.is_dir()]
        assert len(archive_files) == len(set(archive_files)) == 203 and set(archive_files) == set(entries)
        for entry in source.infolist():
            destination = tree / entry.filename
            assert destination.resolve().is_relative_to(tree.resolve())
            if entry.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            content = source.read(entry)
            blob = hashlib.sha1(b'blob ' + str(len(content)).encode('ascii') + b'\0' + content).hexdigest()
            assert blob == entries[entry.filename]['git_blob_sha1'], 'Preserved Git blob mismatch: ' + entry.filename
            assert len(content) == entries[entry.filename]['bytes'] and hashlib.sha256(content).hexdigest() == entries[entry.filename]['sha256']
            baseline[entry.filename] = dict(entries[entry.filename])
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(content)
    q17, q25 = tree / 'sys/pll_q17.qip', tree / 'sys/pll_q25.qip'
    assert q25.read_bytes() == q17.read_bytes(), 'Committed Q25 alias must match Q17 bytes'
    assert sha(tree / 'sys/sys_top.sdc') == 'ca42b002f0b2bd7e201a1363c2a16078945a5ebe63112425fedd750e89af3a62'
    files = {path.relative_to(tree).as_posix(): dict(bytes=path.stat().st_size, sha256=sha(path))
             for path in sorted(tree.rglob('*')) if path.is_file()}
    assert set(files) == set(baseline)
    assert all(files[name]['sha256'] == row['sha256'] for name, row in baseline.items())
    manifest = dict(state='frozen-not-launched', prepared_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        source_commit=PIN, source_code_identity=SOURCE_IDENTITY, base_commit=receipt['base_commit'], source_archive_sha256=sha(archive),
        preserved_archive_path=str(ARCHIVE), preserved_archive_receipt_path=str(ARCHIVE_RECEIPT), preserved_archive_receipt_sha256=ARCHIVE_RECEIPT_SHA,
        source_review_path=str(review_path), source_review_sha256=sha(review_path), reference_evidence_sha256=references,
        excluded_top_paths=['install', 'packages', 'releases'], archive_method='Exact copy of accepted canonical committed old-profile ZIP; no checkout, branch or alias addition',
        baseline_files=baseline, source_files=files,
        approved_changed_paths=receipt['approved_changed_paths'],
        committed_compile_compatibility_alias=dict(path='sys/pll_q25.qip', byte_identical_to='sys/pll_q17.qip', sha256=sha(q25)),
        tool_bindings=tool_bindings, guard_sha256=GUARD_SHA, limits=LIMITS,
        project='STV_DS', revision='STV_DS', command=COMMAND,
        scheduler=dict(task_name='CoreLab-Shienryu-OldProfile-Candidate-FullFlow-Q251-R2',
            user='DESKTOP-8SVI9NM\\djjohnson13p', logon_type='Interactive', run_level='Limited',
            execution_time_limit='PT0S', triggers=[], retries=0, hidden=True),
        generated_files=['build_id.v', 'jtag.cdf', 'STV_DS_assignment_defaults.qdf'],
        generated_build_id_policy='Absent before launch; unchanged preflow generates date macro/CDF; validate/hash after flow, then preserve matching generated date and synthesis for later fitter-only seeds without rerunning preflow',
        checkout_validation_policy='No checkout consulted. Every extracted file must match preserved receipt bytes/SHA256/Gitblob; no newline normalization.',
        source_and_timing_policy='Exact committed203-file control-R2 archive; only sys/ascal.vhd differs from b75; other202 files including QSF/SDC/PLL and committed Q25 alias remain byte-identical. Seed1/effort2 unchanged. Simulation is qualified, not universal custom-geometry or hardware acceptance. No sweep implemented.',
        expected_metadata_change='Any observed Quartus QSF version/newline rewrite requires precise separate root audit. Raw hashes/changed-input flags/adapter/scheduler exits remain honest; no exception is preaccepted.',
        timing_acceptance=False, all_corner_sta_still_required=True, mode_paths_fully_timed=True)
    save(BASE / 'input-manifest.json', manifest)
    pins = {name: sha(BASE / name) for name in (*SCRIPTS, 'input-manifest.json', 'upstream-inputs.zip')}
    save(BASE / 'frozen-pins.json', pins)
    print(json.dumps(dict(state='frozen-not-launched', files=len(files), baseline_files=len(baseline),
        frozen_pins_sha256=sha(BASE / 'frozen-pins.json'), task_registered=False, native_job_started=False), indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
