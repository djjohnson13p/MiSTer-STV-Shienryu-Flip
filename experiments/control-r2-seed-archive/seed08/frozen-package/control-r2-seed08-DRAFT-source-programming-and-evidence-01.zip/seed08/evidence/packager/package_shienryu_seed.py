"""Local DRAFT preservation of sealed fixed-7e9 seeds6-10; default is plan-only.

--create requires the closed native sequence, exact frozen inputs, external root
measurement and peer review. It never runs project code, Git, Quartus or devices,
updates a seed index, grants acceptance, uploads, or overwrites an output.
An output without its final PACKAGE-INDEX.json is incomplete and must not publish.
"""
import argparse
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

WORKSPACE = Path(__file__).resolve().parents[2]
RESEARCH = WORKSPACE / "core-lab/research/shienryu-timing-20261024"
BATCH = WORKSPACE / "core-lab/builds/shienryu-oldprofile-r2-seeds03-10-batch-r1"
SOURCE = "7e987bb9ef0361356be22be13551e4626902f3a7"
GUARD = "5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9"
ADMISSION = "1ace5a9df39a60e021d93b75a15ba5ce5dd26a01a085b610b8ca408bb9cd54b2"
PINS = "7467aeda38a61890456fc8894d4d7d7a7febe9f4d63a3bee661cb7b3e640e0e4"
LIMITS = dict(wall_seconds=None, cleanup_reserve_seconds=20,
              job_private_bytes=10 * 1024**3, tree_rss_bytes=9 * 1024**3,
              admission_free_commit_bytes=12 * 1024**3,
              continuous_free_commit_floor_bytes=2 * 1024**3)
ZIP_LIMIT, RAW_PART_BUDGET = 100_000_000, 85_000_000
STAGES = ("fit", "asm", "sta")
CHECKS = ("setup", "hold", "recovery", "removal")
STATIC = {
    BATCH / "frozen-pins.json": PINS,
    BATCH / "ROOT-BATCH-ADMISSION.json": ADMISSION,
    BATCH / "ROOT-FROZEN-ADAPTER-REVIEW.json":
        "3b301d951613f9594b5957b3fc407893f58b0c1ea74763f9f7b0d2e82d6181e1",
    RESEARCH / "oldprofile-control-r2-source-7e987bb-canonical.zip":
        "4747ff94e65a56e8e44c3f4c8b9fbcb5d1ea415523abb55dab3d8747742d605b",
    RESEARCH / "ROOT-OLDPROFILE-CONTROL-R2-SOURCE-REVIEW.json":
        "735286ac878d801091284690091dbd6cbd12ad92d2ebe4c473234129048d06f3",
    RESEARCH / "control-r2-seed-preservation/TOOL-PROVENANCE.json":
        "0f04612d38386e93192d69a58c1f3993d17ca89864fb3dbcbee7893a0ed62bcd",
    RESEARCH / "frozen-batch-adapter-preservation/"
    "shienryu-control-r2-seeds03-10-frozen-adapter-DRAFT.zip":
        "9d0776d5bbad8cfdc2546a47653f234893540897579b21fb541936804b4c4b5e",
}
SECRET = re.compile(
    rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|"
    rb"\bghp_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{30,}|"
    rb"\bxox[baprs]-[A-Za-z0-9-]{20,}")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def info(path):
    return dict(bytes=path.stat().st_size, sha256=sha(path))


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def digest(value):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def relative(name):
    p = PurePosixPath(name)
    require(bool(name) and not p.is_absolute() and ".." not in p.parts
            and "\\" not in name and ":" not in name, "Unsafe relative path: " + name)
    return p


def no_link(path):
    st = path.lstat()
    require(not path.is_symlink() and not getattr(st, "st_file_attributes", 0) & 0x400,
            "Symlink/reparse point refused: " + str(path))


def snapshot(folder):
    no_link(folder)
    result = {}
    for root, dirs, files in os.walk(folder, followlinks=False):
        for name in sorted(dirs + files):
            path = Path(root) / name
            no_link(path)
            if path.is_file():
                rel = path.relative_to(folder).as_posix()
                relative(rel)
                result[rel] = info(path)
    return dict(sorted(result.items()))


def matrix_check(matrix):
    expected = {(m, t) for m in ("slow", "fast") for t in (-40, 0, 85, 100)}
    require(len(matrix) == 8 and {(r["model"], r["temperature_C"]) for r in matrix}
            == expected, "All eight actual conditions required")
    for row in matrix:
        require(set(row["checks"]) == set(CHECKS), "Missing timing check")
        for check in row["checks"].values():
            v = check["slack_ns"]
            require(isinstance(v, (int, float)) and not isinstance(v, bool)
                    and math.isfinite(v) and check["pass"] == (v >= 0),
                    "NA/nonfinite/inconsistent timing slack is not a pass")
        pw = row["minimum_pulse_width"]
        require(isinstance(pw["slack_ns"], (int, float))
                and math.isfinite(pw["slack_ns"]) and pw["reported_paths"] > 0
                and isinstance(pw["violated"], int) and pw["violated"] >= 0,
                "Applicable global MPW evidence required")


def stage_check(seed, stage, roles, manifest, result):
    require(manifest["seed"] == seed and manifest["stage"] == stage,
            "Wrong stage/seed manifest")
    require(manifest["root_admission_sha256"] == ADMISSION
            and manifest["limits"] == result["limits"] == LIMITS, "Guard policy changed")
    require(result["flow_exit_code"] == 0 and result["all_job_processes_terminal"]
            and result["all_handles_closed"] and not result["errors"],
            "Native stage not terminal/closed/zero: " + stage)
    require(result["launcher_sha256"] == GUARD
            and result["baseline_commit"] == SOURCE
            and result["command"] == manifest["command"], "Wrong guard/source/command")
    keys = ["source_names", "generated_names", "map_database_names"]
    keys += ["primary_cmp_names"] if stage == "asm" else (
        ["fit_database_names"] if stage == "sta" else [])
    bound = set().union(*(set(roles[k]) for k in keys))
    before, after = result["input_hashes_before"], result["input_hashes_after"]
    require(manifest["bound_inputs"] == before and set(before) == set(after) == bound,
            "Bound input inventory changed")
    changes = {n: dict(before=before[n], after=after[n])
               for n in before if before[n] != after[n]}
    allowed = {"db/STV_DS.tiscmp.fastest_slow_1100mv_85c.ddb"} if stage == "sta" else set()
    require(changes == result["changed_bound_inputs"] and set(changes) <= allowed,
            "Protected input mutation: " + stage)
    for n in bound:
        relative(n)


def metadata(seed):
    """Metadata gates only: this function never reads a stage tree."""
    folder = BATCH / f"seeds/seed-{seed:02}"
    seal_path = folder / "preservation-index.json"
    require(seal_path.is_file(), "Unsealed seed: do not read active tree")
    no_link(folder.parent)
    no_link(folder)
    seal = read(seal_path)
    require(seal["seed"] == seed and seal["source_commit"] == SOURCE
            and seal["completed_native_sequence"], "Wrong/incomplete sealed sequence")
    for n in seal["members"]:
        relative(n)
    for path, expected in STATIC.items():
        require(sha(path) == expected, "Fixed artifact changed: " + str(path))
    bindings = dict(STATIC)
    for n, expected in read(BATCH / "frozen-pins.json").items():
        relative(n)
        require(sha(BATCH / n) == expected, "Frozen batch input changed: " + n)
        bindings[BATCH / n] = expected
    bm = read(BATCH / "batch-manifest.json")
    roles = bm["roles"]
    results, qualifications = {}, {}
    for stage in STAGES:
        result = read(folder / stage / "result.json")
        stage_check(seed, stage, roles, read(folder / stage / "stage-manifest.json"), result)
        results[stage] = result
        qualifications[stage] = read(folder / stage / "qualification.json")
        tcl_name = "sta_all_corners.tcl" if stage == "sta" else stage + "_only.tcl"
        tcl = (BATCH / tcl_name).read_bytes()
        if stage != "sta":
            require(tcl.count(b"@SEED@") == 2, "Unexpected seed Tcl template")
            tcl = tcl.replace(b"@SEED@", str(seed).encode())
        require((folder / stage / tcl_name).read_bytes() == tcl
                and sha(folder / stage / tcl_name)
                == read(folder / stage / "stage-manifest.json")["tcl_sha256"],
                "Native Tcl differs from frozen template")
    fit, asm = (qualifications[k]["qualification"] for k in ("fit", "asm"))
    require(fit["passed"] and fit["actual_placement_seed"] == seed
            and fit["no_post_fit_input"] and fit["zero_requested_and_achieved_placement_and_routing"],
            "Native fitter qualification missing")
    require(asm["passed"] and asm["fresh_RBF_and_SOF"]
            and asm["assembler_successful"], "Fresh standalone assembler qualification missing")
    matrix = qualifications["sta"]["timing_condition_matrix"]
    matrix_check(matrix)
    root_path = RESEARCH / f"ROOT-SEED{seed:02}-TIMING-RESULT.json"
    peer_path = RESEARCH / f"OLDPROFILE-R2-SEED{seed:02}-ALL-CORNER-REPORT-REVIEW.json"
    root = read(root_path)
    require(root["reviewer"] == "root" and root["seed"] == seed
            and root["source_commit"] == SOURCE and root["seal_sha256"] == sha(seal_path)
            and root["matrix"] == matrix and root["root_admission_sha256"] == ADMISSION,
            "External root measurement does not bind this sealed seed")
    require(sha(peer_path) == root["constraint_agent_review_sha256"],
            "Independent all-corner review absent/changed")
    require(root["programming_outputs"] == asm["outputs"],
            "Root/native programming output bindings differ")
    bindings.update({root_path: sha(root_path), peer_path: sha(peer_path),
                     seal_path: sha(seal_path), Path(__file__): sha(Path(__file__))})
    return dict(seed=seed, folder=folder, seal=seal, seal_path=seal_path, roles=roles,
                results=results, qualifications=qualifications, matrix=matrix,
                root=root, root_path=root_path, peer_path=peer_path, metadata_bindings=bindings)


def expected_qsf(raw, seed):
    old = b"set_global_assignment -name SEED 1\n"
    version = b"25.1std.0 Standard Edition"
    require(b"\r" not in raw and raw.count(old) == raw.count(version) == 1,
            "Unexpected canonical QSF/newlines")
    return raw.replace(version, b"25.1std.0 Lite Edition").replace(
        old, f"set_global_assignment -name SEED {seed}\n".encode()).replace(b"\n", b"\r\n")


def tree_maps(members):
    return {stage: {n[len(stage + "/tree/"):]: v for n, v in members.items()
                    if n.startswith(stage + "/tree/")} for stage in STAGES}


def preflight(seed):
    ctx = metadata(seed)  # All three Jobs must close before the first tree read.
    actual = snapshot(ctx["folder"])
    actual.pop("preservation-index.json")
    require(actual == ctx["seal"]["members"], "Sealed bytes/membership changed")
    trees = tree_maps(actual)
    require(trees["fit"] == read(ctx["folder"] / "fit/checkpoint.json")
            and trees["asm"] == read(ctx["folder"] / "asm/checkpoint.json"),
            "Native checkpoint inventories differ")
    for stage, key, name in (("fit", "fit_report_sha256", "STV_DS.fit.rpt"),
                             ("asm", "asm_report_sha256", "STV_DS.asm.rpt")):
        require(ctx["qualifications"][stage]["qualification"][key]
                == trees[stage]["output_files/" + name]["sha256"],
                "Qualified native report changed")
    with zipfile.ZipFile(RESEARCH / "oldprofile-control-r2-source-7e987bb-canonical.zip") as z:
        canonical = {n: hashlib.sha256(z.read(n)).hexdigest()
                     for n in z.namelist() if not n.endswith("/")}
        require(len(canonical) == 203, "Canonical source count differs")
        canonical["STV_DS.qsf"] = hashlib.sha256(
            expected_qsf(z.read("STV_DS.qsf"), seed)).hexdigest()
        ctx["inherited_mif"] = sorted(n for n in canonical if n.endswith((".mif", ".mem")))
    original = read(BATCH / "seed1-files.json")
    for stage, tree in trees.items():
        for n, expected in canonical.items():
            require(tree[n]["sha256"] == expected, "Compiled source/QSF/clock/SDC/PLL changed: " + n)
        for n in ctx["roles"]["generated_names"] + ctx["roles"]["map_database_names"]:
            require(tree[n] == original[n], "Generated/map/date changed: " + n)
        for n, expected in ctx["results"][stage]["input_hashes_after"].items():
            require(tree[n]["sha256"] == expected, "Final guard input differs: " + n)
    for n in ctx["roles"]["fit_database_names"]:
        require(trees["asm"][n] == trees["fit"][n], "Assembler changed fitted DB role: " + n)
    require((ctx["folder"] / "asm/tree/build_id.v").read_bytes()
            == b'\x60define BUILD_DATE "261025"', "Fixed generated date changed")
    for n, value in ctx["qualifications"]["asm"]["qualification"]["outputs"].items():
        require(trees["asm"][n] == {k: value[k] for k in ("bytes", "sha256")},
                "Fresh programming output differs: " + n)
    report_prefix = "sta/reports/"
    reports = {n[len(report_prefix):]: v for n, v in actual.items() if n.startswith(report_prefix)}
    require(len(reports) == ctx["root"]["actual_report_file_count"] and reports,
            "Actual report count differs from reviewed evidence")
    for n in ("corner-inventory.tsv", "clock-check-coverage.tsv",
              "global-check-coverage.tsv", "old-mode-check-coverage.tsv"):
        require(n in reports and reports[n]["bytes"] > 0, "Missing coverage evidence: " + n)
    fit, asm = trees["fit"], trees["asm"]
    ctx.update(trees=trees, reports=reports,
               changed={n: v for n, v in asm.items() if fit.get(n) != v},
               deleted=sorted(set(fit) - set(asm)))
    return ctx


def checkpoint_groups(seed, folder, trees):
    tag, groups = f"seed{seed:02}", {}
    fit, asm = trees["fit"], trees["asm"]
    for n in fit:
        group = ("checkpoint-db" if n.startswith("db/") else
                 "checkpoint-incremental-db" if n.startswith("incremental_db/") else
                 "checkpoint-project-and-outputs")
        groups.setdefault(group, {})[f"{tag}/fit-checkpoint/tree/{n}"] = folder / "fit/tree" / n
    for n in asm:
        if fit.get(n) != asm[n]:
            groups.setdefault("assembled-checkpoint-overlay", {})[
                f"{tag}/assembled-checkpoint-overlay/tree/{n}"] = folder / "asm/tree" / n
    return groups


def partition(entries, budget=RAW_PART_BUDGET):
    batch, total = [], 0
    for name, path in sorted(entries.items()):
        relative(name)
        size = path.stat().st_size
        require(size < budget, "Single member exceeds raw part budget: " + name)
        if batch and total + size > budget:
            yield batch
            batch, total = [], 0
        batch.append((name, path))
        total += size
    if batch:
        yield batch


def write_zip(path, entries):
    entries = list(entries)
    records = {n: info(p) for n, p in entries}
    require(len(records) == len(entries), "Duplicate ZIP member")

    def build():
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for n, p in entries:
                relative(n)
                data = p.read_bytes()
                require(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
                        == records[n], "Packaging input changed: " + n)
                zi = zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0))
                zi.create_system, zi.external_attr = 3, 0o100644 << 16
                z.writestr(zi, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
        return buf.getvalue()

    data = build()
    require(len(data) < ZIP_LIMIT and data == build(), "ZIP size/determinism failed")
    with path.open("xb") as stream:
        stream.write(data)
    with zipfile.ZipFile(path) as z:
        require(z.testzip() is None and z.namelist() == [n for n, _ in entries], "ZIP CRC/member inventory failed")
        for n, record in records.items():
            raw = z.read(n)
            require(dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) == record,
                    "ZIP member hash failed: " + n)
    return dict(bytes=len(data), sha256=sha(path), member_count=len(records), members=records,
                all_member_sha_and_crc_verified=True, deterministic_second_serialization_identical=True)


def package(ctx, out):
    seed, folder, tag = ctx["seed"], ctx["folder"], f'seed{ctx["seed"]:02}'
    require(seed in range(6, 11), "Creation is restricted to remaining seeds6-10")
    require(out.parent.resolve() == RESEARCH.resolve(), "Output must be a new direct research-directory child")
    require(all(sha(p) == expected for p, expected in ctx["metadata_bindings"].items()),
            "Reviewed metadata changed before output creation")
    out.mkdir(exist_ok=False)
    trees, packages = ctx["trees"], {}
    for stage, tree in trees.items():
        save(out / f"SEED{seed:02}-{stage.upper()}-SNAPSHOT.json",
             dict(directory=str(folder / stage / "tree"), files=tree, file_count=len(tree),
                  bytes=sum(v["bytes"] for v in tree.values()), snapshot_sha256=digest(tree)))
    with (out / "SEALED-PRESERVATION-INDEX.json").open("xb") as stream:
        stream.write(ctx["seal_path"].read_bytes())
    save(out / "ASM-OVERLAY.json", dict(base_snapshot_sha256=digest(trees["fit"]),
         target_snapshot_sha256=digest(trees["asm"]), changed_or_added=ctx["changed"],
         deleted=ctx["deleted"], base_prefix=tag + "/fit-checkpoint/tree/",
         overlay_prefix=tag + "/assembled-checkpoint-overlay/tree/"))
    save(out / "SEED-PRESERVATION-MANIFEST.json", dict(
        state="LOCAL_DRAFT_PENDING_ROOT_PACKAGE_REVIEW", recorded_by="package_shienryu_seed.py",
        source_commit=SOURCE, seed=seed, root_package_review="PENDING",
        root_timing_review_sha256=sha(ctx["root_path"]), independent_timing_review_sha256=sha(ctx["peer_path"]),
        sealed_preservation_index_sha256=sha(ctx["seal_path"]), native_matrix=ctx["matrix"],
        programming_outputs=ctx["root"]["programming_outputs"],
        root_measurement_decision=ctx["root"]["decision"],
        root_measurement_qualified_clean_candidate=ctx["root"].get("qualified_clean_candidate"),
        package_grants_timing_or_hardware_acceptance=False, remote_uploaded=False,
        bit_identical_rebuild_demonstrated=False, whole_batch_cleanup_implied=False,
        actual_STA_report_file_count=len(ctx["reports"]), packager_sha256=sha(Path(__file__)),
        STA_working_DB_qualification="Complete fit/map/incremental DB and exact ASM overlay retained; redundant STA caches omitted; exact STA snapshot and every actual raw report retained."))
    lines = [f"# Shienryu control R2 seed {seed} — experimental DRAFT", "",
             "Local package awaiting root review; no upload, root/package/hardware acceptance or bit-identical rebuild is granted.",
             f"Fixed source {SOURCE}, Quartus25.1 Lite/STV_DS, stored seed{seed}, generated date261025.",
             "The archived root measurement decision is: " + ctx["root"]["decision"], "",
             f"All {len(trees['fit'])} fit/map/incremental files plus the exact {len(ctx['changed'])}-file ASM overlay reconstruct {len(trees['asm'])} assembled files.",
             "Extract every fit-checkpoint part into a NEW empty directory, apply the assembler overlay, and remove only its explicit deleted list. Never overwrite an original.",
             "Programming/ contains the genuine ASM RBF/SOF; fitter-only copied outputs remain inherited seed1 files.",
             f"All {len(ctx['reports'])} actual reports, native Jobs/qualification, source/QSF/SDC/PLL/date/tools/admissions/reviews are retained.",
             "Only per-stage terminal/handle proofs are recorded; whole-batch scheduled-task cleanup is not implied.",
             "Exact existing binary/checkpoint restoration is supported by hashes; bit-identical recompilation is unproven. Further analysis needs compatible tools/device support and reviewed path adaptation.",
             "Each ZIP is below100,000,000 bytes, fixed1980/Unix0644/DEFLATE6, serialized twice identically, and every member hash/CRC verified.",
             "Retain all parts and sidecars. An output lacking final PACKAGE-INDEX.json is incomplete and must not publish.",
             "No externally sourced game/BIOS/runtime archives or credentials added. Exact inherited tracked MIF/microcode is retained without asserting content-level copyright clearance.", "",
             "All eight conditions at1.1V follow. A reported0.000ns is zero visible margin, not positive margin. Inherited I/O/audio-reset/runtime-PLL and simulation/custom-geometry qualifications remain.", "",
             "| Model | C | Setup ns | Hold ns | Recovery ns | Removal ns | MPW ns | Result |",
             "| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |"]
    for row in ctx["matrix"]:
        checks, pw = row["checks"], row["minimum_pulse_width"]
        failed = [k for k in CHECKS if not checks[k]["pass"]]
        if pw["slack_ns"] < 0 or pw["violated"] > 0:
            failed.append("MPW")
        values = [f'{checks[k]["slack_ns"]:+.3f}' for k in CHECKS]
        lines.append("| " + " | ".join([row["model"].title(), str(row["temperature_C"]),
                     *values, f'{pw["slack_ns"]:+.3f}', "Fail " + ",".join(failed) if failed else "Pass"]) + " |")
    with (out / "README.md").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write("\n".join(lines) + "\n")
    groups = checkpoint_groups(seed, folder, trees)
    for group, entries in groups.items():
        for i, part in enumerate(partition(entries), 1):
            name = f"control-r2-{tag}-DRAFT-{group}-{i:02}.zip"
            packages[name] = dict(group=group, **write_zip(out / name, part))
            print(json.dumps(dict(zip=name, bytes=packages[name]["bytes"])), flush=True)
    checkpoint_packages = dict(packages)
    evidence = {}
    for stage in STAGES:
        for path in sorted((folder / stage).iterdir()):
            if path.is_file():
                evidence[f"{tag}/evidence/stages/{stage}/{path.name}"] = path
        for n in ctx["seal"]["members"]:
            if n.startswith(stage + "/reports/"):
                evidence[f"{tag}/evidence/stages/{n}"] = folder / n
    for name in ("oldprofile-control-r2-source-7e987bb-canonical.zip",
                 "OLDPROFILE-CONTROL-R2-SOURCE-ARCHIVE.json", "ROOT-OLDPROFILE-CONTROL-R2-SOURCE-REVIEW.json",
                 ctx["root_path"].name, ctx["peer_path"].name, "CONTROL-R2-SEED-INDEX.json"):
        evidence[f"{tag}/evidence/research/{name}"] = RESEARCH / name
    for name in ("batch-manifest.json", "frozen-pins.json", "ROOT-BATCH-ADMISSION.json",
                 "ROOT-FROZEN-ADAPTER-REVIEW.json", "launch-admission.json", "seed1-files.json",
                 "coverage-reference.json", "scheduler-action-start.json", "start-receipt.json",
                 "registration-receipt.json"):
        evidence[f"{tag}/evidence/batch/{name}"] = BATCH / name
    adapter = RESEARCH / "frozen-batch-adapter-preservation"
    for name in ("shienryu-control-r2-seeds03-10-frozen-adapter-DRAFT.zip", "MEMBER-HASHES.json", "README.md"):
        evidence[f"{tag}/evidence/frozen-batch-adapter/{name}"] = adapter / name
    evidence[f"{tag}/evidence/tool-provenance/TOOL-PROVENANCE.json"] = (
        RESEARCH / "control-r2-seed-preservation/TOOL-PROVENANCE.json")
    evidence[f"{tag}/evidence/packager/package_shienryu_seed.py"] = Path(__file__)
    for name in ("SEALED-PRESERVATION-INDEX.json", "ASM-OVERLAY.json",
                 "SEED-PRESERVATION-MANIFEST.json", "README.md",
                 *(f"SEED{seed:02}-{stage.upper()}-SNAPSHOT.json" for stage in STAGES)):
        evidence[f"{tag}/evidence/preservation/{name}"] = out / name
    for ext in ("rbf", "sof"):
        evidence[f"{tag}/programming/STV_DS.{ext}"] = folder / f"asm/tree/output_files/STV_DS.{ext}"
    evidence_before = {n: info(p) for n, p in evidence.items()}
    for n, path in evidence.items():
        if path.suffix.lower() in (".json", ".md", ".tcl", ".log", ".py", ".ps1", ".txt"):
            require(not SECRET.search(path.read_bytes()), "Credential marker in selected evidence: " + n)
    for i, part in enumerate(partition(evidence), 1):
        name = f"control-r2-{tag}-DRAFT-source-programming-and-evidence-{i:02}.zip"
        packages[name] = dict(group="source-programming-and-evidence", **write_zip(out / name, part))
    members = {n: value for pkg in packages.values() for n, value in pkg["members"].items()}
    base, overlay = tag + "/fit-checkpoint/tree/", tag + "/assembled-checkpoint-overlay/tree/"
    reconstructed = {n[len(base):]: v for n, v in members.items() if n.startswith(base)}
    require(reconstructed == trees["fit"], "Full fit archive-member coverage failed")
    changed = {n[len(overlay):]: v for n, v in members.items() if n.startswith(overlay)}
    require(changed == ctx["changed"], "ASM overlay member coverage failed")
    for n in ctx["deleted"]:
        del reconstructed[n]
    reconstructed.update(changed)
    require(reconstructed == trees["asm"], "Exact assembled checkpoint reconstruction failed")
    require({n: info(p) for n, p in evidence.items()} == evidence_before, "Evidence changed after packaging")
    after = snapshot(folder)
    after.pop("preservation-index.json")
    require(after == ctx["seal"]["members"] and sha(ctx["seal_path"]) ==
            sha(out / "SEALED-PRESERVATION-INDEX.json"), "Original seed changed after packaging")
    require(all(sha(p) == expected for p, expected in ctx["metadata_bindings"].items()),
            "Reviewed metadata changed after packaging")
    report_prefix = f"{tag}/evidence/stages/sta/reports/"
    require({n[len(report_prefix):]: v for n, v in members.items() if n.startswith(report_prefix)}
            == ctx["reports"], "Actual report member coverage failed")
    save(out / "CHECKPOINT-MEMBER-HASHES.json", dict(
        state="CHECKPOINT_PARTS_COMPLETE_FINAL_EVIDENCE_IN_MEMBER_HASHES", seed=seed,
        packages=checkpoint_packages, all_sealed_original_members_unchanged=True))
    save(out / "SAFETY-AUDIT.json", dict(
        no_externally_sourced_game_BIOS_runtime_archives_or_credentials_added=True,
        inherited_tracked_MIF_microcode=ctx["inherited_mif"], content_level_copyright_clearance_asserted=False,
        no_other_seed_tree_read=True, no_Git_device_native_or_remote_actions=True))
    save(out / "ORIGINAL-PRESERVATION-CHECK.json", dict(
        sealed_member_count=len(after), all_original_bytes_and_membership_exact_before_after=True,
        seal_sha256=sha(ctx["seal_path"]), fit_snapshot_sha256=digest(trees["fit"]),
        assembled_snapshot_sha256=digest(trees["asm"]), actual_STA_reports=len(ctx["reports"]),
        archive_member_union_reconstructs_complete_fit_and_ASM=True))
    save(out / "MEMBER-HASHES.json", dict(
        state="LOCAL_DRAFT_PENDING_ROOT_PACKAGE_REVIEW", seed=seed, source_commit=SOURCE,
        packages=packages, root_timing_result_sha256=sha(ctx["root_path"])))
    save(out / "PACKAGE-INDEX.json", dict(
        state="LOCAL_DRAFT_PENDING_ROOT_PACKAGE_REVIEW", root_package_review="PENDING",
        recorded_by="package_shienryu_seed.py", seed=seed, source_commit=SOURCE,
        packager_sha256=sha(Path(__file__)), root_timing_result_sha256=sha(ctx["root_path"]),
        original_seal_sha256=sha(ctx["seal_path"]),
        packages={n: {k: v for k, v in p.items() if k != "members"} for n, p in packages.items()},
        package_count=len(packages), total_ZIP_bytes=sum(p["bytes"] for p in packages.values()),
        largest_ZIP_bytes=max(p["bytes"] for p in packages.values()), archived_member_count=len(members),
        actual_STA_reports=len(ctx["reports"]), all_sealed_original_members_unchanged=True,
        sidecars={p.name: info(p) for p in sorted(out.iterdir()) if p.is_file() and p.suffix != ".zip"},
        remote_uploaded=False, package_grants_timing_or_hardware_acceptance=False,
        bit_identical_rebuild_demonstrated=False, whole_batch_cleanup_implied=False))
    return dict(output=str(out), package_index_sha256=sha(out / "PACKAGE-INDEX.json"),
                package_count=len(packages), sealed_member_count=len(after),
                actual_STA_reports=len(ctx["reports"]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, choices=range(6, 11), required=True)
    parser.add_argument("--out", type=Path, required=True, help="New direct child of the research directory")
    parser.add_argument("--create", action="store_true", help="Perform gated local packaging; otherwise print a plan without opening seed inputs")
    args = parser.parse_args()
    out = args.out.resolve()
    require(out.parent == RESEARCH.resolve() and not out.exists(),
            "Output must be a new direct research-directory child")
    if not args.create:
        print(json.dumps(dict(state="READ_ONLY_PLAN_NO_SEED_INPUTS_OPENED", seed=args.seed,
                              out=str(out), create_requires="Sealed/terminal/protected/source/native/all8/root+peer gates",
                              remote_or_hardware_acceptance=False)))
        return
    print(json.dumps(package(preflight(args.seed), out), indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, zipfile.BadZipFile) as error:
        print(json.dumps(dict(state="REFUSED_OR_INCOMPLETE_LOCAL_DRAFT", error=str(error))), file=sys.stderr)
        raise SystemExit(1)
