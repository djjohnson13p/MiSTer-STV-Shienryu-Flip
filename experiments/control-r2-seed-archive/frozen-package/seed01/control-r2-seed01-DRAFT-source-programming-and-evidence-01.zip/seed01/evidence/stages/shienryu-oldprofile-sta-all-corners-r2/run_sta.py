"""One copy-isolated fixed old-profile STV_DS saved-fit all-corner STA. Default validates locally only."""
import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
TREE=BASE/'tree'
POWERSHELL='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
GIB=1024**3
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,
    tree_rss_bytes=9*GIB,admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def names(tree):return {path.relative_to(tree).as_posix() for path in tree.rglob('*') if path.is_file()}

def no_overlap():
    scan=subprocess.check_output([POWERSHELL,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not scan or not json.loads(scan),'Quartus overlap'

def validate():
    pins=json.loads((BASE/'frozen-pins.json').read_text())
    for name,digest in pins.items():assert sha(BASE/name)==digest,'Frozen STA input changed: '+name
    m=json.loads((BASE/'sta-manifest.json').read_text());original=Path(m['fitted_directory'])
    assert m['source_commit']=='7e987bb9ef0361356be22be13551e4626902f3a7'
    assert m['project']==m['revision']=='STV_DS'
    assert m['constraint_disposition']=='FIXED_OLD_PROFILE_MODE_PATHS_FULLY_TIMED'
    assert m['limits']==LIMITS and m['guard_sha256']==sha(BASE/'quartus_job_guard.py')==GUARD_SHA
    assert sha(BASE/'sta_all_corners.tcl')==m['sta_tcl_sha256']=='83cbe8f26ee214464867a912c64a3b5b9ff7512cbd73d72558d08e69d4c2c32d'
    assert sha(m['api_help_receipt'])==m['api_help_receipt_sha256']
    assert sha(m['mode_diagnostic_api_evidence_path'])==m['mode_diagnostic_api_evidence_sha256']=='684426b21e5ace6f2b2fa95497588f5eccaeffcbeaac1c729d98c8f4462d1293'
    assert m['old_mode_diagnostics']['source_expression']=='ascal|o_flip_180'
    assert sha(m['fit_review_path'])==m['fit_review_sha256']
    assert sha(m['source_review_path'])==m['source_review_sha256']=='735286ac878d801091284690091dbd6cbd12ad92d2ebe4c473234129048d06f3'
    assert sha(m['constraint_review_path'])==m['constraint_review_sha256']==m['source_review_sha256']
    for name,digest in m['fitted_evidence_sha256'].items():assert sha(original/name)==digest,'Original fixed old-profile fullflow receipt/report changed: '+name
    for path,digest in m['tool_bindings'].items():assert sha(path)==digest,'Pinned STA tool changed: '+path
    copied=json.loads((BASE/'copied-fitted-files.json').read_text())
    assert sha(BASE/'copied-fitted-files.json')==m['copied_manifest_sha256'] and len(copied)==m['copied_file_count']
    assert names(original/'tree')==set(copied),'Original fitted file membership changed'
    for name,row in copied.items():
        assert sha(original/'tree'/name)==row['sha256'],'Original fitted tree changed: '+name
        assert sha(TREE/name)==row['sha256'],'Prepared STA tree changed: '+name
    for key in ('action_source','registration_source'):assert sha(BASE/m['scheduler'][key])==m['scheduler'][key+'_sha256']
    return m,pins

def validate_pristine(m):
    copied=json.loads((BASE/'copied-fitted-files.json').read_text())
    assert names(TREE)==set(copied),'Prepared STA tree contains another attempt or unbound file'
    assert not any((BASE/'reports').iterdir()),'STA report attempt already exists'

def table(name):
    with (BASE/'reports'/name).open(newline='') as stream:return list(csv.DictReader(stream,delimiter='\t'))

def read_resources():
    # Read-only native memory sample; never creates a Job, task or compiler process.
    spec = importlib.util.spec_from_file_location('shienryu_resource_probe_guard', BASE / 'quartus_job_guard.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    api = module.Windows()
    value = module.Performance(cb=module.C.sizeof(module.Performance))
    api.checked(api.p.GetPerformanceInfo(module.C.byref(value), value.cb), 'GetPerformanceInfo')
    free = (value.limit - value.commit) * value.page
    threshold = 12 * 1024**3
    return dict(observed_utc=module.stamp(), free_commit_bytes=free, admission_free_commit_bytes=threshold,
        admission_pass=free >= threshold, committed_bytes=value.commit*value.page,
        commit_limit_bytes=value.limit*value.page, physical_available_bytes=value.available*value.page,
        physical_total_bytes=value.physical*value.page, no_job_or_task_created=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
    if not (BASE/'frozen-pins.json').exists():
        assert not args.run,'Root-accepted terminal fixed old-profile fitted copy has not been prepared'
        print(json.dumps(dict(state='template-only-no-database-read-no-task-no-sta',root_accepted_terminal_old_profile_fit_required=True)));return 0
    m,pins=validate();copied=json.loads((BASE/'copied-fitted-files.json').read_text());original=Path(m['fitted_directory'])
    spec=importlib.util.spec_from_file_location('shienryu_oldprofile_saved_fit_all_corner_guard',BASE/'quartus_job_guard.py')
    guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
    bound_names=sorted(set(m['source_names']+m['generated_names']+m['map_database_names']+m['fit_database_names']))
    def inputs():return {name:sha(TREE/name) for name in bound_names}
    guard.LAB=BASE.parents[1];guard.BASE=BASE;guard.TREE=TREE;guard.BASELINE=m['source_commit']
    guard.QUARTUS=Path('C:/altera_lite/25.1std/quartus');guard.EXE=guard.QUARTUS/'bin64/quartus_sta.exe'
    guard.COMMAND=[str(guard.EXE),'-t',str(BASE/'sta_all_corners.tcl')]
    guard.RUN_KIND='shienryu-oldprofile-control-r2-fixed-mode-saved-fit-all-available-corner-sta-no-wall';guard.LIMITS=dict(LIMITS);guard.inputs=inputs
    assert guard.COMMAND==m['command'] and guard.LIMITS==m['limits']
    plan=dict(state='local-dry-run-no-task-or-native-job',command=guard.COMMAND,cwd=str(TREE),output=str(BASE),
        source_commit=m['source_commit'],copied_files=len(copied),
        protected_source_and_fitted_inputs=len(bound_names),manifest_sha256=sha(BASE/'sta-manifest.json'),
        adapter_sha256=sha(__file__),sta_tcl_sha256=m['sta_tcl_sha256'],guard_sha256=GUARD_SHA,limits=guard.LIMITS,
        scope=m['operation'],timing_acceptance=False)
    if not args.run:print(json.dumps(plan,indent=2));return 0
    validate_pristine(m)
    for name in ('prelaunch.json','fullflow.log','live.json','result.json','preservation-readback.json'):
        assert not (BASE/name).exists(),'Preserve previous attempt: '+name
    action=json.loads((BASE/'scheduler-action-start.json').read_text(encoding='utf-8-sig'))
    assert action['pid']==os.getppid() and action['parent_name'].lower() in ('svchost.exe','taskeng.exe'),'Use reviewed OS-owned Task Scheduler launch'
    no_overlap();plan.update(scheduler_action_start=action,scheduler_task_name=m['scheduler']['task_name'])
    guard.save(BASE/'prelaunch.json',plan);code=guard.run(inputs())
    original_members=names(original/'tree');working_members=names(TREE)
    original_changed=[name for name,row in copied.items() if name not in original_members or sha(original/'tree'/name)!=row['sha256']]
    original_added=sorted(original_members-set(copied))
    local_changed={name:dict(before=row['sha256'],after=sha(TREE/name) if name in working_members else None)
        for name,row in copied.items() if name not in working_members or sha(TREE/name)!=row['sha256']}
    local_added={name:sha(TREE/name) for name in sorted(working_members-set(copied))}
    immutable=set(m['source_names']+m['generated_names']+m['map_database_names']+m['primary_cmp_names'])
    protected_changes={name:row for name,row in local_changed.items() if name in immutable}
    coverage={};coverage_error=None
    try:
        corners=table('corner-inventory.tsv');perclock=table('clock-check-coverage.tsv');global_rows=table('global-check-coverage.tsv')
        coverage=dict(corners=len(corners),clock_counts=[int(row['clock_count']) for row in corners],
            per_clock_rows=len(perclock),global_rows=len(global_rows),zero_path_rows=sum(row['returned_path_count']=='0' for row in perclock))
        coverage['complete_dynamic_row_counts']=(len(corners)>=2 and len(set(coverage['clock_counts']))==1 and
            all(count>0 for count in coverage['clock_counts']) and
            [int(row['index']) for row in corners]==list(range(1,len(corners)+1)) and
            len(perclock)==sum(coverage['clock_counts'])*4 and len(global_rows)==len(corners)*4)
        coverage['constraints_and_mpw_reports_present']=all((BASE/'reports'/f'corner-{index:02d}-{kind}.rpt').is_file()
            for index in range(1,len(corners)+1) for kind in ('constraints','min-pulse-width'))
        # Required reporting-only old-mode coverage; no excluded or absent path is a pass.
        mode_rows=table('old-mode-check-coverage.tsv')
        expected_mode_keys={(int(corner['index']),variant,kind) for corner in corners
            for variant in ('default','no_duplicates') for kind in ('setup','hold')}
        mode_keys=[(int(row['corner']),row['collection_variant'],row['check']) for row in mode_rows]
        coverage['old_mode_rows']=len(mode_rows)
        coverage['old_mode_complete_dynamic_rows']=(len(mode_keys)==len(expected_mode_keys) and set(mode_keys)==expected_mode_keys)
        assert coverage['old_mode_complete_dynamic_rows'],'Missing, duplicate or unexpected old-mode coverage rows'
        mode_reports={};mode_counts={}
        for row in mode_rows:
            corner=int(row['corner']);variant=row['collection_variant'];kind=row['check']
            assert row['source_expression']=='ascal|o_flip_180'
            keepers=int(row['keepers_count']);registers=int(row['registers_count']);paths=int(row['returned_path_count'])
            assert keepers>=0 and registers>=0 and paths in (0,1)
            key=f'{corner}:{variant}';counts=dict(keepers=keepers,registers=registers)
            assert key not in mode_counts or mode_counts[key]==counts,'Mode collection counts differ between setup/hold rows'
            mode_counts[key]=counts
            expected_report=f'corner-{corner:02d}-old-mode-{variant}-{kind}.rpt'
            if keepers==0:
                assert paths==0 and row['worst_slack_ns']=='NA' and row['report_file']=='NA'
                assert row['classification']=='NO_MATCHING_KEEPERS_REQUIRES_REVIEW'
                assert not (BASE/'reports'/expected_report).exists(),'Zero-collection timing report must not exist'
            else:
                assert row['report_file']==expected_report
                report=BASE/'reports'/expected_report
                assert report.is_file() and report.stat().st_size>0,'Missing native targeted full-path report'
                mode_reports[expected_report]=sha(report)
                if paths==0:
                    assert row['worst_slack_ns']=='NA' and row['classification']=='NO_PATHS_REQUIRES_REVIEW'
                else:
                    assert math.isfinite(float(row['worst_slack_ns'])) and row['classification']=='PATH_FOUND_REQUIRES_TIMING_REVIEW'
        coverage['old_mode_collection_counts']=mode_counts
        coverage['old_mode_no_matching_rows']=sum(row['keepers_count']=='0' for row in mode_rows)
        coverage['old_mode_no_timed_path_rows']=sum(row['returned_path_count']=='0' for row in mode_rows)
        coverage['old_mode_report_sha256']=mode_reports
        coverage['old_mode_coverage_sha256']=sha(BASE/'reports/old-mode-check-coverage.tsv')
        coverage['old_mode_diagnostic_reports_complete']=True
        coverage['fixed_profile_mode_paths_present']=all(int(row['keepers_count'])>0 and int(row['registers_count'])>0 and int(row['returned_path_count'])>0 for row in mode_rows)
        assert coverage['fixed_profile_mode_paths_present'],'Fixed profile requires nonempty mode keeper/register and timed-path queries; zero/NA is not a pass'
    except Exception as error:coverage_error=str(error)
    readback=dict(original_fitted_files_changed=original_changed,original_fitted_files_added=original_added,
        original_fit_result_sha256=sha(original/'result.json'),local_working_files_changed=local_changed,
        local_working_files_added=local_added,protected_source_generated_map_primary_cmp_changes=protected_changes,
        coverage=coverage,coverage_error=coverage_error,zero_path_transfer_applicability_review_required=True,
        STA_exit_is_not_timing_acceptance=True,timing_acceptance=False,constraint_disposition=m['constraint_disposition'])
    guard.save(BASE/'preservation-readback.json',readback)
    return 0 if code==0 and not original_changed and not original_added and not protected_changes and not coverage_error and coverage.get('complete_dynamic_row_counts') and coverage.get('constraints_and_mpw_reports_present') and coverage.get('old_mode_complete_dynamic_rows') and coverage.get('old_mode_diagnostic_reports_complete') and coverage.get('fixed_profile_mode_paths_present') else 1

if __name__=='__main__':raise SystemExit(main())
