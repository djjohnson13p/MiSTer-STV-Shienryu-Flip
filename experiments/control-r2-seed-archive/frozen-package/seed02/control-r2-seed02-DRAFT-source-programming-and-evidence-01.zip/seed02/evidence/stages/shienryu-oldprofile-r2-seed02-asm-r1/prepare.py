"""Unfrozen single-stage seed2 template. Default plans only; preparation never launches native work."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
LAB=BASE.parents[1]
PARENT=BASE.parent/'shienryu-oldprofile-r2-seed02-fit-r1'
PIN='7e987bb9ef0361356be22be13551e4626902f3a7'
PARENT_MANIFEST='fit-manifest.json'
PARENT_REVIEW_DECISION='ACCEPTED_SEED02_FIT_FOR_ASSEMBLER'
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
TCL_NAME='asm_only.tcl'
TCL_SHA='6a9d7ed0785dc94521c9a24e0426f88a6f1720dc50702bd9159fcbf3797132df'
PYTHON=Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
EXE=Path('C:/altera_lite/25.1std/quartus/bin64/quartus_sh.exe')
POWERSHELL='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
BUILD_ID_SHA='5b35f414663a939035468cad510c62429d250fa24e1114e19f171e449bd5e5c1'
SEED1_ORIGINAL_COUNT=1051
SEED1_ORIGINAL_SNAPSHOT_SHA='7bd644fb86eca6ee83f995e94b9d014a369d89a1e173fb5f755e2d353c57c901'
GIB=1024**3
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,tree_rss_bytes=9*GIB,
    admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)
INVENTORY_KEYS=('generated_names','map_database_names','fit_database_names','primary_cmp_names')
SCRIPTS=('prepare.py','run_asm.py','launch_task.py','quartus_job_guard.py',TCL_NAME,'register-start-inline.ps1',
    'scheduler-action-inline.ps1','PLAN.md','template-reuse-provenance.json')
REQUIRED_CONDITIONS=[dict(model=model,temperature_C=temp,status='PENDING_NOT_ANALYZED') for model in ('slow','fast') for temp in (-40,0,85,100)]

def sha(p):
    with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(p,d):
    with p.open('x',encoding='utf-8') as stream:json.dump(d,stream,indent=2);stream.write('\n')
def snapshot(tree):
    result={}
    for p in sorted(tree.rglob('*')):
        assert not p.is_symlink()
        if p.is_file():result[p.relative_to(tree).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p))
    return result

def no_overlap():
    text=subprocess.check_output([POWERSHELL,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not text or not json.loads(text),'Quartus overlap; do not read/copy parent tree'

def prerequisites(args):
    no_overlap()
    assert re.fullmatch('[0-9a-f]{64}',args.parent_result_sha256 or '') and re.fullmatch('[0-9a-f]{64}',args.parent_review_sha256 or '')
    path=Path(args.parent_review or '').resolve();assert path.is_file() and sha(path)==args.parent_review_sha256
    review=json.loads(path.read_text(encoding='utf-8-sig'))
    assert review['reviewer']=='root' and review['decision']==PARENT_REVIEW_DECISION
    assert review['source_commit']==PIN and review['seed']==2 and Path(review['parent_directory']).resolve()==PARENT.resolve()
    names=['result.json',PARENT_MANIFEST,'frozen-pins.json','preservation-readback.json','scheduler-action-exit.json','terminal-task-cleanup.json']+['tree/output_files/STV_DS.fit.rpt','tree/output_files/STV_DS.fit.summary']
    evidence={name:sha(PARENT/name) for name in names}
    assert evidence['result.json']==args.parent_result_sha256
    for name,digest in evidence.items():assert review['evidence_sha256'].get(name)==digest,'Root must bind parent evidence: '+name
    result=json.loads((PARENT/'result.json').read_text());m=json.loads((PARENT/PARENT_MANIFEST).read_text())
    assert result['state']=='terminal' and result['flow_exit_code']==0 and result['launcher_success'] and result['errors']==[]
    assert result['all_job_processes_terminal'] and result['all_handles_closed'] and result['final_job_active_processes']==0 and result['final_job_pids']==[]
    assert m['source_commit']==PIN and m['seed']==2 and m['project']==m['revision']=='STV_DS' and m['limits']==LIMITS
    assert sha(m['source_review_path'])==m['source_review_sha256']=='735286ac878d801091284690091dbd6cbd12ad92d2ebe4c473234129048d06f3'
    for name,digest in json.loads((PARENT/'frozen-pins.json').read_text()).items():assert sha(PARENT/name)==digest,'Frozen parent input changed: '+name
    cleanup=json.loads((PARENT/'terminal-task-cleanup.json').read_text(encoding='utf-8-sig'))
    assert cleanup['task_name']==m['scheduler']['task_name'] and cleanup['exact_task_unregistered']
    assert cleanup['all_job_processes_terminal'] and cleanup['all_handles_closed'] and cleanup['errors']==[]
    assert cleanup['remaining_owned_or_quartus_processes']==[] and cleanup['last_task_result']==0
    assert json.loads((PARENT/'scheduler-action-exit.json').read_text(encoding='utf-8-sig'))['exit_code']==0
    readback=json.loads((PARENT/'preservation-readback.json').read_text())
    assert readback['original_fitted_files_changed']==[] and readback['original_fitted_files_added']==[]
    assert readback['adapter_success'] and readback['protected_source_generated_map_changes']=={} and readback['intentional_seed_delta_matches']
    assert readback['native_fit_qualification_error'] is None and readback['native_fit_qualification']['passed']
    assert readback['native_fit_qualification']['actual_placement_seed']==2 and readback['native_fit_qualification']['no_post_fit_input']
    assert readback['native_fit_qualification']['zero_requested_and_achieved_placement_and_routing']
    assert sha(PARENT/PARENT_MANIFEST)=='13dc221bd56b8c0294d332e46f1e0b96bcc27a7196c069de1f83930f3b827506'
    assert sha(PARENT/'frozen-pins.json')=='7958633b735de7f3965aa7fb091ceeb2c83e5aa8255acf4b78c8f4520826ca01'
    assert m['copied_file_count']==SEED1_ORIGINAL_COUNT and m['copied_manifest_sha256']==SEED1_ORIGINAL_SNAPSHOT_SHA
    name=review['fit_input_inventory'];assert isinstance(name,str) and not Path(name).is_absolute() and '\\' not in name and '..' not in Path(name).parts
    inventory_path=PARENT/name;assert review['evidence_sha256'].get(name)==sha(inventory_path)
    inventory=json.loads(inventory_path.read_text(encoding='utf-8-sig'))
    assert inventory['reviewer']=='root' and inventory['decision']=='ACCEPTED_SAVED_FIT_INPUT_INVENTORY'
    assert inventory['source_commit']==PIN and inventory['seed']==2 and inventory['project']==inventory['revision']=='STV_DS'
    for key in INVENTORY_KEYS:
        assert inventory[key] and len(inventory[key])==len(set(inventory[key]))
        for name in inventory[key]:assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert set(inventory['primary_cmp_names'])<=set(inventory['fit_database_names'])
    assert set(inventory['files_sha256'])==set().union(*(set(inventory[k]) for k in INVENTORY_KEYS))
    evidence[review['fit_input_inventory']]=sha(inventory_path);no_overlap()
    return path,evidence,m,inventory

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--parent-result-sha256');parser.add_argument('--parent-review');parser.add_argument('--parent-review-sha256');args=parser.parse_args()
    assert Path(sys.executable).resolve()==PYTHON.resolve()
    assert sha(BASE/'quartus_job_guard.py')==sha(LAB/'scripts/quartus_job_guard.py')==GUARD_SHA and sha(BASE/TCL_NAME)==TCL_SHA
    command=[str(EXE),'-t',str(BASE/TCL_NAME)]
    plan=dict(state='template-only-no-live-parent-tree-read-copy-freeze-task-or-native',source_commit=PIN,seed=2,parent_directory=str(PARENT),
        command=command,limits=LIMITS,original_seed1_files=SEED1_ORIGINAL_COUNT,original_snapshot_sha256=SEED1_ORIGINAL_SNAPSHOT_SHA,
        fixed_build_id_sha256=BUILD_ID_SHA,required_timing_conditions=REQUIRED_CONDITIONS,timing_acceptance=False)
    if not args.prepare:print(json.dumps(plan,indent=2));return 0
    for name in ('tree','reports','asm-manifest.json','copied-parent-files.json','frozen-pins.json'):assert not (BASE/name).exists(),'Preserve existing preparation: '+name
    review_path,evidence,parent,inventory=prerequisites(args)
    copied=snapshot(PARENT/'tree');assert copied and copied['build_id.v']['sha256']==BUILD_ID_SHA
    for name,digest in inventory['files_sha256'].items():assert copied[name]['sha256']==digest
    assert set(parent['generated_names'])<=set(inventory['generated_names'])
    assert len(re.findall(rb'^set_global_assignment -name SEED 2\r?$',(PARENT/'tree/STV_DS.qsf').read_bytes(),re.M))==1
    tree=BASE/'tree';tree.mkdir()
    for name,row in copied.items():
        target=tree/name;target.parent.mkdir(parents=True,exist_ok=True)
        with (PARENT/'tree'/name).open('rb') as incoming,target.open('xb') as outgoing:shutil.copyfileobj(incoming,outgoing)
        assert sha(target)==row['sha256']
    assert snapshot(PARENT/'tree')==copied,'Immutable parent tree changed during copy'
    save(BASE/'copied-parent-files.json',copied);(BASE/'reports').mkdir()
    scheduler=dict(parent['scheduler']);scheduler.update(task_name='CoreLab-Shienryu-OldProfile-R2-Seed02-Assembler-Q251-R1',working_directory=str(BASE),
        action_source='scheduler-action-inline.ps1',registration_source='register-start-inline.ps1',
        action_source_sha256=sha(BASE/'scheduler-action-inline.ps1'),registration_source_sha256=sha(BASE/'register-start-inline.ps1'))
    m=dict(state='prepared-seed02-assembler-not-launched',source_commit=PIN,seed=2,constraint_disposition='FIXED_OLD_PROFILE_MODE_PATHS_FULLY_TIMED',project='STV_DS',revision='STV_DS',
        parent_directory=str(PARENT),parent_evidence_sha256=evidence,parent_review_path=str(review_path),parent_review_sha256=sha(review_path),
        source_review_path=parent['source_review_path'],source_review_sha256=parent['source_review_sha256'],source_names=parent['source_names'],
        copied_file_count=len(copied),copied_manifest_sha256=sha(BASE/'copied-parent-files.json'),build_id_sha256=BUILD_ID_SHA,
        original_seed1_file_count=SEED1_ORIGINAL_COUNT,original_seed1_snapshot_sha256=SEED1_ORIGINAL_SNAPSHOT_SHA,
        guard_sha256=GUARD_SHA,tcl_sha256=TCL_SHA,tool_bindings={str(p):sha(p) for p in [PYTHON,EXE]},
        command=command,limits=LIMITS,scheduler=scheduler,required_timing_conditions=REQUIRED_CONDITIONS,timing_acceptance=False)
    m.update({k:inventory[k] for k in INVENTORY_KEYS});save(BASE/'asm-manifest.json',m)
    save(BASE/'frozen-pins.json',{name:sha(BASE/name) for name in (*SCRIPTS,'asm-manifest.json','copied-parent-files.json')})
    print(json.dumps(dict(state=m['state'],copied_files=len(copied),frozen_pins_sha256=sha(BASE/'frozen-pins.json'),no_native_launch=True),indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
