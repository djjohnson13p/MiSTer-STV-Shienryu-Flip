# Assembler only from root-qualified seed2 fit. No map/fit/STA or assignment export.
package require ::quartus::flow
project_open STV_DS -revision STV_DS
puts "SHIENRYU_SEED02_ASSEMBLER_ONLY_BEGIN"
if {[catch {
    set seed [get_global_assignment -name SEED]
    if {$seed ne "2"} {error "Stored QSF seed is not exactly2: $seed"}
    puts "SHIENRYU_SEED02_STORED_SEED_READBACK=$seed"
    execute_module -tool asm -dont_export_assignments
} message]} {
    post_message -type error $message
    project_close -dont_export_assignments
    qexit -error
}
project_close -dont_export_assignments
puts "SHIENRYU_SEED02_ASSEMBLER_ONLY_COMPLETE"
