"""One copy-isolated fixed old-profile STV_DS saved-fit all-corner STA. Default validates locally only."""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import re
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
TREE=BASE/'tree'
POWERSHELL='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
GIB=1024**3
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,
    tree_rss_bytes=9*GIB,admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def names(tree):return {path.relative_to(tree).as_posix() for path in tree.rglob('*') if path.is_file()}

def no_overlap():
    scan=subprocess.check_output([POWERSHELL,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not scan or not json.loads(scan),'Quartus overlap'

REQUIRED_CONDITIONS=[dict(model=model,temperature_C=temp,status='PENDING_NOT_ANALYZED') for model in ('slow','fast') for temp in (-40,0,85,100)]

def validate():
    no_overlap()
    pins=json.loads((BASE/'frozen-pins.json').read_text())
    for name,digest in pins.items():assert sha(BASE/name)==digest,'Frozen stage input changed: '+name
    m=json.loads((BASE/'asm-manifest.json').read_text());original=Path(m['parent_directory'])
    assert m['source_commit']=='7e987bb9ef0361356be22be13551e4626902f3a7' and m['seed']==2 and m['project']==m['revision']=='STV_DS'
    assert m['limits']==LIMITS and m['guard_sha256']==sha(BASE/'quartus_job_guard.py')==GUARD_SHA
    assert sha(BASE/'asm_only.tcl')==m['tcl_sha256']=='6a9d7ed0785dc94521c9a24e0426f88a6f1720dc50702bd9159fcbf3797132df'
    assert sha(m['parent_review_path'])==m['parent_review_sha256']
    assert sha(m['source_review_path'])==m['source_review_sha256']=='735286ac878d801091284690091dbd6cbd12ad92d2ebe4c473234129048d06f3'
    assert m['original_seed1_file_count']==1051 and m['original_seed1_snapshot_sha256']=='7bd644fb86eca6ee83f995e94b9d014a369d89a1e173fb5f755e2d353c57c901'
    for name,digest in m['parent_evidence_sha256'].items():assert sha(original/name)==digest,'Parent evidence changed: '+name
    for path,digest in m['tool_bindings'].items():assert sha(path)==digest
    copied=json.loads((BASE/'copied-parent-files.json').read_text())
    assert sha(BASE/'copied-parent-files.json')==m['copied_manifest_sha256'] and len(copied)==m['copied_file_count']
    assert names(original/'tree')==set(copied) and names(TREE)==set(copied)
    for name,row in copied.items():
        assert sha(original/'tree'/name)==row['sha256'],'Immutable parent file changed: '+name
        assert sha(TREE/name)==row['sha256'],'Prepared stage file changed: '+name
    assert sha(TREE/'build_id.v')==m['build_id_sha256']
    assert len(re.findall(rb'^set_global_assignment -name SEED 2\r?$',(TREE/'STV_DS.qsf').read_bytes(),re.M))==1
    for key in ('action_source','registration_source'):assert sha(BASE/m['scheduler'][key])==m['scheduler'][key+'_sha256']
    return m,pins


def validate_pristine(m):
    assert names(TREE)==set(json.loads((BASE/'copied-parent-files.json').read_text()))
    assert not any((BASE/'reports').iterdir()),'Report attempt already exists'


def read_resources():
    # Read-only native memory sample; never creates a Job, task or compiler process.
    spec = importlib.util.spec_from_file_location('shienryu_resource_probe_guard', BASE / 'quartus_job_guard.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    api = module.Windows()
    value = module.Performance(cb=module.C.sizeof(module.Performance))
    api.checked(api.p.GetPerformanceInfo(module.C.byref(value), value.cb), 'GetPerformanceInfo')
    free = (value.limit - value.commit) * value.page
    threshold = 12 * 1024**3
    return dict(observed_utc=module.stamp(), free_commit_bytes=free, admission_free_commit_bytes=threshold,
        admission_pass=free >= threshold, committed_bytes=value.commit*value.page,
        commit_limit_bytes=value.limit*value.page, physical_available_bytes=value.available*value.page,
        physical_total_bytes=value.physical*value.page, no_job_or_task_created=True)




def main():
    parser=argparse.ArgumentParser(description='One seed2 assembler-only guarded stage');parser.add_argument('--run',action='store_true');args=parser.parse_args()
    if not (BASE/'frozen-pins.json').exists():
        assert not args.run,'Qualified root-accepted seed2 fit copy not frozen'
        print(json.dumps(dict(state='template-only-no-parent-tree-read-no-task-no-assembler',seed=2,required_timing_conditions=REQUIRED_CONDITIONS)));return 0
    m,pins=validate();original=Path(m['parent_directory']);copied=json.loads((BASE/'copied-parent-files.json').read_text())
    spec=importlib.util.spec_from_file_location('shienryu_seed02_asm_guard',BASE/'quartus_job_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
    bound_names=sorted(set(m['source_names']+m['generated_names']+m['map_database_names']+m['primary_cmp_names']))
    def inputs():return {name:sha(TREE/name) for name in bound_names}
    assert inputs()=={name:copied[name]['sha256'] for name in bound_names}
    guard.LAB=BASE.parents[1];guard.BASE=BASE;guard.TREE=TREE;guard.BASELINE=m['source_commit']
    guard.QUARTUS=Path('C:/altera_lite/25.1std/quartus');guard.EXE=guard.QUARTUS/'bin64/quartus_sh.exe'
    guard.COMMAND=[str(guard.EXE),'-t',str(BASE/'asm_only.tcl')];guard.LIMITS=dict(LIMITS);guard.inputs=inputs
    guard.RUN_KIND='shienryu-oldprofile-r2-seed02-assembler-only-no-wall'
    assert guard.COMMAND==m['command'] and guard.LIMITS==m['limits']
    plan=dict(state='prepared-dry-run-no-native-job',seed=2,command=guard.COMMAND,cwd=str(TREE),limits=LIMITS,
        required_timing_conditions=REQUIRED_CONDITIONS,timing_acceptance=False)
    if not args.run:print(json.dumps(plan,indent=2));return 0
    validate_pristine(m)
    for name in ('prelaunch.json','fullflow.log','live.json','result.json','preservation-readback.json'):assert not (BASE/name).exists()
    action=json.loads((BASE/'scheduler-action-start.json').read_text(encoding='utf-8-sig'))
    assert action['pid']==os.getppid() and action['parent_name'].lower() in ('svchost.exe','taskeng.exe')
    no_overlap()
    pre_native_output_stats={}
    for name in ('output_files/STV_DS.rbf','output_files/STV_DS.sof'):
        output=TREE/name;exists=output.is_file();stat=output.stat() if exists else None
        pre_native_output_stats[name]=dict(exists=exists,mtime_ns=stat.st_mtime_ns if stat else None,
            bytes=stat.st_size if stat else None,sha256=sha(output) if exists else None)
    plan['scheduler_action_start']=action;guard.save(BASE/'prelaunch.json',plan);code=guard.run(inputs())
    oldnames=names(original/'tree');working=names(TREE)
    original_changed=[name for name,row in copied.items() if name not in oldnames or sha(original/'tree'/name)!=row['sha256']]
    original_added=sorted(oldnames-set(copied));changed={name:dict(before=row['sha256'],after=sha(TREE/name) if name in working else None) for name,row in copied.items() if name not in working or sha(TREE/name)!=row['sha256']}
    protected={name:row for name,row in changed.items() if name in bound_names};qualification={};error=None
    try:
        result=json.loads((BASE/'result.json').read_text());started=dt.datetime.fromisoformat(result['started_utc']).timestamp()
        report=TREE/'output_files/STV_DS.asm.rpt';log=(BASE/'fullflow.log').read_text(encoding='utf-8',errors='replace')
        text=report.read_text(encoding='latin-1');modules=re.findall(r'Info: Running Quartus Prime ([^\r\n]+)',log)
        outputs={n:dict(bytes=(TREE/n).stat().st_size,sha256=sha(TREE/n),mtime=(TREE/n).stat().st_mtime,mtime_ns=(TREE/n).stat().st_mtime_ns) for n in ['output_files/STV_DS.rbf','output_files/STV_DS.sof']}
        fresh=all(row['bytes']>0 and row['mtime']>=started-2 and (not pre_native_output_stats[name]['exists'] or row['mtime_ns']>pre_native_output_stats[name]['mtime_ns']) for name,row in outputs.items())
        qualification=dict(assembler_successful=bool(re.search(r';\s*Assembler Status\s*;\s*Successful',text)),
            fresh_RBF_and_SOF=fresh,outputs=outputs,pre_native_output_stats=pre_native_output_stats,
            output_mtime_ns_advanced={name:(not pre_native_output_stats[name]['exists'] or row['mtime_ns']>pre_native_output_stats[name]['mtime_ns']) for name,row in outputs.items()},asm_report_sha256=sha(report),
            fresh_report=sha(report)!=copied['output_files/STV_DS.asm.rpt']['sha256'] and report.stat().st_mtime>=started-2,
            native_modules=modules,assembler_only=modules.count('Assembler')==1 and all(x in ('Shell','Assembler') for x in modules),
            stored_seed2_readback='SHIENRYU_SEED02_STORED_SEED_READBACK=2' in log)
        qualification['passed']=all(qualification[k] for k in ('assembler_successful','fresh_RBF_and_SOF','fresh_report','assembler_only','stored_seed2_readback'))
    except Exception as exc:error=str(exc)
    readback=dict(original_fitted_files_changed=original_changed,original_fitted_files_added=original_added,
        local_working_files_changed=changed,local_working_files_added={n:sha(TREE/n) for n in sorted(working-set(copied))},
        protected_source_generated_map_primary_cmp_changes=protected,pre_native_output_stats=pre_native_output_stats,
        assembly_qualification=qualification,assembly_qualification_error=error,
        required_timing_conditions=REQUIRED_CONDITIONS,inherited_seed1_outputs_not_used_as_new_results=True,timing_acceptance=False)
    readback['adapter_success']=code==0 and not original_changed and not original_added and not protected and not error and qualification.get('passed',False)
    guard.save(BASE/'preservation-readback.json',readback);return 0 if readback['adapter_success'] else 1
if __name__=='__main__':raise SystemExit(main())
