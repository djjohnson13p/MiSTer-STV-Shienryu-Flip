"""Template only by default; --prepare requires a root-accepted terminal STV fit. Never launches fitter or a task."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
LAB=BASE.parents[1]
FIT=BASE.parent/'shienryu-oldprofile-q251-candidate-r2'
PYTHON=Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
SHELL=Path('C:/altera_lite/25.1std/quartus/bin64/quartus_sh.exe')
POWERSHELL='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
PIN='7e987bb9ef0361356be22be13551e4626902f3a7'
FIT_MANIFEST_SHA='ab897f294a23f06c7268e8a782164dc7930b2577d727a8eed704c6f4ee1cc6ed'
FIT_FROZEN_PINS_SHA='97d818924a0a56df4a2a5385420f6eca74f09c0d8b8ab6bef6f216ae62df2729'
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
TCL_SHA='6c3fd4b498c7ef89cd80304ed2692aee4a1dfc450da5215d975e6fd47b0b2bec'
SEED_PLAN=LAB/'research/shienryu-timing-20261024/OLDPROFILE-CONTROL-R2-SAVED-SYNTHESIS-SEED-PLAN.json'
SEED_PLAN_SHA='cefc94a31cb7927f4c362bf2e043588cbadd6cacf70f3ba2f27f8b72045d53c6'
CONSTRAINTS=LAB/'research/shienryu-timing-20261024/ROOT-OLDPROFILE-CONTROL-R2-SOURCE-REVIEW.json'
CONSTRAINTS_SHA='735286ac878d801091284690091dbd6cbd12ad92d2ebe4c473234129048d06f3'
SEED1_STA=BASE.parent/'shienryu-oldprofile-sta-all-corners-r2'
QSF='STV_DS.qsf'
GIB=1024**3
FIT_LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,
    tree_rss_bytes=9*GIB,admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,
    tree_rss_bytes=9*GIB,admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)
SCRIPTS=('prepare.py','run_fit.py','launch_task.py','quartus_job_guard.py','fit_only.tcl',
    'scheduler-action-inline.ps1','register-start-inline.ps1','PLAN.md','template-reuse-provenance.json','fit-api-evidence.json')
EVIDENCE=('result.json','input-manifest.json','frozen-pins.json','integrity-readback.json',
    'scheduler-action-exit.json','terminal-task-cleanup.json','tree/output_files/STV_DS.fit.summary',
    'tree/output_files/STV_DS.fit.rpt','tree/output_files/STV_DS.flow.rpt')
INVENTORY_KEYS=('generated_names','map_database_names','fit_database_names','primary_cmp_names')

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def save(path,value):
    with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2);stream.write('\n')

def snapshot(tree):
    found={}
    for path in sorted(tree.rglob('*')):
        assert not path.is_symlink(),'Unsupported symlink: '+str(path)
        if path.is_file():found[path.relative_to(tree).as_posix()]=dict(bytes=path.stat().st_size,sha256=sha(path))
    return found

def no_overlap():
    scan=subprocess.check_output([POWERSHELL,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not scan or not json.loads(scan),'Quartus still active; do not read or copy a live fitted tree'

def safe_evidence_name(name):
    assert isinstance(name,str) and name and not Path(name).is_absolute() and '\\' not in name
    assert all(part not in ('','.','..') for part in name.split('/'))
    assert (FIT/name).resolve().is_relative_to(FIT.resolve())
    return name

def prerequisites(args):
    # This check precedes all reads of terminal evidence or the fitted tree.
    no_overlap()
    assert re.fullmatch('[0-9a-f]{64}',args.fit_result_sha256 or ''),'Root-accepted terminal result SHA256 required'
    assert re.fullmatch('[0-9a-f]{64}',args.fit_review_sha256 or ''),'Root fit review SHA256 required'
    review_path=Path(args.fit_review or '').resolve()
    assert review_path.is_file() and sha(review_path)==args.fit_review_sha256,'Root fit review missing or changed'
    review=json.loads(review_path.read_text(encoding='utf-8-sig'))
    assert review['reviewer']=='root' and review['decision']=='ACCEPTED_FOR_SAVED_FIT_STA'
    assert Path(review['fit_directory']).resolve()==FIT.resolve()
    assert review['constraint_disposition']=='FIXED_OLD_PROFILE_MODE_PATHS_FULLY_TIMED'
    evidence={name:sha(FIT/name) for name in EVIDENCE}
    assert all(review['evidence_sha256'].get(name)==digest for name,digest in evidence.items()),'Root review does not bind every terminal/report prerequisite'
    assert evidence['result.json']==args.fit_result_sha256 and evidence['input-manifest.json']==FIT_MANIFEST_SHA
    assert evidence['frozen-pins.json']==FIT_FROZEN_PINS_SHA
    fitted=json.loads((FIT/'result.json').read_text())
    assert fitted['state']=='terminal' and fitted['launcher_success'] and fitted['flow_exit_code']==0
    assert fitted['all_job_processes_terminal'] and fitted['all_handles_closed'] and fitted['errors']==[]
    assert 'input_hashes_after' in fitted
    fit_plan=json.loads((FIT/'input-manifest.json').read_text())
    assert fit_plan['source_commit']==PIN and fit_plan['project']==fit_plan['revision']=='STV_DS'
    assert fit_plan['limits']==FIT_LIMITS
    assert fit_plan['source_files']['sys/sys_top.sdc']['sha256']=='ca42b002f0b2bd7e201a1363c2a16078945a5ebe63112425fedd750e89af3a62'
    assert fit_plan['source_files'][QSF]['sha256']=='c08630d2d79bcb8450308ada18b11ad688950c97dd5ff11c6aac86144c0d1afb'
    assert fit_plan['source_review_sha256']=='735286ac878d801091284690091dbd6cbd12ad92d2ebe4c473234129048d06f3'
    source_review_path=Path(fit_plan['source_review_path'])
    assert sha(source_review_path)==fit_plan['source_review_sha256'],'Root fixed old-profile source/constraint-disposition review changed'
    source_review=json.loads(source_review_path.read_text(encoding='utf-8-sig'))
    assert source_review['reviewer']=='root' and source_review['decision']=='ACCEPTED_OLD_GAME_HDMI_CONTROL_R2_FOR_COMPILE'
    assert source_review['source_commit']==PIN and source_review['source_code_identity']==PIN and source_review['base_commit']=='b75f7c175dad7fcc9c685ba776f6aa673e2a4d6e'
    assert fit_plan['source_code_identity']==source_review['source_code_identity']
    assert source_review['timing_acceptance'] is False and source_review['hardware_acceptance'] is False
    for name,digest in json.loads((FIT/'frozen-pins.json').read_text()).items():assert sha(FIT/name)==digest,'Frozen full-flow input changed: '+name
    integrity=json.loads((FIT/'integrity-readback.json').read_text())
    metadata_case=fitted['changed_bound_inputs']!={}
    metadata_delta=None
    if metadata_case:
        audit_name=safe_evidence_name(review['metadata_only_qsf_audit'])
        audit_sha=sha(FIT/audit_name)
        assert review['evidence_sha256'].get(audit_name)==audit_sha,'Root review must bind exact QSF metadata audit'
        audit=json.loads((FIT/audit_name).read_text(encoding='utf-8-sig'))
        assert audit['reviewer']=='root' and audit['decision']=='EXACT_LAST_QUARTUS_VERSION_AND_LF_TO_CRLF_ONLY'
        assert audit['all_other_protected_inputs_unchanged'] is True
        before_map=fitted['input_hashes_before'];after_map=fitted['input_hashes_after']
        before=fit_plan['source_files'][QSF]['sha256'];after=sha(FIT/'tree'/QSF)
        delta={QSF:dict(before=before,after=after)}
        assert fitted['changed_bound_inputs']==integrity['bound_source_changes']==delta
        assert audit['qsf_before_sha256']==before and audit['qsf_after_sha256']==after
        assert set(before_map)==set(after_map) and before_map[QSF]==before and after_map[QSF]==after
        assert all(after_map[name]==digest for name,digest in before_map.items() if name!=QSF)
        assert integrity['adapter_success'] is False and integrity['source_integrity_ok'] is False
        with zipfile.ZipFile(FIT/'upstream-inputs.zip') as archive:old_qsf=archive.read(QSF)
        old_literal=b'set_global_assignment -name LAST_QUARTUS_VERSION "25.1std.0 Standard Edition"'
        new_literal=b'set_global_assignment -name LAST_QUARTUS_VERSION "25.1std.0 Lite Edition"'
        assert hashlib.sha256(old_qsf).hexdigest()==before=='c08630d2d79bcb8450308ada18b11ad688950c97dd5ff11c6aac86144c0d1afb'
        assert b'\r' not in old_qsf and old_qsf.count(b'\n')>0,'Archived QSF must be verified LF-only'
        assert old_qsf.count(old_literal)==1
        expected_qsf=old_qsf.replace(old_literal,new_literal,1).replace(b'\n',b'\r\n')
        assert (FIT/'tree'/QSF).read_bytes()==expected_qsf,'QSF differs beyond the exact version literal and LF-to-CRLF transformation'
        evidence[audit_name]=audit_sha
        metadata_delta=dict(path=QSF,before_sha256=before,after_sha256=after,audit_file=audit_name,audit_sha256=audit_sha,
            raw_adapter_success=False,raw_source_integrity_ok=False,raw_scheduler_exit_code=1,
            line_ending_conversion='Verified LF-only archive to CRLF, every newline converted exactly once',
            before_lf_count=old_qsf.count(b'\n'),after_crlf_count=expected_qsf.count(b'\r\n'),
            scope='Exact LAST_QUARTUS_VERSION replacement plus verified LF-to-CRLF conversion only; all raw full-flow receipts preserved')
    else:
        assert integrity['adapter_success'] and integrity['source_integrity_ok'] and integrity['bound_source_changes']=={}
    assert integrity['generated_build_id_matches_upstream_contract']
    expected_adapter_exit=1 if metadata_case else 0
    assert json.loads((FIT/'scheduler-action-exit.json').read_text(encoding='utf-8-sig'))['exit_code']==expected_adapter_exit
    cleanup=json.loads((FIT/'terminal-task-cleanup.json').read_text(encoding='utf-8-sig'))
    assert cleanup['task_name']==fit_plan['scheduler']['task_name'] and cleanup['exact_task_unregistered']
    assert cleanup['all_job_processes_terminal'] and cleanup['all_handles_closed'] and cleanup['errors']==[]
    assert cleanup['remaining_owned_or_quartus_processes']==[] and cleanup['last_task_result']==expected_adapter_exit
    summary=(FIT/'tree/output_files/STV_DS.fit.summary').read_text(encoding='latin-1')
    assert 'Fitter Status : Successful' in summary and 'Timing Models : Final' in summary and '5CSEBA6U23I7' in summary
    assert (FIT/'tree/output_files/STV_DS.fit.rpt').stat().st_size>10000
    for name,row in fit_plan['source_files'].items():
        expected=metadata_delta['after_sha256'] if metadata_case and name==QSF else row['sha256']
        assert sha(FIT/'tree'/name)==expected,'Completed source changed: '+name
    inventory_name=safe_evidence_name(review['fit_input_inventory'])
    assert review['evidence_sha256'].get(inventory_name)==sha(FIT/inventory_name),'Root must bind actual completed-fit database inventory'
    inventory=json.loads((FIT/inventory_name).read_text(encoding='utf-8-sig'))
    assert inventory['reviewer']=='root' and inventory['decision']=='ACCEPTED_SAVED_FIT_INPUT_INVENTORY'
    assert inventory['source_commit']==PIN and inventory['project']==inventory['revision']=='STV_DS'
    for key in INVENTORY_KEYS:
        assert isinstance(inventory[key],list) and inventory[key] and len(inventory[key])==len(set(inventory[key]))
        for name in inventory[key]:safe_evidence_name(name)
    assert set(inventory['primary_cmp_names'])<=set(inventory['fit_database_names'])
    assert set(inventory['files_sha256'])==set().union(*(set(inventory[key]) for key in INVENTORY_KEYS))
    evidence[inventory_name]=sha(FIT/inventory_name)
    no_overlap()
    return review_path,evidence,fit_plan,metadata_delta,inventory

def seed_prerequisites(args,fit_review_path):
    no_overlap()
    assert re.fullmatch('[0-9a-f]{64}',args.seed_review_sha256 or ''),'Root seed2 qualification admission SHA required'
    path=Path(args.seed_review or '').resolve();assert path.is_file() and sha(path)==args.seed_review_sha256
    review=json.loads(path.read_text(encoding='utf-8-sig'))
    assert review['reviewer']=='root' and review['decision']=='ACCEPTED_SEED02_FITTER_QUALIFICATION'
    assert review['source_commit']==PIN and review['seed']==2 and review['further_seed_needed'] is True
    assert review['timing_acceptance'] is False and review['fit_review_sha256']==sha(fit_review_path)
    assert Path(review['fit_directory']).resolve()==FIT.resolve() and Path(review['seed1_sta_directory']).resolve()==SEED1_STA.resolve()
    timing_path=Path(review['seed1_allcorner_review_path']).resolve()
    assert sha(timing_path)==review['seed1_allcorner_review_sha256']
    timing=json.loads(timing_path.read_text(encoding='utf-8-sig'))
    assert timing['reviewer']=='root' and timing['source_commit']==PIN and timing['timing_acceptance'] is False
    names=('result.json','sta-manifest.json','frozen-pins.json','preservation-readback.json',
        'scheduler-action-exit.json','terminal-task-cleanup.json','reports/corner-inventory.tsv',
        'reports/clock-check-coverage.tsv','reports/global-check-coverage.tsv','reports/old-mode-check-coverage.tsv')
    evidence={name:sha(SEED1_STA/name) for name in names}
    for name,digest in evidence.items():assert review['seed1_sta_evidence_sha256'].get(name)==digest,'Root must bind seed1 all-corner evidence: '+name
    result=json.loads((SEED1_STA/'result.json').read_text());m=json.loads((SEED1_STA/'sta-manifest.json').read_text())
    assert result['state']=='terminal' and result['flow_exit_code']==0 and result['launcher_success']
    assert result['all_job_processes_terminal'] and result['all_handles_closed'] and result['errors']==[] and result['final_job_active_processes']==0
    assert m['source_commit']==PIN and Path(m['fitted_directory']).resolve()==FIT.resolve() and m['limits']==LIMITS
    cleanup=json.loads((SEED1_STA/'terminal-task-cleanup.json').read_text(encoding='utf-8-sig'))
    assert cleanup['task_name']==m['scheduler']['task_name'] and cleanup['exact_task_unregistered']
    assert cleanup['all_job_processes_terminal'] and cleanup['all_handles_closed'] and cleanup['errors']==[]
    assert cleanup['remaining_owned_or_quartus_processes']==[] and cleanup['last_task_result']==0
    assert json.loads((SEED1_STA/'scheduler-action-exit.json').read_text(encoding='utf-8-sig'))['exit_code']==0
    readback=json.loads((SEED1_STA/'preservation-readback.json').read_text())
    assert readback['original_fitted_files_changed']==[] and readback['original_fitted_files_added']==[]
    assert readback['protected_source_generated_map_primary_cmp_changes']=={} and readback['coverage_error'] is None
    assert readback['coverage']['complete_dynamic_row_counts'] and readback['coverage']['old_mode_complete_dynamic_rows'] and readback['coverage']['old_mode_diagnostic_reports_complete']
    no_overlap()
    return dict(seed_review_path=str(path),seed_review_sha256=sha(path),seed1_allcorner_review_path=str(timing_path),
        seed1_allcorner_review_sha256=sha(timing_path),seed1_sta_directory=str(SEED1_STA),seed1_sta_evidence_sha256=evidence)


def seed02_qsf(original):
    lines=original.splitlines(keepends=True)
    matches=[i for i,line in enumerate(lines) if line.rstrip(b'\r\n')==b'set_global_assignment -name SEED 1']
    assert len(matches)==1,'Exactly one stored SEED1 line required'
    lines[matches[0]]=lines[matches[0]].replace(b'SEED 1',b'SEED 2',1)
    return b''.join(lines)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--fit-result-sha256');parser.add_argument('--fit-review');parser.add_argument('--fit-review-sha256')
    parser.add_argument('--seed-review');parser.add_argument('--seed-review-sha256');args=parser.parse_args()
    assert Path(sys.executable).resolve()==PYTHON.resolve()
    assert sha(LAB/'scripts/quartus_job_guard.py')==sha(BASE/'quartus_job_guard.py')==GUARD_SHA
    assert sha(BASE/'fit_only.tcl')==TCL_SHA and sha(SEED_PLAN)==SEED_PLAN_SHA and sha(CONSTRAINTS)==CONSTRAINTS_SHA
    assert json.loads(SEED_PLAN.read_text(encoding='utf-8-sig'))['candidate_commit']==PIN
    plan=dict(state='template-only-no-live-tree-read-copy-freeze-task-or-native-job',source_commit=PIN,seed=2,
        fitted_directory=str(FIT),fitted_manifest_sha256=FIT_MANIFEST_SHA,fitted_frozen_pins_sha256=FIT_FROZEN_PINS_SHA,
        command=[str(SHELL),'-t',str(BASE/'fit_only.tcl')],limits=LIMITS,
        gates=['Accepted terminal seed1 fullflow/source/QSF metadata/actual inventory/task cleanup',
            'Completed seed1 all-corner root result and explicit further_seed_needed admission',
            'Fresh complete terminal FULLFIT copy, exact stored QSF SEED1-to2 patch, root frozen-copy review and fresh admission'],
        copy_policy='All db/incremental_db dependencies retained; prior-fit caches honestly present, not pristine A&S-only',
        qualification='Actual placement seed2; no Post-Fit netlist input; zero requested/achieved placement/routing preservation; fitter-only execution and source/generated/map/date integrity',
        copied_RBF_STA='Inherited only; never a new seed2 result',timing_acceptance=False)
    if not args.prepare:print(json.dumps(plan,indent=2));return 0
    for name in ('tree','fit-manifest.json','copied-files.json','seed-start-files.json','frozen-pins.json'):assert not (BASE/name).exists(),'Preserve existing preparation: '+name
    review_path,evidence,fit_plan,metadata_delta,inventory=prerequisites(args)
    seed_proof=seed_prerequisites(args,review_path)
    copied=snapshot(FIT/'tree');assert copied
    for name,digest in inventory['files_sha256'].items():assert copied[name]['sha256']==digest
    assert {name for name in fit_plan['generated_files'] if name in copied}<=set(inventory['generated_names'])
    assert 'build_id.v' in inventory['generated_names'] and copied['build_id.v']['sha256']
    tree=BASE/'tree';tree.mkdir()
    for name,row in copied.items():
        target=tree/name;target.parent.mkdir(parents=True,exist_ok=True)
        with (FIT/'tree'/name).open('rb') as incoming,target.open('xb') as outgoing:shutil.copyfileobj(incoming,outgoing)
        assert sha(target)==row['sha256']
    assert snapshot(FIT/'tree')==copied,'Original fullfit changed during complete copy'
    qsf=tree/QSF;before=qsf.read_bytes();qsf.write_bytes(seed02_qsf(before))
    seed_start=snapshot(tree);expected_delta={QSF:dict(before_sha256=copied[QSF]['sha256'],after_sha256=seed_start[QSF]['sha256'])}
    actual_delta={name:dict(before_sha256=row['sha256'],after_sha256=seed_start[name]['sha256']) for name,row in copied.items() if seed_start[name]['sha256']!=row['sha256']}
    assert set(seed_start)==set(copied) and actual_delta==expected_delta
    assert snapshot(FIT/'tree')==copied,'Original fullfit changed during seed patch'
    save(BASE/'copied-files.json',copied);save(BASE/'seed-start-files.json',seed_start)
    scheduler=dict(fit_plan['scheduler']);scheduler.update(task_name='CoreLab-Shienryu-OldProfile-R2-Seed02-Fit-Q251-R1',
        working_directory=str(BASE),action_source='scheduler-action-inline.ps1',registration_source='register-start-inline.ps1',
        action_source_sha256=sha(BASE/'scheduler-action-inline.ps1'),registration_source_sha256=sha(BASE/'register-start-inline.ps1'))
    m=dict(state='prepared-root-accepted-seed02-fit-not-launched',prepared_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        source_commit=PIN,project='STV_DS',revision='STV_DS',seed=2,fitted_directory=str(FIT),fitted_evidence_sha256=evidence,
        fit_review_path=str(review_path),fit_review_sha256=sha(review_path),accepted_input_metadata_delta=metadata_delta,
        source_review_path=fit_plan['source_review_path'],source_review_sha256=fit_plan['source_review_sha256'],
        seed_plan_path=str(SEED_PLAN),seed_plan_sha256=SEED_PLAN_SHA,
        copied_file_count=len(copied),copied_bytes=sum(row['bytes'] for row in copied.values()),copied_manifest_sha256=sha(BASE/'copied-files.json'),
        seed_start_manifest_sha256=sha(BASE/'seed-start-files.json'),intentional_seed_delta=expected_delta,
        source_names=sorted(fit_plan['source_files']),guard_sha256=GUARD_SHA,fit_tcl_sha256=TCL_SHA,
        tool_bindings={str(path):sha(path) for path in (PYTHON,SHELL)},limits=LIMITS,scheduler=scheduler,command=plan['command'],
        operation='Only fitter from preserved complete seed1 database with exact QSF seed2 patch; no map/preflow/asm/STA/clock/constraint/RTL change',
        inherited_outputs_are_not_seed02_results=True,prior_fit_caches_present=True,timing_acceptance=False)
    m.update(seed_proof);m.update({key:inventory[key] for key in INVENTORY_KEYS});save(BASE/'fit-manifest.json',m)
    save(BASE/'frozen-pins.json',{name:sha(BASE/name) for name in (*SCRIPTS,'fit-manifest.json','copied-files.json','seed-start-files.json')})
    print(json.dumps(dict(state=m['state'],copied_files=len(copied),frozen_pins_sha256=sha(BASE/'frozen-pins.json'),no_task_or_native_launch=True),indent=2));return 0


if __name__=='__main__':raise SystemExit(main())
