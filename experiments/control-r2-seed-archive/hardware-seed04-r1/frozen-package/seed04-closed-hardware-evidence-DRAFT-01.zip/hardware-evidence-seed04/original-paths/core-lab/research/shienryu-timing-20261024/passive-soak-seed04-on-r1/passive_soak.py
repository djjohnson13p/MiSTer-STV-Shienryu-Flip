"""One-hour passive frame sampling. No inputs, ownership changes or device writes."""
import argparse, base64, hashlib, importlib.util, json, sys, time
from pathlib import Path
sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
CORE = OUT.parent / 'candidate-hardware-oldprofile-seed04'
REVIEW = OUT.parent / 'candidate-hardware-oldprofile-seed04-gameplay-r1/ROOT-GAMEPLAY-REVIEW.json'
SHA = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def run(expected_script):
    assert SHA(Path(__file__)) == expected_script
    assert SHA(REVIEW) == '7b8f50fa1e247aa5ebc278748de6a2507d1e00534eb670ed8e5541b2d32d14dc'
    assert SHA(CORE / 'candidate_hardware.py') == 'ae9daa6516c2fd3be0bde3126c54d29b4b7c7424c34a3bf916a01ca292ef1a0b'
    spec = importlib.util.spec_from_file_location('seed4_frozen_helper', CORE / 'candidate_hardware.py')
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    helper.verified_ready(); h = helper.baseline(); api = h.api()
    review = json.loads(REVIEW.read_text()); epoch = review['last_closed_epoch']
    journal = OUT / 'result.json'
    record = dict(state='STARTED', started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                  script_sha256=expected_script, gameplay_review_sha256=SHA(REVIEW),
                  intended_seconds=3600, samples=[], control_acquisitions=0, inputs=0,
                  device_writes=0, physical_HDMI_or_audio_verified=False)
    with journal.open('x', encoding='utf-8') as f: json.dump(record, f, indent=2)
    def save():
        temp = journal.with_suffix('.tmp'); temp.write_text(json.dumps(record, indent=2)+'\n'); temp.replace(journal)
    started = time.monotonic()
    try:
        with api.device() as (c, sf):
            def identity():
                state = api.state(c); g = state['game']; record['latest_state'] = h.slim(state)
                return (api.idle(state['control'], 'user', epoch) and
                        g.get('core_path') == helper.RBF and g.get('game_path') == helper.MRA and not g.get('error'))
            for at in [0, 300, 900, 1800, 3600]:
                while time.monotonic()-started < at:
                    if not identity():
                        record['state'] = 'STOPPED_ON_CONTROL_OR_CORE_CHANGE_NOT_A_CRASH_DIAGNOSIS'; return
                    time.sleep(min(10, max(0, at-(time.monotonic()-started))))
                if not identity():
                    record['state'] = 'STOPPED_ON_CONTROL_OR_CORE_CHANGE_NOT_A_CRASH_DIAGNOSIS'; return
                response = c.request({'mister': 'screenshot'})
                assert response.get('success') is True
                raw = base64.b64decode(response['data'], validate=True)
                assert raw.startswith(b'\x89PNG\r\n\x1a\n') and len(raw) == response['size'] and len(raw) < 8*1024*1024
                dest = OUT / ('sample-%04d.png' % at)
                with dest.open('xb') as f: f.write(raw)
                assert identity(), 'State changed during passive capture; do not infer crash'
                item = dict(target_seconds=at, actual_seconds=round(time.monotonic()-started, 3),
                            file=str(dest), sha256=SHA(dest), scope='Pre-ascal frame only; root visual review pending')
                record['samples'].append(item); save(); print(json.dumps(item), flush=True)
            record['state'] = 'FIVE_PASSIVE_SAMPLES_COMPLETED_ROOT_REVIEW_PENDING'
    except Exception as error:
        record.update(state='INCONCLUSIVE_OBSERVATION_ERROR_NOT_A_CRASH_DIAGNOSIS', error=repr(error))
    finally:
        record['elapsed_seconds'] = round(time.monotonic()-started, 3); save()
        print(json.dumps({'state': record['state'], 'samples': len(record['samples'])}), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--execute-reviewed-sha256')
    args = parser.parse_args()
    if args.execute_reviewed_sha256: run(args.execute_reviewed_sha256)
    else: print(json.dumps({'local_only': True, 'script_sha256': SHA(Path(__file__)), 'device_access': False}))
