"""Bounded unchanged STV baseline observation using existing pinned transport.
Default prepares local fixtures only. Inventory is read-only. Each live phase
has an exclusive journal, one acquisition, matching IDs and same-epoch cleanup.
"""
import argparse, base64, hashlib, importlib.util, json, re, shlex, stat, struct, sys, time, uuid
from pathlib import Path
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
LAB=OUT.parents[2]
ROOT=LAB.parent
SOURCE=LAB/'builds/shienryu-upstream-q251-baseline-r1/tree/output_files/STV_DS.rbf'
OLD=OUT.parent/'preserved-originals/Shienryu stv_flip_v1.1_rc1.mra'
RBF='/media/fat/_Arcade/cores/STVB0001.rbf'
MRA='/media/fat/_Arcade/_CoreLab/STVB0001.mra'
MAP='/media/fat/config/inputs/STVB0001_input_4711_0815_v3.map'
MENU='/media/fat/menu.rbf'
WORDS=tuple([106,105,108,103,29,56,0,0,0,0,2,6,0,0]+[0]*18)
HELPERS={ROOT/'core-lab/scripts/run_megacd_payload_pair.py':'fc9837d0cce23f6bf468967d39b9c21055e52f54e19210e5619db5d8c763c9cd',Path('C:/Users/djjoh/MiSTer-Rebuild/Tools/mister_control.py'):'78f46677ece7b9582dc86e3d53bf6c64bfed8c7f48d3e8ea16b3c15bcb998789'}
KNOWN={'/media/fat/_Arcade/cores/stv_flip_v1.1_rc1.rbf':'bf1a726b0e7ac5e41a8262ea1db54bcc613c56355dcb0e4bcce5826820044b31','/media/fat/_Arcade/Shienryu stv_flip_v1.1_rc1.mra':'0e9c0a8422fe419a458c8ad8673555acc4500fca7aa19e93985096353efd813e','/media/fat/games/mame/shienryu.zip':'b2952de90d28dedfffe41776d2fde56344fe008ae7334ebfe4ef5f15d7cabd0c','/media/fat/games/mame/stvbios.zip':'1c4970da5f7066dd213d3dca14f7e45408cf667f508f4653025626bb33fbeb14'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def must(ok,msg):
    if not ok:raise RuntimeError(msg)
def save(path,value,exclusive=False):
    with path.open('x' if exclusive else 'w',encoding='utf-8') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def slim(s):return {'game':s['game'],'control':{k:s['control'].get(k) for k in ('success','mode','epoch','active_input','active_action','cleanup_error','transition_in_progress')}}
def api():
    for p,h in HELPERS.items():must(sha(p.read_bytes())==h,'Existing helper changed: '+str(p))
    spec=importlib.util.spec_from_file_location('existing_stv_transport',ROOT/'core-lab/scripts/run_megacd_payload_pair.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);return a
def shell(c,command):
    with c.transport.open_session(timeout=10) as ch:
        ch.settimeout(30);ch.exec_command(command)
        out=ch.makefile('rb').read(2000000).decode();err=ch.makefile_stderr('rb').read(2000).decode(errors='replace')
        must(ch.recv_exit_status()==0,'Read-only device check failed: '+err);return out
def hashes(c,paths):
    paths=sorted(set(paths));must(0<len(paths)<2000,'Unexpected protected inventory size')
    text=shell(c,'sha256sum -- '+' '.join(shlex.quote(p) for p in paths))
    got={line.split(None,1)[1].strip():line.split(None,1)[0] for line in text.splitlines()};must(set(got)==set(paths),'Hash response path mismatch');return got
def names(c):return shell(c,'find /media/fat/config /media/fat/saves -type f -print').splitlines()
def original_members(c):
    selected=[]
    for p in names(c):
        low=p.lower()
        if 'stvb0001' in low:continue
        if low.startswith('/media/fat/config/inputs/') or low.endswith('.map') or re.search(r'stv|st-v|shienryu|saturn',low):selected.append(p)
    return sorted(set(selected))
def snapshot(c):
    paths=original_members(c);extra=set(KNOWN)|{'/media/fat/MiSTer','/media/fat/MiSTer.ini',MENU}
    return {'membership':paths,'hashes':hashes(c,set(paths)|extra)}
def protect(c,inv):
    now=snapshot(c);must(now==inv['originals'],'Protected original hashes or membership changed');return now
def identity(a,s,mode,epoch=None,where='MENU'):
    must(a.idle(s['control'],mode,epoch),'Unexpected control state/epoch')
    g=s['game']
    if where=='MENU':must(g.get('core_name','').upper()=='MENU' and not g.get('game_path') and g.get('core_path') in ('',MENU,'menu.rbf'),'Expected idle Menu')
    else:must(g.get('core_path')==RBF and g.get('game_path')==MRA and not g.get('error'),'Unexpected baseline identity')
def local():
    must(sha(SOURCE.read_bytes())=='2bad41a6e2bd52078f5a8fffff85640a416332364c4c1721ff7496735d2660d4' and SOURCE.stat().st_size==4591232,'Baseline RBF differs')
    must(sha(OLD.read_bytes())==KNOWN['/media/fat/_Arcade/Shienryu stv_flip_v1.1_rc1.mra'],'Preserved MRA differs')
    meta=load(LAB/'builds/shienryu-upstream-q251-baseline-r1/qsf-version-metadata-review.json')
    must(meta['native_flow_exit_code']==0 and meta['whole_file_equality_to_exact_transformation'] and meta['all_other_protected_inputs_unchanged'],'Root build provenance review differs')
    a=ET.fromstring(OLD.read_bytes());before=[ET.tostring(x) for x in a if x.tag not in ('rbf','setname','description')]
    a.find('rbf').text='STVB0001';a.find('setname').text='STVB0001';a.find('description').text='CoreLab Shienryu unchanged current STV baseline STVB0001'
    must(before==[ET.tostring(x) for x in a if x.tag not in ('rbf','setname','description')],'MRA semantics changed')
    fixtures={'STVB0001.mra':(ET.tostring(a,encoding='utf-8',xml_declaration=True)+b'\n',MRA),'STVB0001_input_4711_0815_v3.map':(struct.pack('<32I',*WORDS),MAP)}
    if not (OUT/'fixture-manifest.json').exists():
        files={}
        for name,(raw,remote) in fixtures.items():
            with (OUT/name).open('xb') as f:f.write(raw)
            files[name]={'bytes':len(raw),'sha256':sha(raw),'remote':remote}
        files['STVB0001.rbf']={'local':str(SOURCE),'bytes':SOURCE.stat().st_size,'sha256':sha(SOURCE.read_bytes()),'remote':RBF}
        save(OUT/'fixture-manifest.json',{'schema':'STVB0001-BASELINE-FIXTURES-1','files':files,'input_map_words':WORDS,'timing_accepted':False,'purpose':'Root-authorized unchanged baseline boot/behavior experiment; initial corner setup fails -1.248ns. No improvement or timing-pass claim.'},True)
    m=load(OUT/'fixture-manifest.json')
    must(tuple(m['input_map_words'])==WORDS and 42 not in WORDS,'Unexpected map/neutral-key binding')
    for name,item in m['files'].items():
        raw=Path(item.get('local',OUT/name)).read_bytes();must(len(raw)==item['bytes'] and sha(raw)==item['sha256'],'Local fixture changed: '+name)
    api();return m
def inventory(a):
    must(not (OUT/'device-inventory.json').exists(),'Inventory already recorded; do not overwrite')
    with a.device() as (c,sf):
        before=a.state(c);identity(a,before,'user')
        must(not any(re.search(r'stv[bc]0001',p,re.I) for p in names(c)),'Reserved config/save namespace already exists')
        for folder in ('/media/fat/_Arcade/cores','/media/fat/_Arcade/_CoreLab'):
            for name in sf.listdir(folder):must(not re.match(r'(?:Arcade-)?STV[BC]0001(?:[._]|$)',name,re.I),'Reserved installed namespace collision')
        s={'schema':'STVB0001-DEVICE-INVENTORY-1','agent':'/root/shienryu_source_review','utc':time.time(),'state':slim(before),'originals':snapshot(c),'backups':{}}
        must(all(s['originals']['hashes'].get(p)==h for p,h in KNOWN.items()),'Known preserved artifact/ROM differs')
        selected=shell(c,"sed -n -e '/^[[:space:]]*controller_unique_mapping[[:space:]]*=/p' -e '/^[[:space:]]*jamma_vid[[:space:]]*=/p' -e '/^[[:space:]]*jamma_pid[[:space:]]*=/p' -e '/^[[:space:]]*keyrah_mode[[:space:]]*=/p' -e '/^[[:space:]]*video_mode[[:space:]]*=/p' /media/fat/MiSTer.ini")
        s['selected_nonsecret_ini_lines']=selected.splitlines()
        def v(key,default):
            matches=re.findall(r'^\s*'+key+r'\s*=\s*([^;\s]+)',selected,re.M);must(len(set(matches))<=1,'Ambiguous input setting '+key);return int(matches[0],0) if matches else default
        must(v('controller_unique_mapping',0)==0 and (v('jamma_vid',0),v('jamma_pid',0))!=(0x4711,0x0815) and v('keyrah_mode',0)!=0x47110815,'Input identity mapping cannot be safely assumed')
        for i,p in enumerate(s['originals']['membership']):
            must(sf.stat(p).st_size<2*1024*1024,'Protected setting unexpectedly large')
            with sf.open(p,'rb') as f:raw=f.read()
            must(sha(raw)==s['originals']['hashes'][p],'Protected file changed during backup')
            target=OUT/f'protected-{i:03d}.bin'
            with target.open('xb') as f:f.write(raw)
            s['backups'][p]={'local':target.name,'bytes':len(raw),'sha256':sha(raw)}
        identity(a,a.state(c),'user',before['control']['epoch']);protect(c,s)
        s['namespace_free']=True;save(OUT/'device-inventory.json',s,True)
    print(json.dumps({'read_only_inventory':True,'protected_settings':len(s['backups']),'known_originals_verified':True,'state':s['state']}))
def phase(a,m,kind):
    path=OUT/(kind+'-journal.json');must(not path.exists(),'This phase already attempted; do not replay')
    inv=load(OUT/'device-inventory.json')
    must(inv['originals']['hashes']['/media/fat/MiSTer']=='ba8746d91ced547845b743b7826d827cfd6c488de0bcf8b27112d8d77f8a7e27','Installed Main differs from the qualified map codec identity')
    s={'agent':'/root/shienryu_source_review','phase':kind,'started':time.time(),'result':'STARTED_DO_NOT_REPEAT','events':[],'captures':[]};save(path,s,True)
    def write():save(path,s)
    with a.device() as (c,sf):
        where='MENU' if kind=='stage-boot' else 'BASELINE'
        def guard():identity(a,a.state(c),'assistant',s['epoch'],where)
        def wire(payload,label):
            payload={**payload,'id':'STVB-'+uuid.uuid4().hex};e={'label':label,'payload':payload,'started':time.time()};s['events'].append(e);write();r=c.request(payload);e['reply']={k:v for k,v in r.items() if k!='data'};write();must(r.get('id')==payload['id'],'Reply ID differs; do not replay');return r
        def completed(r):must(r.get('success') is True and r.get('status')=='completed' and r.get('action_id')==r.get('id'),'Action outcome uncertain; do not replay')
        def capture(label,settle=0):
            guard();time.sleep(settle);guard();r=c.request({'mister':'screenshot'});must(r.get('success') is True,'Screenshot failed')
            raw=base64.b64decode(r['data'],validate=True);must(raw.startswith(b'\x89PNG\r\n\x1a\n') and len(raw)==r['size'] and len(raw)<8*1024*1024,'Bad screenshot')
            p=OUT/(label+'.png')
            with p.open('xb') as f:f.write(raw)
            s['captures'].append({'label':label,'file':p.name,'sha256':sha(raw),'bytes':len(raw),'utc':time.time(),'scope':'Pre-output-flip framebuffer; no HDMI orientation/OSD/audio proof'});write();guard()
        def press(key,ms):
            guard();type(c).request.__globals__['preflight_input'](a.state(c)['control'],ms);completed(wire({'mister':'input','device':'keyboard','key':key,'duration_ms':ms},'bounded-key-'+key));guard()
        def change_load(dest):
            nonlocal where
            guard();completed(wire({'mister':'load_core','path':MRA if dest=='BASELINE' else MENU},'one-load-'+dest))
            until=time.monotonic()+75
            while time.monotonic()<until:
                cur=a.state(c);must(a.idle(cur['control'],'assistant',s['epoch']),'Ownership changed during load')
                try:identity(a,cur,'assistant',s['epoch'],dest);where=dest;return
                except RuntimeError:pass
                must(cur['game'].get('core_path') in ('',MENU,'menu.rbf',RBF),'Unexpected core during load');time.sleep(1)
            raise RuntimeError('Initial load readiness observation expired; do not replay')
        def staged_check():
            want={item['remote']:item['sha256'] for item in m['files'].values()};must(hashes(c,want)==want,'Staged hash changed')
            must(a.rbf_candidates(sf,RBF)==['STVB0001.rbf'],'Ambiguous baseline RBF prefix')
        try:
            identity(a,a.state(c),'user',where=where);protect(c,inv)
            if kind=='stage-boot':
                for item in m['files'].values():must(not a.remote_exists(sf,item['remote']),'Exclusive stage target occupied')
                must(not a.rbf_candidates(sf,RBF),'Baseline RBF prefix occupied')
            else:staged_check()
            s['pre_handoff_state']=slim(a.state(c));identity(a,s['pre_handoff_state'],'user',where=where)
            s['handoff_attempted']=True;write()
            h=wire({'mister':'control','action':'assistant'},'one-assistant-handoff')
            if h.get('success') and h.get('mode')=='assistant':s['epoch']=h.get('epoch');write()
            must(a.idle(h,'assistant'),'Handoff not idle');guard()
            if kind=='stage-boot':
                for parent in ('/media/fat/_Arcade/_CoreLab','/media/fat/config/inputs'):
                    guard()
                    if not a.remote_exists(sf,parent):sf.mkdir(parent)
                    must(stat.S_ISDIR(sf.lstat(parent).st_mode),'Stage parent not ordinary directory')
                for name,item in m['files'].items():
                    guard();must(not a.remote_exists(sf,item['remote']),'Stage collision')
                    with sf.open(item['remote'],'wx') as f:
                        with Path(item.get('local',OUT/name)).open('rb') as src:
                            for b in iter(lambda:src.read(131072),b''):f.write(b)
                    s.setdefault('created_files',[]).append(item['remote']);write()
                staged_check();protect(c,inv);change_load('BASELINE');capture('baseline-00-boot',8);capture('baseline-01-attract',12)
            elif kind=='inputs':
                must(tuple(struct.unpack('<32I',(OUT/'STVB0001_input_4711_0815_v3.map').read_bytes()))==WORDS and 42 not in WORDS,'Neutral shift key mapped')
                press('leftshift',1)
                blocks=[b for b in shell(c,'cat /proc/bus/input/devices').split('\n\n') if 'N: Name="misterclaw"' in b]
                must(len(blocks)==1 and 'Bus=0003 Vendor=4711 Product=0815 Version=0001' in blocks[0] and 'kbd' in blocks[0],'Keyboard identity not proven');s['keyboard_identity']=blocks[0];write()
                capture('baseline-02-before-coin');press('5',80);capture('baseline-03-after-coin',0.5);press('1',100);capture('baseline-04-after-start',2)
                press('right',350);capture('baseline-05-right');press('left',700);capture('baseline-06-left');press('up',350);capture('baseline-07-up');press('down',700);capture('baseline-08-down');press('leftctrl',1200);capture('baseline-09-shot');press('leftalt',100);capture('baseline-10-bomb',0.3)
                change_load('MENU')
            elif kind=='finish':change_load('MENU')
            s['result']='CAPTURED_FOR_ROOT_REVIEW_NOT_FUNCTIONAL_OR_TIMING_PASS';staged_check()
        except BaseException as e:s['result']='STOPPED';s['error']=str(e)
        finally:
            errors=[]
            if s.get('handoff_attempted') and not s.get('epoch'):
                try:
                    observed=a.state(c);s['uncertain_acquisition_audit']=slim(observed)
                    if a.idle(observed['control'],'user'):
                        s['uncertain_acquisition_disposition']='User/idle observed; no acknowledged owned lease, no stage/load/input permitted.'
                    else:
                        s['recovery_required']='Handoff outcome uncertain and User/idle is not proven. Stop without stage/load/input; do not adopt or release an unattributed epoch. Root/manual control recovery required.'
                        errors.append(s['recovery_required'])
                except BaseException as e:
                    s['recovery_required']='Handoff outcome uncertain; read-only acquisition audit failed: '+str(e)
                    errors.append(s['recovery_required'])
                write()
            for operation in ('release_all','user'):
                try:
                    cur=a.state(c)
                    if s.get('epoch') and cur['control'].get('mode')=='assistant' and cur['control'].get('epoch')==s['epoch']:
                        r=wire({'mister':'control','action':operation},'final-'+operation);must(r.get('success') is True,'Cleanup not acknowledged')
                except BaseException as e:errors.append(operation+': '+str(e))
            try:
                final=a.state(c);s['final_state']=slim(final);must(a.idle(final['control'],'user'),'User/idle not proven');protect(c,inv);s['protected_original_hashes_and_membership_unchanged']=True
                if s['result'].startswith('CAPTURED'):identity(a,final,'user',where=where)
            except BaseException as e:errors.append('Final proof: '+str(e))
            s['cleanup_errors']=errors;s['finished']=time.time();write()
    print(json.dumps({k:s.get(k) for k in ('phase','result','error','cleanup_errors','final_state','protected_original_hashes_and_membership_unchanged')},indent=2))
    return 0 if s['result'].startswith('CAPTURED') and not s['cleanup_errors'] else 2
def main():
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['inventory','stage-boot','inputs','finish']);args=p.parse_args();m=local();a=api()
    if args.phase=='inventory':inventory(a);return 0
    if args.phase:return phase(a,m,args.phase)
    print(json.dumps({'local_only':True,'fixture_manifest_sha256':sha((OUT/'fixture-manifest.json').read_bytes()),'script_sha256':sha(Path(__file__).read_bytes()),'rbf_sha256':m['files']['STVB0001.rbf']['sha256'],'no_device_access':True}));return 0
if __name__=='__main__':raise SystemExit(main())
