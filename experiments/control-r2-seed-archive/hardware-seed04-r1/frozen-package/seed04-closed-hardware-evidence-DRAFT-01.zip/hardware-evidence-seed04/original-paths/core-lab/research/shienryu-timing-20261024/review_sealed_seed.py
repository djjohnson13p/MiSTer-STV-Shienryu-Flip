"""Read-only fixed-source seed audit; --record writes a new external root measurement."""
import argparse, datetime, hashlib, json, math
from pathlib import Path
HERE = Path(__file__).resolve().parent
LAB = HERE.parents[1]
BATCH = LAB / 'builds/shienryu-oldprofile-r2-seeds03-10-batch-r1'
SOURCE = '7e987bb9ef0361356be22be13551e4626902f3a7'
GUARD = '5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
def require(ok, message):
    if not ok: raise ValueError(message)
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def audit(seed, peer_sha, record=False):
    folder = BATCH / f'seeds/seed-{seed:02}'
    index = folder / 'preservation-index.json'
    require(index.is_file(), 'Not sealed: do not read an active seed')
    sealed = read(index)
    require(sealed['seed'] == seed and sealed['completed_native_sequence'] and sealed['source_commit'] == SOURCE, 'Wrong/incomplete source/seed')
    actual = {f.relative_to(folder).as_posix() for f in folder.rglob('*') if f.is_file()}
    require(actual == set(sealed['members']) | {'preservation-index.json'}, 'Sealed membership changed')
    for name, expected in sealed['members'].items():
        f = folder / name
        require(not f.is_symlink() and f.stat().st_size == expected['bytes'] and sha(f) == expected['sha256'], 'Sealed bytes changed: '+name)
    peer = HERE / f'OLDPROFILE-R2-SEED{seed:02}-ALL-CORNER-REPORT-REVIEW.json'
    require(peer.is_file() and sha(peer) == peer_sha, 'Independent review absent/changed')
    proofs = {}
    for stage in ('fit', 'asm', 'sta'):
        r = read(folder / stage / 'result.json')
        require(r['flow_exit_code'] == 0 and r['all_job_processes_terminal'] and r['all_handles_closed'] and not r['errors'], 'Native stage did not close successfully: '+stage)
        require(r['launcher_sha256'] == GUARD and r['baseline_commit'] == SOURCE, 'Guard/source differs')
        before, after = r['input_hashes_before'], r['input_hashes_after']
        changed = {k for k in before if before[k] != after[k]}
        permitted = {'db/STV_DS.tiscmp.fastest_slow_1100mv_85c.ddb'} if stage == 'sta' else set()
        require(set(before) == set(after) and changed == set(r['changed_bound_inputs']) and changed <= permitted, 'Unexpected bound input mutation: '+stage)
        reference = read(BATCH / 'seeds/seed-04' / stage / 'result.json')['input_hashes_before']
        require(set(before) == set(reference), 'Source/clock/constraint input inventory differs')
        require(all(before[k] == reference[k] for k in before if k != 'STV_DS.qsf' and not k.startswith('db/')), 'Protected source/map/date/clock/constraint differs')
        previous_qsf = (BATCH / 'seeds/seed-04' / stage / 'tree/STV_DS.qsf').read_bytes()
        qsf = (folder / stage / 'tree/STV_DS.qsf').read_bytes()
        require(previous_qsf.count(b'set_global_assignment -name SEED 4') == 1 and qsf == previous_qsf.replace(b'set_global_assignment -name SEED 4', f'set_global_assignment -name SEED {seed}'.encode()), 'QSF changes exceed seed')
        for name, expected in after.items(): require(sha(folder / stage / 'tree' / name) == expected, 'Final bound bytes differ: '+name)
        proofs[stage] = {k:r[k] for k in ('flow_exit_code','elapsed_seconds','all_job_processes_terminal','all_handles_closed','errors','changed_bound_inputs')}
    fit = read(folder / 'fit/qualification.json')['qualification']
    require(fit['actual_placement_seed'] == seed and fit['no_post_fit_input'] and fit['zero_requested_and_achieved_placement_and_routing'], 'Native fit seed/preservation differs')
    assembly = read(folder / 'asm/qualification.json')['qualification']
    require(assembly['passed'] and assembly['fresh_RBF_and_SOF'] and assembly['assembler_successful'], 'Assembly not qualified')
    for name, expected in assembly['outputs'].items():
        f = folder / 'asm/tree' / name
        require(f.stat().st_size == expected['bytes'] and sha(f) == expected['sha256'], 'Programming bytes changed')
    timing = read(folder / 'sta/qualification.json'); matrix = timing['timing_condition_matrix']; coverage = timing['coverage']
    require({(v['model'],v['temperature_C']) for v in matrix} == {(m,t) for m in ('slow','fast') for t in (-40,0,85,100)} and len(matrix) == 8, 'Eight conditions incomplete')
    for condition in matrix:
        for check in condition['checks'].values():
            v = check['slack_ns']; require(isinstance(v,(int,float)) and math.isfinite(v) and check['pass'] == (v >= 0), 'Invalid/nonfinite timing slack')
        pw = condition['minimum_pulse_width']; require(math.isfinite(pw['slack_ns']) and pw['reported_paths'] > 0, 'Pulse width evidence missing')
    require(coverage['clock_counts'] == [13]*8 and coverage['per_clock_rows'] == 416 and coverage['global_rows'] == 32 and coverage['zero_path_rows'] == 192 and coverage['old_mode_rows'] == 32, 'Reference coverage differs')
    result = dict(reviewer='root', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        decision=f'REVIEWED_SEED{seed:02}_MEASUREMENT_NOT_HARDWARE_ACCEPTANCE', source_commit=SOURCE, seed=seed,
        sealed_seed_folder=str(folder), seal_sha256=sha(index), all_sealed_members_independently_rehashed=len(sealed['members']),
        all3_protected_source_map_generated_date_clock_constraint_inputs_fixed=True, only_exact_seed4_to_N_QSF_delta=True,
        native_stage_proofs=proofs, coverage={k:coverage[k] for k in ('corners','per_clock_rows','global_rows','zero_path_rows','old_mode_rows')},
        actual_report_file_count=sum(f.is_file() for f in (folder/'sta/reports').rglob('*')),
        matrix=matrix, programming_outputs=assembly['outputs'], constraint_agent_review=str(peer), constraint_agent_review_sha256=peer_sha,
        qualified_clean_candidate=timing['qualified_clean_candidate'], full_board_signoff=timing['full_board_signoff'],
        fully_passing_conditions=sum(v['status']=='PASS' for v in matrix),
        root_admission_sha256=sealed['root_admission_sha256'], timing_acceptance=False, hardware_acceptance=False,
        bit_identical_rebuild_demonstrated=False, whole_batch_cleanup_not_implied=True)
    if record:
        target = HERE / f'ROOT-SEED{seed:02}-TIMING-RESULT.json'
        with target.open('x', encoding='utf-8') as f: json.dump(result,f,indent=2); f.write('\n')
        print(json.dumps({'result':str(target),'sha256':sha(target)}))
    print(json.dumps({'seed':seed,'members':len(sealed['members']),'matrix':[(v['model'],v['temperature_C'],v['checks']['setup']['slack_ns'],v['checks']['hold']['slack_ns'],v['status']) for v in matrix],'recorded':record}))
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--seed',type=int,choices=range(5,11),required=True)
    parser.add_argument('--peer-review-sha256',required=True); parser.add_argument('--record',action='store_true'); args=parser.parse_args()
    audit(args.seed,args.peer_review_sha256,args.record)
