"""UNFROZEN seed4 gameplay inputs/captures only. Default is local; no device access."""
import argparse,base64,hashlib,importlib.util,json,re,sys,time,uuid
from pathlib import Path
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
RESEARCH=OUT.parent
CORE=RESEARCH/'candidate-hardware-oldprofile-seed04'
MENU=RESEARCH/'candidate-hardware-oldprofile-seed04-menu-r1'
MENU_SCRIPT_SHA='ddb5270400ab6b554fa2d6ff35ddd32a5cc1ea483d983cbd0fd662815826fd29'
MENU_REVIEW_SHA='c4f44f95cfee1197924e0ccb2ed1359cf178a71fd1174a6a442641fff53b1e83'
MENU_JOURNAL_SHA='f563594cbb6d42a74f2831253c90551227dd9cc8b9a1a19bfaf45c9f91929243'
READY_SHA='0088198c749f2ec7ce635bf9cabdba9ce06d1a1e18412bc8be28a9705b1fc3d8'
RBF='/media/fat/_Arcade/cores/SHYF0004.rbf'
MRA='/media/fat/_Arcade/_CoreLab/SHYF0004.mra'
KEYS={'up','down','left','right','leftctrl','leftalt','1','5'}
def must(ok,msg):
    if not ok:raise RuntimeError(msg)
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def require(p,h):
    p=Path(p);must(p.is_absolute() and p.is_file() and not p.is_symlink() and sha(p)==h,'Bound ordinary file changed: '+str(p));return p
def save(p,v):
    temporary=p.with_suffix(p.suffix+'.tmp');temporary.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');temporary.replace(p)
def local():
    require(MENU/'menu_once.py',MENU_SCRIPT_SHA);require(MENU/'ROOT-MENU-RESULT.json',MENU_REVIEW_SHA)
    q=read(MENU/'ROOT-MENU-RESULT.json');must(q['reviewer']=='root' and q['decision']=='ACCEPTED_ACTUAL_MENU_CFG_OFF_ON_OFF_ONLY','Actual root menu result absent')
    must(q['ready_sha256']==READY_SHA and q['status82_sequence']==[False,True,False] and q['exact_byte10_mask04_only_delta'] and q['final_Off_equals_baseline_bytes'],'Wrong menu status proof')
    must(q['actual_Main_Save_side_effects_verified'] and q['final_User_idle'] and q['original35hash24membership_and_staged_files_unchanged'],'Menu/protection/cleanup incomplete')
    must(q['physical_HDMI_flip_OSD_orientation_audio_verified'] is False,'Do not relabel physical observations')
    require(q['journal'],MENU_JOURNAL_SHA);j=read(q['journal']);must(j['result']=='MENU_CFG_OFF_ON_OFF_PROVEN_PHYSICAL_OUTPUT_UNVERIFIED' and j['cleanup_errors']==[],'Menu did not finish safely')
    spec=importlib.util.spec_from_file_location('frozen_seed04_menu_local_gates',MENU/'menu_once.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    helper,h,r,boot=m.local();last=j['CFG_observations'][-1];extra={}
    for name in ('CFG','NVM'):
        item=last[name];must(isinstance(item,dict),'Menu CFG/NVM snapshot absent');require(item['local'],item['sha256']);extra[item['remote']]=item['sha256']
    must(last['status82'] is False and Path(last['CFG']['local']).read_bytes()==bytes(16) and last['NVM']['bytes']==65664,'DefaultOff/geometry gate differs')
    return helper,h,r,extra
def validate_action(path,digest,admission_path,admission_sha):
    require(path,digest);a=read(path);require(admission_path,admission_sha);q=read(admission_path)
    must(a['schema']=='SHYF0004-GAMEPLAY-ACTION-1' and a['state']=='ROOT_REVIEWED_ACTION','Unreviewed action')
    must(re.fullmatch('[a-z0-9][a-z0-9-]{0,47}',a['phase_id']) is not None,'Invalid phase ID')
    must(a['script_sha256']==sha(__file__) and a['ready_sha256']==READY_SHA and a['menu_result_sha256']==MENU_REVIEW_SHA,'Action bindings differ')
    must(type(a['expected_status82']) is bool,'Expected flip state must be explicit')
    must(isinstance(a['starting_user_epoch'],str) and str(uuid.UUID(a['starting_user_epoch']))==a['starting_user_epoch'],'Expected User epoch must be explicitly root-bound')
    must(type(a['max_seconds']) is int and 1<=a['max_seconds']<=240,'Phase bounds invalid')
    steps=a['steps'];must(isinstance(steps,list) and 1<=len(steps)<=24,'At most24 bounded steps')
    input_ms=settle_ms=0;labels=set()
    for step in steps:
        if step['kind']=='input':
            must(set(step)=={'kind','keys','duration_ms'},'Unexpected input fields');keys=step['keys'];ms=step['duration_ms']
            must(isinstance(keys,list) and 1<=len(keys)<=2 and len(keys)==len(set(keys)) and set(keys)<=KEYS,'Unsupported gameplay key/combo')
            must(not {'up','down'}<=set(keys) and not {'left','right'}<=set(keys),'Opposite directions forbidden')
            must(type(ms) is int and 1<=ms<=5000,'Input duration invalid');input_ms+=ms
        elif step['kind']=='capture':
            must(set(step)=={'kind','label','settle_ms'} and re.fullmatch('[a-z0-9][a-z0-9-]{0,47}',step['label']) is not None and step['label'] not in labels,'Invalid/duplicate capture label')
            must(type(step['settle_ms']) is int and 0<=step['settle_ms']<=15000,'Settle invalid');labels.add(step['label']);settle_ms+=step['settle_ms']
        else:raise RuntimeError('Only gameplay inputs and pre-ascal captures allowed')
    must(input_ms<=30000 and settle_ms<=60000,'Sequence exceeds existing bounds')
    must(q['reviewer']=='root' and q['decision']=='ACCEPTED_SEED04_GAMEPLAY_INPUT_CAPTURE_ONLY','Root admission absent')
    must(q['action_sha256']==digest and q['script_sha256']==sha(__file__) and q['ready_sha256']==READY_SHA and q['menu_result_sha256']==MENU_REVIEW_SHA,'Root admission does not bind action/evidence')
    must(q['actual_boot_and_menu_CFG_replace_manual_observation_for_gameplay'] is True and q['physical_HDMI_or_audio_acceptance'] is False,'Wrong observation scope')
    return a
def active_menu_state(a):
    require(a['active_menu_result_path'],a['active_menu_result_sha256']);q=read(a['active_menu_result_path'])
    must(q['reviewer']=='root' and q['ready_sha256']==READY_SHA and q['rbf_sha256']=='99654dbf7a472b610f840f9dbbb0087bc6f508ce3dfdfe2ffbd48e6df5396d11','Active menu proof not bound to seed4')
    must(q['actual_Main_Save_side_effects_verified'] and q['final_User_idle'] and q['physical_HDMI_flip_OSD_orientation_audio_verified'] is False,'Active menu proof incomplete or mislabeled')
    must(q['status82_sequence'] and q['status82_sequence'][-1] is a['expected_status82'],'Active menu proof differs from action flip expectation')
    require(q['journal'],q['journal_sha256']);j=read(q['journal']);must(j['cleanup_errors']==[],'Active menu cleanup failed')
    last=j['CFG_observations'][-1];must(last['status82'] is a['expected_status82'],'Menu journal state differs');extra={}
    for name in ('CFG','NVM'):
        item=last[name];require(item['local'],item['sha256']);extra[item['remote']]=item['sha256']
    cfg=Path(last['CFG']['local']).read_bytes();must(len(cfg)==16 and bool(cfg[10]&4)==a['expected_status82'] and all(value==0 for i,value in enumerate(cfg) if i!=10) and cfg[10]&251==0,'Unexpected active CFG/status bit delta')
    must(last['NVM']['bytes']==65664,'Active NVM geometry differs')
    return extra
def execute(action_path,action_sha,admission_path,admission_sha):
    helper,h,r,_=local();a=validate_action(action_path,action_sha,admission_path,admission_sha);extra=active_menu_state(a);api=h.api();protected=read(CORE/'cached-protection.json')
    phase=OUT/'phases'/a['phase_id'];must(not phase.exists(),'Never overwrite/replay an occupied phase');phase.mkdir(parents=True);captures=phase/'captures';captures.mkdir()
    s=dict(agent='shienryu_source_review',phase_id=a['phase_id'],action_sha256=action_sha,root_admission_sha256=admission_sha,
        started=time.time(),result='STARTED_NOT_ACCEPTED',events=[],captures=[],cleanup_errors=[],expected_status82=a['expected_status82'],active_menu_result_sha256=a['active_menu_result_sha256'],physical_HDMI_or_audio_acceptance=False)
    deadline=time.monotonic()+a['max_seconds'];jp=phase/'journal.json'
    def journal():save(jp,s)
    journal()
    with api.device() as (c,sf):
        sf.get_channel().settimeout(30)
        def identity(mode,epoch=None):
            state=api.state(c);must(api.idle(state['control'],mode,epoch),'Unexpected ownership/active input/epoch');g=state['game']
            must(g.get('core_path')==RBF and g.get('game_path')==MRA and not g.get('error'),'Exact candidate changed');return state
        def guard():must(time.monotonic()<deadline,'Cooperative gameplay phase limit reached');return identity('assistant',s['epoch'])
        def wire(payload,label):
            payload={**payload,'id':'SHYF4G-'+uuid.uuid4().hex};e=dict(label=label,payload=payload,started=time.time());s['events'].append(e);journal()
            v=c.request(payload);e['reply']={k:z for k,z in v.items() if k!='data'};journal();must(v.get('id')==payload['id'],'Uncertain reply ID: no replay');return v
        def proof():
            found=[];allnames=h.names(c)
            for p in allnames:
                low=p.lower()
                if 'shyf0004' in low:continue
                if low.startswith('/media/fat/config/inputs/') or low.endswith('.map') or re.search('stv|st-v|shienryu|saturn',low):found.append(p)
            must(sorted(set(found))==protected['membership'],'Protected24 membership changed')
            expected={**protected['hashes'],**extra,**{x['remote']:x['sha256'] for x in r['files'].values()}}
            must(h.hashes(c,expected)==expected,'Original/staged/aliasCFG/NVM hashes changed')
            must(api.rbf_candidates(sf,RBF)==['SHYF0004.rbf'],'Candidate RBF prefix ambiguous')
            must({p for p in allnames if 'shyf0004' in p.lower()}==set(extra)|{'/media/fat/config/inputs/SHYF0004_input_4711_0815_v3.map'},'Candidate settings membership changed')
        def press(keys,ms,label):
            state=guard();type(c).request.__globals__['preflight_input'](state['control'],ms)
            payload={'mister':'input','device':'keyboard','duration_ms':ms};payload['key' if len(keys)==1 else 'combo']=keys[0] if len(keys)==1 else keys
            v=wire(payload,label);must(v.get('success') is True and v.get('status')=='completed' and v.get('action_id')==v.get('id'),'Uncertain input outcome: no replay');guard()
        try:
            s['before']=h.slim(identity('user',a['starting_user_epoch']));proof();s['handoff_attempted']=True;journal()
            v=wire({'mister':'control','action':'assistant'},'acquire-once');s['epoch']=v.get('epoch');journal();must(bool(s['epoch']) and api.idle(v,'assistant',s['epoch']),'Assistant lease/epoch not proven');guard()
            must(42 not in h.WORDS,'Neutral initialization key mapped');press(['leftshift'],1,'neutral-keyboard-initialization')
            blocks=[b for b in h.shell(c,'cat /proc/bus/input/devices').split('\n\n') if 'N: Name="misterclaw"' in b]
            must(len(blocks)==1 and 'Bus=0003 Vendor=4711 Product=0815 Version=0001' in blocks[0] and 'kbd' in blocks[0],'Keyboard identity unverified');s['keyboard_identity']=blocks[0];journal()
            for index,step in enumerate(a['steps']):
                guard()
                if step['kind']=='input':press(step['keys'],step['duration_ms'],'gameplay-input-'+str(index))
                else:
                    time.sleep(step['settle_ms']/1000);guard();event=dict(label=step['label'],request={'mister':'screenshot'},started=time.time());s['events'].append(event);journal()
                    v=c.request({'mister':'screenshot'});event['reply']={k:z for k,z in v.items() if k!='data'};journal();must(v.get('success') is True,'Capture failed; no replay')
                    raw=base64.b64decode(v['data'],validate=True);must(raw.startswith(b'\x89PNG\r\n\x1a\n') and len(raw)==v['size'] and len(raw)<8*1024*1024,'Invalid bounded PNG')
                    guard();p=captures/(step['label']+'.png')
                    with p.open('xb') as f:f.write(raw)
                    s['captures'].append(dict(file=str(p),sha256=sha(p),source_response={k:z for k,z in v.items() if k!='data'},scope='Pre-ascal framebuffer: root visual review pending; no HDMI flip/OSD/audio proof'));journal()
            guard();proof();s['result']='INPUTS_AND_CAPTURES_COMPLETED_FOR_ROOT_REVIEW_NOT_ACCEPTANCE'
        except Exception as error:s.update(result='FAILED_STOPPED_NO_REPLAY',error=repr(error))
        finally:
            try:
                state=api.state(c)
                if s.get('epoch') and state['control'].get('mode')=='assistant' and state['control'].get('epoch')==s['epoch']:
                    v=wire({'mister':'control','action':'release_all'},'release-owned-inputs');must(api.idle(v,'assistant',s['epoch']),'Owned release not idle')
                    v=wire({'mister':'control','action':'user'},'handback-once');s['handback_epoch']=v.get('epoch');must(bool(s['handback_epoch']) and api.idle(v,'user',s['handback_epoch']),'Handback User epoch not proven')
                elif not api.idle(state['control'],'user'):raise RuntimeError('Unknown ownership/outcome: no adoption; root recovery required')
                else:
                    s['ownership_already_User_no_adoption']=True
                    if s['result'].startswith('INPUTS_'):raise RuntimeError('Unexpected ownership change prevents success')
                s['final_state']=h.slim(identity('user',s.get('handback_epoch')));proof();s['protected_originals_staging_and_alias_CFG_NVM_unchanged']=True
            except Exception as error:s['cleanup_errors'].append(repr(error))
            s['finished']=time.time();journal()
    print(json.dumps({k:s.get(k) for k in ['result','error','cleanup_errors','final_state','protected_originals_staging_and_alias_CFG_NVM_unchanged']},indent=2))
    return 0 if s['result']=='INPUTS_AND_CAPTURES_COMPLETED_FOR_ROOT_REVIEW_NOT_ACCEPTANCE' and not s['cleanup_errors'] else 1
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--action');p.add_argument('--action-sha256');p.add_argument('--admission');p.add_argument('--admission-sha256');a=p.parse_args()
    if a.execute:return execute(a.action,a.action_sha256,a.admission,a.admission_sha256)
    local();print(json.dumps(dict(state='UNFROZEN_LOCAL_ONLY_NO_DEVICE_ACCESS',script_sha256=sha(__file__),menu_result_sha256=MENU_REVIEW_SHA,allowed_steps=24)));return 0
if __name__=='__main__':raise SystemExit(main())
