"""Unfrozen SHYF0004 hardware wrapper. Default is local-only readiness.
Reuse the closed baseline's pinned transport; never navigate cached OSD menus.
Freeze needs root artifact qualification. Live phases need exact reviewed IDs.
"""
import argparse,base64,hashlib,importlib.util,json,re,shlex,stat,struct,sys,time,uuid
from pathlib import Path
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
BASE=OUT.parent/'baseline-hardware-r1'
BASE_SHA='47a73ac18e5b8303d56cba43c7b9a9fc9f1850e4b13bfb447167e2267dc04db7'
RBF='/media/fat/_Arcade/cores/SHYF0004.rbf'
MRA='/media/fat/_Arcade/_CoreLab/SHYF0004.mra'
MAP='/media/fat/config/inputs/SHYF0004_input_4711_0815_v3.map'
MENU='/media/fat/menu.rbf'
KEYS={'up','down','left','right','leftctrl','leftalt','1','5'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def must(ok,msg):
    if not ok:raise RuntimeError(msg)
def save(p,v,exclusive=False):
    with p.open('x' if exclusive else 'w',encoding='utf-8') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def digest(p):return sha(Path(p).read_bytes())
def baseline():
    must(digest(BASE/'hardware_once.py')==BASE_SHA,'Closed baseline helper changed')
    spec=importlib.util.spec_from_file_location('closed_stv_baseline_helpers',BASE/'hardware_once.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);return h
def require_file(path,expected):
    p=Path(path);must(p.is_absolute() and p.is_file() and not p.is_symlink(),'Expected ordinary absolute evidence file');must(digest(p)==expected,'Evidence hash changed: '+str(p));return p
def freeze(review_path,review_sha):
    must(not (OUT/'ready.json').exists(),'Already frozen; preserve existing record')
    review_path=Path(review_path).resolve()
    require_file(review_path,review_sha);q=read(review_path)
    must(q['schema']=='SHYF0004-ARTIFACT-QUALIFICATION-1' and q['reviewed_by']=='root' and q['accepted_for_bounded_hardware'] is True,'Root hardware artifact qualification absent')
    must(q['native_flow_exit_code']==0 and q['profile']=='SHIENRYU_ONLY/scaled-HDMI' and q['timing_status'] in ('experimental','clean'),'Invalid compile/profile/timing disposition')
    must(re.fullmatch('[0-9a-f]{40}',q['candidate_source_commit']) is not None,'Missing source commit')
    rb=require_file(q['local_rbf'],q['rbf_sha256']);must(rb.stat().st_size==q['rbf_bytes'] and 1000000<rb.stat().st_size<16000000,'RBF size mismatch')
    must(q['rbf_sha256']!='2bad41a6e2bd52078f5a8fffff85640a416332364c4c1721ff7496735d2660d4','Unchanged baseline cannot be labeled candidate')
    src=require_file(q['conf_source'],q['conf_source_sha256']).read_text()
    must('"P1o[82],Shienryu 180 Flip,Off,On;"' in src and 'wire [127:0] status;' in src and "localparam [7:0] STV_MODE = 8'h00;" in src,'Qualified candidate source lacks expected profile/option')
    must(bool(q['provenance_evidence']),'Root source/constraint/clock provenance evidence absent')
    for item in q['provenance_evidence']:require_file(item['path'],item['sha256'])
    h=baseline();original=OUT.parent/'preserved-originals/Shienryu stv_flip_v1.1_rc1.mra'
    must(digest(original)=='0e9c0a8422fe419a458c8ad8673555acc4500fca7aa19e93985096353efd813e','Protected MRA changed')
    tree=ET.fromstring(original.read_bytes());fixed=[ET.tostring(x) for x in tree if x.tag not in ('rbf','setname','description')]
    tree.find('rbf').text='SHYF0004';tree.find('setname').text='SHYF0004';tree.find('description').text='CoreLab Shienryu HDMI-only flip candidate SHYF0004'
    must(fixed==[ET.tostring(x) for x in tree if x.tag not in ('rbf','setname','description')],'MRA semantics changed')
    fixtures=[('SHYF0004.mra',ET.tostring(tree,encoding='utf-8',xml_declaration=True)+b'\n',MRA),('SHYF0004_input_4711_0815_v3.map',struct.pack('<32I',*h.WORDS),MAP)]
    files={}
    for name,raw,remote in fixtures:
        local=OUT/name
        if local.exists():must(local.is_file() and not local.is_symlink() and local.read_bytes()==raw,'Reviewed local staging file changed: '+name)
        else:
            with local.open('xb') as f:f.write(raw)
        files[name]={'local':str(OUT/name),'remote':remote,'bytes':len(raw),'sha256':sha(raw)}
    files['SHYF0004.rbf']={'local':str(rb),'remote':RBF,'bytes':q['rbf_bytes'],'sha256':q['rbf_sha256']}
    ready={'schema':'SHYF0004-READY-1','root_review':str(Path(review_path).resolve()),'root_review_sha256':review_sha,'files':files,'source_commit':q['candidate_source_commit'],'timing_status':q['timing_status'],'conf_source':q['conf_source'],'conf_source_sha256':q['conf_source_sha256'],'script_sha256':digest(__file__),'cached_protection_sha256':digest(OUT/'cached-protection.json'),'plan_sha256':digest(OUT/'HARDWARE-ACCEPTANCE-PLAN.json')}
    save(OUT/'ready.json',ready,True);print(json.dumps({'local_freeze_only':True,'ready_sha256':digest(OUT/'ready.json'),'device_access':False}));return 0
def verified_ready():
    r=read(OUT/'ready.json');must(r['schema']=='SHYF0004-READY-1' and r['script_sha256']==digest(__file__),'Unfrozen or changed harness')
    require_file(r['root_review'],r['root_review_sha256']);require_file(r['conf_source'],r['conf_source_sha256'])
    must(r['cached_protection_sha256']==digest(OUT/'cached-protection.json') and r['plan_sha256']==digest(OUT/'HARDWARE-ACCEPTANCE-PLAN.json'),'Frozen plan/protection changed')
    for item in r['files'].values():require_file(item['local'],item['sha256']);must(Path(item['local']).stat().st_size==item['bytes'],'Fixture size changed')
    return r
def action_check(path,expected_sha,r):
    require_file(str(Path(path).resolve()),expected_sha);a=read(path)
    must(a['schema']=='SHYF0004-ACTION-1' and re.fullmatch('[a-z0-9][a-z0-9-]{0,47}',a['phase_id']) is not None,'Invalid phase/schema')
    must(a['expected_start'] in ('MENU','CANDIDATE') and type(a['load_candidate']) is bool and type(a['finish_to_menu']) is bool,'Invalid phase starting/load state')
    must(type(a['max_seconds']) is int and 1<=a['max_seconds']<=240,'Phase bounds invalid')
    steps=a['steps'];must(isinstance(steps,list) and len(steps)<=24,'At most24 steps')
    if a['finish_to_menu']:must(a['expected_start']=='CANDIDATE' and not a['load_candidate'] and steps==[],'Finish is separate no-input phase')
    must(a['expected_start']=='CANDIDATE' or a['load_candidate'],'Menu phase must load candidate')
    input_ms=settle_ms=0;labels=set()
    for step in steps:
        if step['kind']=='input':
            must(set(step)=={'kind','keys','duration_ms'},'Unexpected input fields');keys=step['keys'];ms=step['duration_ms']
            must(isinstance(keys,list) and 1<=len(keys)<=2 and len(keys)==len(set(keys)) and set(keys)<=KEYS,'Unsupported key/combo')
            must(not {'up','down'}<=set(keys) and not {'left','right'}<=set(keys),'Opposite directions unsupported');must(type(ms) is int and 1<=ms<=5000,'Input duration invalid');input_ms+=ms
        elif step['kind']=='capture':
            must(set(step)=={'kind','label','settle_ms'} and re.fullmatch('[a-z0-9][a-z0-9-]{0,47}',step['label']) is not None and step['label'] not in labels,'Bad capture label/fields');must(type(step['settle_ms']) is int and 0<=step['settle_ms']<=15000,'Bad settle');labels.add(step['label']);settle_ms+=step['settle_ms']
        else:raise RuntimeError('Only bounded inputs/captures supported')
    must(input_ms<=30000 and settle_ms<=60000,'Action sequence exceeds bounds')
    obs=a.get('requires_observation')
    if obs is not None:
        must(isinstance(obs,dict) and set(obs)=={'path','sha256','required_checks'},'Observation reference must have exact evidence fields')
        must(isinstance(obs['required_checks'],list) and bool(obs['required_checks']) and all(isinstance(k,str) and k for k in obs['required_checks']) and len(obs['required_checks'])==len(set(obs['required_checks'])),'Observation checks must be explicit and unique')
        require_file(obs['path'],obs['sha256']);v=read(obs['path']);must(v['schema']=='SHYF0004-USER-OBSERVATION-1' and v['reviewed_by']=='root' and v['candidate_rbf_sha256']==r['files']['SHYF0004.rbf']['sha256'],'Observation not bound to candidate')
        must(v['source'] in ('user_tv','existing_HDMI_capture') and bool(v['observed_utc']),'Observation needs actual HDMI/user evidence')
        must(all(v['checks'].get(k) is True for k in obs['required_checks']),'Required physical observation pending')
    if any(x['kind']=='input' for x in steps):must(obs is not None,'Gameplay phases need actual candidate display/option observation first')
    return a
def execute(action_path,action_sha,ready_sha):
    must(digest(OUT/'ready.json')==ready_sha,'Root-reviewed ready hash differs');r=verified_ready();a=action_check(action_path,action_sha,r);h=baseline();api=h.api();protected=read(OUT/'cached-protection.json')
    folder=OUT/'phases';folder.mkdir(exist_ok=True);jp=folder/(a['phase_id']+'.json');must(not jp.exists(),'Phase already attempted; do not replay')
    captures=folder/a['phase_id'];captures.mkdir();s={'agent':'/root/shienryu_source_review','phase_id':a['phase_id'],'action_sha256':action_sha,'ready_sha256':ready_sha,'started':time.time(),'result':'STARTED_DO_NOT_REPEAT','events':[],'captures':[]};save(jp,s,True)
    deadline=time.monotonic()+a['max_seconds'];where=a['expected_start']
    def journal():save(jp,s)
    with api.device() as (c,sf):
        sf.get_channel().settimeout(30)
        def identity(mode,epoch=None):
            state=api.state(c);must(api.idle(state['control'],mode,epoch),'Control not idle in expected epoch')
            game=state['game']
            if where=='MENU':must(game.get('core_name','').upper()=='MENU' and not game.get('game_path') and game.get('core_path') in ('',MENU,'menu.rbf'),'Expected Menu')
            else:must(game.get('core_path')==RBF and game.get('game_path')==MRA and not game.get('error'),'Expected exact candidate')
            return state
        def guard():must(time.monotonic()<deadline,'Cooperative action deadline reached');return identity('assistant',s['epoch'])
        def proof():
            paths=[]
            for p in h.names(c):
                low=p.lower()
                if 'shyf0004' in low:continue
                if low.startswith('/media/fat/config/inputs/') or low.endswith('.map') or re.search('stv|st-v|shienryu|saturn',low):paths.append(p)
            must(sorted(set(paths))==protected['membership'],'Protected settings membership changed')
            must(h.hashes(c,protected['hashes'])==protected['hashes'],'Protected original/baseline hashes changed')
        def files_check():must(h.hashes(c,{x['remote']:x['sha256'] for x in r['files'].values()})=={x['remote']:x['sha256'] for x in r['files'].values()},'Staged candidate hashes changed');must(api.rbf_candidates(sf,RBF)==['SHYF0004.rbf'],'Candidate RBF prefix ambiguous')
        def wire(payload,label):
            payload={**payload,'id':'SHYF-'+uuid.uuid4().hex};e={'label':label,'payload':payload,'started':time.time()};s['events'].append(e);journal();v=c.request(payload);e['reply']={k:z for k,z in v.items() if k!='data'};journal();must(v.get('id')==payload['id'],'Reply ID uncertain; do not repeat');return v
        def completed(v):must(v.get('success') is True and v.get('status')=='completed' and v.get('action_id')==v.get('id'),'Action outcome uncertain; do not repeat')
        def load_once(destination):
            nonlocal where
            guard();completed(wire({'mister':'load_core','path':MRA if destination=='CANDIDATE' else MENU},'one-load-'+destination));limit=min(deadline,time.monotonic()+75)
            while time.monotonic()<limit:
                before=where;where=destination
                try:identity('assistant',s['epoch']);return
                except RuntimeError:where=before
                current=api.state(c);must(api.idle(current['control'],'assistant',s['epoch']),'Ownership changed during load')
                must(current['game'].get('core_path') in ('',MENU,'menu.rbf',RBF),'Unexpected core during load; no further action');time.sleep(1)
            raise RuntimeError('Load observation expired; never retry automatically')
        def press(keys,ms):
            state=guard();type(c).request.__globals__['preflight_input'](state['control'],ms);payload={'mister':'input','device':'keyboard','duration_ms':ms};payload['key' if len(keys)==1 else 'combo']=keys[0] if len(keys)==1 else keys;completed(wire(payload,'bounded-input'));guard()
        try:
            s['before']=h.slim(identity('user'));proof()
            staging=a['load_candidate'] and where=='MENU' and not (OUT/'staged.json').exists()
            if staging:
                must(not any('shyf0004' in p.lower() for p in h.names(c)),'Candidate settings namespace occupied')
                for item in r['files'].values():must(not api.remote_exists(sf,item['remote']),'Exclusive upload path occupied')
                must(not api.rbf_candidates(sf,RBF),'Candidate prefix occupied')
            else:files_check()
            s['handoff_attempted']=True;journal();v=wire({'mister':'control','action':'assistant'},'one-assistant-handoff')
            if v.get('success') and v.get('mode')=='assistant':s['epoch']=v.get('epoch');journal()
            must(api.idle(v,'assistant'),'Assistant handoff not idle');guard()
            if staging:
                for parent in ('/media/fat/_Arcade/_CoreLab','/media/fat/config/inputs'):
                    if not api.remote_exists(sf,parent):sf.mkdir(parent)
                    must(stat.S_ISDIR(sf.lstat(parent).st_mode),'Upload parent not ordinary directory')
                for item in r['files'].values():
                    guard();must(not api.remote_exists(sf,item['remote']),'Upload collision')
                    with sf.open(item['remote'],'wx') as dest:
                        with Path(item['local']).open('rb') as source:
                            for block in iter(lambda:source.read(131072),b''):dest.write(block)
                    s.setdefault('created_files',[]).append(item['remote']);journal()
                files_check();save(OUT/'staged.json',{'ready_sha256':ready_sha,'files':r['files'],'phase':a['phase_id']},True);proof()
            if a['load_candidate']:load_once('CANDIDATE')
            if any(x['kind']=='input' for x in a['steps']):
                must(42 not in h.WORDS,'Initialization key mapped');press(['leftshift'],1)
                blocks=[b for b in h.shell(c,'cat /proc/bus/input/devices').split('\n\n') if 'N: Name="misterclaw"' in b]
                must(len(blocks)==1 and 'Bus=0003 Vendor=4711 Product=0815 Version=0001' in blocks[0] and 'kbd' in blocks[0],'Keyboard identity unverified');s['keyboard_identity']=blocks[0];journal()
            for step in a['steps']:
                guard()
                if step['kind']=='input':press(step['keys'],step['duration_ms'])
                else:
                    time.sleep(step['settle_ms']/1000);guard();v=c.request({'mister':'screenshot'});must(v.get('success') is True,'Capture failed');raw=base64.b64decode(v['data'],validate=True);must(raw.startswith(b'\x89PNG\r\n\x1a\n') and len(raw)==v['size'] and len(raw)<8*1024*1024,'Invalid capture')
                    p=captures/(step['label']+'.png')
                    with p.open('xb') as f:f.write(raw)
                    s['captures'].append({'file':str(p),'sha256':sha(raw),'scope':'Pre-ascal-flip framebuffer; no physical HDMI/OSD/audio proof'});journal()
            if a['finish_to_menu']:load_once('MENU')
            guard();files_check();s['result']='ACTIONS_CAPTURED_FOR_ROOT_REVIEW_NOT_ACCEPTANCE'
        except BaseException as e:s['result']='STOPPED';s['error']=str(e)
        finally:
            errors=[]
            if s.get('handoff_attempted') and not s.get('epoch'):
                try:
                    state=api.state(c);s['uncertain_acquisition_audit']=h.slim(state);must(api.idle(state['control'],'user'),'Unknown handoff outcome; do not adopt/release unattributed epoch; root/manual recovery required')
                except BaseException as e:errors.append(str(e))
            for operation in ('release_all','user'):
                try:
                    state=api.state(c)
                    if s.get('epoch') and state['control'].get('mode')=='assistant' and state['control'].get('epoch')==s['epoch']:must(wire({'mister':'control','action':operation},'final-'+operation).get('success') is True,'Cleanup not acknowledged')
                except BaseException as e:errors.append(operation+': '+str(e))
            try:
                state=api.state(c);s['final_state']=h.slim(state);must(api.idle(state['control'],'user'),'Final User/idle unverified');proof();s['protected_originals_and_baseline_unchanged']=True
                candidate=[p for p in h.names(c) if 'shyf0004' in p.lower()];s['candidate_settings_after']={}
                for i,p in enumerate(candidate):
                    must(sf.stat(p).st_size<2*1024*1024,'Candidate setting unexpectedly large')
                    with sf.open(p,'rb') as f:raw=f.read()
                    local=captures/f'candidate-setting-{i:03d}.bin'
                    with local.open('xb') as f:f.write(raw)
                    s['candidate_settings_after'][p]={'file':str(local),'bytes':len(raw),'sha256':sha(raw)}
                    if p.endswith('/SHYF0004.CFG') and len(raw)==16:s['saved_CFG_status82']=bool(raw[10]&4)
                    if p.endswith('/SHYF0004.nvm'):s['NVRAM_declared_geometry_matches']=len(raw)==65664
                if s['result'].startswith('ACTIONS'):s['final_state']=h.slim(identity('user'))
            except BaseException as e:errors.append('Final proof: '+str(e))
            s['cleanup_errors']=errors;s['finished']=time.time();journal()
    print(json.dumps({k:s.get(k) for k in ('result','error','cleanup_errors','final_state','protected_originals_and_baseline_unchanged')},indent=2));return 0 if s['result'].startswith('ACTIONS') and not s['cleanup_errors'] else 2
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--freeze');p.add_argument('--review-sha256');p.add_argument('--execute',action='store_true');p.add_argument('--action');p.add_argument('--ready-sha256');args=p.parse_args()
    if args.freeze:must(not args.execute,'Freeze and execution are separate');return freeze(args.freeze,args.review_sha256)
    if args.execute:must(args.action and args.review_sha256 and args.ready_sha256,'Execution needs reviewed ready/action hashes');return execute(args.action,args.review_sha256,args.ready_sha256)
    cached=read(OUT/'cached-protection.json');baseline();print(json.dumps({'state':'UNFROZEN' if not (OUT/'ready.json').exists() else 'FROZEN_REQUIRES_EXPLICIT_REVIEWED_ACTION','no_device_access':True,'candidate_binary_read':False,'protected_hashes':len(cached['hashes']),'protected_settings':len(cached['membership']),'plan_sha256':digest(OUT/'HARDWARE-ACCEPTANCE-PLAN.json'),'script_sha256':digest(__file__)}));return 0
if __name__=='__main__':raise SystemExit(main())
