"""Verify one published lab recovery commit. No remote mutations or device access."""
import argparse, base64, datetime, hashlib, io, json, re, subprocess, zipfile
from pathlib import Path
HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / 'cores/Shienryu_B75_Preservation'
OWNER = 'djjohnson13p/MiSTer-STV-Shienryu-Flip'
BRANCH = 'lab/shienryu-control-r2-seed-archive'
GH = 'C:/Users/djjoh/AppData/Local/Programs/GitHub CLI/gh.exe'
ORIGINAL = '41da931c75b8d1f2d5159cc1ca3770f613c19007'
def require(ok, message):
    if not ok: raise ValueError(message)
def api(path):
    endpoint = 'repos/'+OWNER+('/'+path if path else '')
    return json.loads(subprocess.check_output([GH,'api',endpoint],text=True,encoding='utf-8'))
def originals():
    require(api('')['default_branch']=='stv-flip-v1.1','Original default branch changed')
    for ref in ('heads/stv-flip-v1.1','tags/v1.1-share-20261022'):
        require(api('git/ref/'+ref)['object']['sha']==ORIGINAL,'Original ref changed')
def run(seed, head, parent):
    for value in (head,parent): require(re.fullmatch('[0-9a-f]{40}',value),'Exact commit required')
    receipt = HERE / f'GITHUB-CONTROL-R2-SEED{seed:02}-PRESERVATION.json'
    require(not receipt.exists(),'Preserve existing receipt; do not overwrite/replay')
    originals(); require(api('git/ref/heads/'+BRANCH)['object']['sha']==head,'Lab head differs')
    require(api('git/commits/'+head)['parents'][0]['sha']==parent,'Unexpected parent')
    prefix = f'experiments/control-r2-seed-archive/seed{seed:02}/'
    tree = api('git/trees/'+head+'?recursive=1'); require(not tree.get('truncated'),'Incomplete remote tree')
    entries = {e['path']:e for e in tree['tree'] if e['type']=='blob' and e['path'].startswith(prefix)}
    files = {f.relative_to(REPO).as_posix():f for f in (REPO/prefix).rglob('*') if f.is_file()}
    require(bool(files) and set(entries)==set(files),'Remote/local archive membership differs')
    for name, f in files.items():
        h = hashlib.sha1(('blob '+str(f.stat().st_size)+'\0').encode())
        with f.open('rb') as stream:
            for data in iter(lambda:stream.read(1024*1024),b''): h.update(data)
        require(entries[name]['sha']==h.hexdigest() and entries[name]['size']==f.stat().st_size,'Remote blob differs: '+name)
    pkg = REPO/prefix/'frozen-package'
    index = json.loads((pkg/'PACKAGE-INDEX.json').read_text())
    measurement_path = HERE/f'ROOT-SEED{seed:02}-TIMING-RESULT.json'
    measurement = json.loads(measurement_path.read_text())
    require(index['seed']==measurement['seed']==seed and index['root_timing_result_sha256']==hashlib.sha256(measurement_path.read_bytes()).hexdigest(),'Wrong seed/measurement binding')
    review = json.loads((REPO/prefix/'ROOT-PACKAGE-REVIEW.json').read_text())
    restore_path = REPO/prefix/'ROOT-RESTORE-VALIDATION.json'
    restored = json.loads(restore_path.read_text())
    require(review['reviewer']=='root' and review['manual_root_review'] and not review['root_restore_pending'] and review['root_restore_validation_sha256']==hashlib.sha256(restore_path.read_bytes()).hexdigest(),'Actual root package/restore proof absent')
    require(restored['seed']==seed and restored['exact_checkpoint_verified'] and restored['restored_files']==json.loads((pkg/f'SEED{seed:02}-ASM-SNAPSHOT.json').read_text())['file_count'],'Checkpoint restore scope differs')
    require(restored['rbf_sha256']==measurement['programming_outputs']['output_files/STV_DS.rbf']['sha256'] and restored['SOF_sha256']==measurement['programming_outputs']['output_files/STV_DS.sof']['sha256'],'Restored programming proof differs')
    downloads = []
    for name, record in index['packages'].items():
        if record['group']!='source-programming-and-evidence': continue
        blob = api('git/blobs/'+entries[prefix+'frozen-package/'+name]['sha'])
        require(blob['encoding']=='base64','Unsupported remote encoding')
        data = base64.b64decode(blob['content'])
        require(len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256'],'Downloaded ZIP differs')
        found = {}
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            require(z.testzip() is None,'Downloaded ZIP CRC failed')
            for ext in ('rbf','sof'):
                member = f'seed{seed:02}/programming/STV_DS.{ext}'
                if member not in z.namelist(): continue
                raw = z.read(member); expected = measurement['programming_outputs']['output_files/STV_DS.'+ext]
                require(len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],'Remote programming bytes differ')
                found[ext] = expected
        downloads.append(dict(filename=name,bytes=len(data),sha256=record['sha256'],programming_outputs=found))
    require({k for d in downloads for k in d['programming_outputs']}=={'rbf','sof'},'Missing remote programming outputs')
    originals(); require(api('git/ref/heads/'+BRANCH)['object']['sha']==head,'Lab head moved during verification')
    result = dict(reviewer='root',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        decision=f'REMOTE_SEED{seed:02}_ARCHIVE_BYTES_VERIFIED',repository=OWNER,archive_branch=BRANCH,
        archive_commit=head,parent_commit=parent,all_seed_child_Gitblob_SHA1_and_sizes_match=len(files),
        programming_ZIP_downloads=downloads,original_default_and_tag_unchanged_41da=True,
        timing_acceptance=False,hardware_acceptance=False,bit_identical_rebuild_demonstrated=False,
        verifier_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    with receipt.open('x',encoding='utf-8') as f: json.dump(result,f,indent=2); f.write('\n')
    digest = hashlib.sha256(receipt.read_bytes()).hexdigest()
    ip = HERE/'CONTROL-R2-SEED-INDEX.json'; live=json.loads(ip.read_text())
    entry = next(v for v in live['seed_records'] if v['seed']==seed)
    entry.update(compiled_archive_uploaded_to_fork=True,archive_branch=BRANCH,archive_commit=head,
        archive_url='https://github.com/'+OWNER+'/tree/'+BRANCH+'/'+prefix.rstrip('/'),
        complete_checkpoint_restore_test_passed=True,remote_binary_download_verified=True,remote_verified_utc=result['utc'])
    live.update(latest_archive_head=head,latest_remote_verification_receipt=str(receipt),
        latest_remote_verification_receipt_sha256=digest,latest_remote_verification_by='root')
    temporary=ip.with_suffix('.verify-tmp')
    with temporary.open('x',encoding='utf-8') as f: json.dump(live,f,indent=2); f.write('\n')
    temporary.replace(ip)
    print(json.dumps(dict(remote_verified_commit=head,receipt_sha256=digest,seed_files=len(files))))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--seed',type=int,choices=range(6,11),required=True)
    p.add_argument('--commit',required=True); p.add_argument('--parent',required=True); a=p.parse_args()
    run(a.seed,a.commit,a.parent)
