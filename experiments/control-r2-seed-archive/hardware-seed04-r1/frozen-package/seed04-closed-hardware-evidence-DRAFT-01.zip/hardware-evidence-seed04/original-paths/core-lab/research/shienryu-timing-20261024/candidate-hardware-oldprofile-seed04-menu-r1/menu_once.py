"""UNFROZEN separate seed4 menu trial. Default is local-only; no device access."""
import argparse,hashlib,importlib.util,json,re,stat,sys,time,uuid
from pathlib import Path
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
RESEARCH=OUT.parent
CORE=RESEARCH/'candidate-hardware-oldprofile-seed04'
HELPER_SHA='ae9daa6516c2fd3be0bde3126c54d29b4b7c7424c34a3bf916a01ca292ef1a0b'
READY_SHA='0088198c749f2ec7ce635bf9cabdba9ce06d1a1e18412bc8be28a9705b1fc3d8'
BOOT=CORE/'phases/seed04-bootstrap-capture-01.json'
BOOT_SHA='1bdc563dc0f0fe8cd22f9bfcc2553047eb62343001f52436a545ced225c3e510'
BOOT_REVIEW=CORE/'ROOT-BOOT-CAPTURE-REVIEW.json'
BOOT_REVIEW_SHA='bc9d7e90aa1663598a0b6cce3a43615c5c9719545d8dc2a8f5f4c6e9417f4603'
RELEASE=RESEARCH/'autonomous-osd-reference-738cb7ac'
RELEASE_SHA='bbc6dc01d6cb7f626d9bad4c7dc675e6a73236a48176a8d970ccd2aa35566c0b'
MAIN_SHA='ba8746d91ced547845b743b7826d827cfd6c488de0bcf8b27112d8d77f8a7e27'
CFG='/media/fat/config/SHYF0004.CFG'
NVM='/media/fat/config/nvram/SHYF0004.nvm'
MAP='/media/fat/config/inputs/SHYF0004_input_4711_0815_v3.map'
RBF='/media/fat/_Arcade/cores/SHYF0004.rbf'
MRA='/media/fat/_Arcade/_CoreLab/SHYF0004.mra'
def must(ok,msg):
    if not ok:raise RuntimeError(msg)
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):
    temporary=p.with_suffix(p.suffix+'.tmp');temporary.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');temporary.replace(p)
def require(p,h):
    p=Path(p);must(p.is_absolute() and p.is_file() and not p.is_symlink() and sha(p)==h,'Bound ordinary file changed: '+str(p));return p
def local():
    require(CORE/'candidate_hardware.py',HELPER_SHA);require(CORE/'ready.json',READY_SHA);require(BOOT,BOOT_SHA);require(BOOT_REVIEW,BOOT_REVIEW_SHA)
    reviewed=read(BOOT_REVIEW)
    must(reviewed['reviewed_by']=='root' and reviewed['ready_sha256']==READY_SHA and reviewed['boot_journal_sha256']==BOOT_SHA,'Root boot review bindings differ')
    must(reviewed['pre_ascal_game_boot_progress_verified'] and reviewed['no_input_or_OSD_commands_in_boot_phase'] and reviewed['user_authorizes_autonomous_OSD_without_manual_operation'],'Missing actual boot/fresh-menu authority')
    must(reviewed['physical_HDMI_flip_or_OSD_orientation_verified'] is False and reviewed['audio_verified'] is False,'Do not relabel physical observations')
    require(RELEASE/'release-provenance.json',RELEASE_SHA)
    proof=read(RELEASE/'release-provenance.json');must(proof['release_commit']=='738cb7acc246c830739d02d862c0cc2a275738bb' and proof['release_sha256']==MAIN_SHA,'Wrong Main release')
    for name,entry in proof['source_files'].items():require(RELEASE/name,entry['sha256'])
    spec=importlib.util.spec_from_file_location('frozen_seed04_boot_helper',CORE/'candidate_hardware.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    ready=helper.verified_ready();h=helper.baseline();boot=read(BOOT)
    must(boot['ready_sha256']==READY_SHA and boot['result']=='ACTIONS_CAPTURED_FOR_ROOT_REVIEW_NOT_ACCEPTANCE' and not boot['cleanup_errors'] and boot['protected_originals_and_baseline_unchanged'],'Boot evidence not qualified')
    must(ready['source_commit']=='7e987bb9ef0361356be22be13551e4626902f3a7' and ready['files']['SHYF0004.rbf']['sha256']=='99654dbf7a472b610f840f9dbbb0087bc6f508ce3dfdfe2ffbd48e6df5396d11','Wrong seed4 artifact')
    must(boot['final_state']['game']['core_path']==RBF and boot['final_state']['game']['game_path']==MRA,'Boot candidate identity differs')
    for capture in boot['captures']:require(capture['file'],capture['sha256'])
    return helper,h,ready,boot
def action(path,digest,admission_path,admission_sha):
    require(path,digest);a=read(path);require(admission_path,admission_sha);q=read(admission_path)
    must(a['schema']=='SHYF0004-MENU-ACTION-1' and a['state']=='ROOT_REVIEWED_ACTION','Unreviewed action')
    must(re.fullmatch('[a-z0-9][a-z0-9-]{0,47}',a['phase_id']) is not None and a['phase_id']=='seed04-menu-off-on-off-01','Unexpected phase')
    must(a['script_sha256']==sha(__file__) and a['ready_sha256']==READY_SHA and a['boot_journal_sha256']==BOOT_SHA and a['boot_review_sha256']==BOOT_REVIEW_SHA,'Action bindings differ')
    must(a['starting_user_epoch']=='b5550bf9-03c1-4af0-a355-ac171dfeba76' and a['expected_Main_PID']==11482 and a['max_seconds']==180,'Unreviewed runtime/limit change')
    must(q['reviewer']=='root' and q['decision']=='ACCEPTED_SEED04_MENU_ONLY_AUTOMATION','Root menu admission absent')
    must(q['action_sha256']==digest and q['script_sha256']==sha(__file__) and q['ready_sha256']==READY_SHA and q['boot_journal_sha256']==BOOT_SHA and q['boot_review_sha256']==BOOT_REVIEW_SHA,'Root admission does not bind this action')
    must(q['source_and_CFG_sideeffects_replace_manual_observation_for_menu_only'] is True and q['physical_HDMI_or_audio_acceptance'] is False,'Wrong acceptance scope')
    return a
def execute(action_path,action_sha,admission_path,admission_sha):
    helper,h,r,boot=local();a=action(action_path,action_sha,admission_path,admission_sha);api=h.api();protected=read(CORE/'cached-protection.json')
    phase=OUT/'phases'/a['phase_id'];must(not phase.exists(),'Never overwrite/replay an occupied attempt');phase.mkdir(parents=True)
    s=dict(agent='shienryu_source_review',phase_id=a['phase_id'],action_sha256=action_sha,root_admission_sha256=admission_sha,
        started=time.time(),result='STARTED_NOT_ACCEPTED',events=[],cleanup_errors=[],CFG_observations=[],physical_HDMI_or_audio_acceptance=False)
    deadline=time.monotonic()+a['max_seconds'];jp=phase/'journal.json'
    def journal():save(jp,s)
    journal()
    with api.device() as (c,sf):
        sf.get_channel().settimeout(30)
        def identity(mode,epoch=None):
            state=api.state(c);must(api.idle(state['control'],mode,epoch),'Unexpected ownership/active input/epoch')
            g=state['game'];must(g.get('core_path')==RBF and g.get('game_path')==MRA and not g.get('error'),'Exact candidate changed');return state
        def guard():must(time.monotonic()<deadline,'Cooperative menu phase limit reached');return identity('assistant',s['epoch'])
        def wire(payload,label):
            payload={**payload,'id':'SHYF4M-'+uuid.uuid4().hex};e=dict(label=label,payload=payload,started=time.time());s['events'].append(e);journal()
            v=c.request(payload);e['reply']={k:z for k,z in v.items() if k!='data'};journal();must(v.get('id')==payload['id'],'Uncertain reply ID: no replay');return v
        def proof():
            found=[]
            for p in h.names(c):
                low=p.lower()
                if 'shyf0004' in low:continue
                if low.startswith('/media/fat/config/inputs/') or low.endswith('.map') or re.search('stv|st-v|shienryu|saturn',low):found.append(p)
            must(sorted(set(found))==protected['membership'],'Protected24 membership changed')
            must(h.hashes(c,protected['hashes'])==protected['hashes'],'Protected35 hashes changed')
            expected={x['remote']:x['sha256'] for x in r['files'].values()};must(h.hashes(c,expected)==expected,'Staged RBF/MRA/map changed')
            must(api.rbf_candidates(sf,RBF)==['SHYF0004.rbf'],'Candidate prefix became ambiguous')
            candidates=[p for p in h.names(c) if 'shyf0004' in p.lower()];must(set(candidates)<={CFG,NVM,MAP},'Unexpected candidate settings path')
            return candidates
        def runtime():
            command=r'''printf 'CORENAME:'; cat /tmp/CORENAME; printf '\n'; for menu_proc_exe in /proc/[0-9]*/exe; do menu_proc_target=$(readlink "$menu_proc_exe" 2>/dev/null) || continue; if [ "$menu_proc_target" = /media/fat/MiSTer ]; then printf 'MAIN_PROCESS %s %s\n' "$menu_proc_exe" "$menu_proc_target"; sha256sum "$menu_proc_exe"; strings "$menu_proc_exe" | sed -n '/^[$]VER:/p'; fi; done'''
            lines=h.shell(c,command).splitlines();must('CORENAME:SHYF0004' in lines,'Actual Main internal CFG namespace differs')
            processes=[x for x in lines if x.startswith('MAIN_PROCESS ')];must(processes==[f"MAIN_PROCESS /proc/{a['expected_Main_PID']}/exe /media/fat/MiSTer"],'Fresh Main process changed')
            must(MAIN_SHA+'  /proc/'+str(a['expected_Main_PID'])+'/exe' in lines and '$VER:261010' in lines,'Running Main release differs')
            return lines
        def remote_bytes(path,limit):
            info=sf.lstat(path);must(stat.S_ISREG(info.st_mode) and info.st_size<=limit,'Not bounded ordinary alias file')
            with sf.open(path,'rb') as f:return f.read(limit+1)
        def backup(label,path,limit):
            if not api.remote_exists(sf,path):return None
            raw=remote_bytes(path,limit);name=label+('-CFG.bin' if path==CFG else '-NVM.bin');dest=phase/name
            with dest.open('xb') as f:f.write(raw)
            return dict(remote=path,local=str(dest),bytes=len(raw),sha256=sha(dest))
        def initialize_keyboard():
            state=guard();must(42 not in h.WORDS,'Neutral initialization key is mapped')
            type(c).request.__globals__['preflight_input'](state['control'],1)
            v=wire({'mister':'input','device':'keyboard','key':'leftshift','duration_ms':1},'neutral-keyboard-initialization')
            must(v.get('success') is True and v.get('status')=='completed' and v.get('action_id')==v.get('id'),'Uncertain initialization outcome: no replay');guard()
            blocks=[b for b in h.shell(c,'cat /proc/bus/input/devices').split('\n\n') if 'N: Name="misterclaw"' in b]
            must(len(blocks)==1 and 'Bus=0003 Vendor=4711 Product=0815 Version=0001' in blocks[0] and 'kbd' in blocks[0],'Keyboard identity unverified')
            s['keyboard_identity']=blocks[0];journal();guard()
        def press(key):
            state=guard();type(c).request.__globals__['preflight_input'](state['control'],40)
            must(key in {'F12','up','left','right','enter','esc'},'No other input is in scope')
            v=wire({'mister':'input','device':'keyboard','key':key,'duration_ms':40},'menu-key-'+key)
            must(v.get('success') is True and v.get('status')=='completed' and v.get('action_id')==v.get('id'),'Uncertain input outcome: no replay')
            guard();time.sleep(.18)
        def five_up():
            for _ in range(5):press('up')
        def system_save():
            press('right');five_up();press('enter');time.sleep(.35)
        def saved(label,expected,baseline=None):
            until=min(deadline,time.monotonic()+5);raw=None
            while time.monotonic()<until:
                guard()
                if api.remote_exists(sf,CFG):
                    raw=remote_bytes(CFG,16)
                    if len(raw)==16 and bool(raw[10]&4)==expected:break
                time.sleep(.15)
            must(raw is not None and len(raw)==16 and bool(raw[10]&4)==expected,'Main Save CFG/state side effect not established; no key retry')
            if baseline is not None:must(all((x==y if i!=10 else (x&251)==(y&251)) for i,(x,y) in enumerate(zip(raw,baseline))),'A status bit other than82 changed')
            info=backup(label,CFG,16);must(info['sha256']==hashlib.sha256(raw).hexdigest(),'CFG changed during snapshot');nv=backup(label,NVM,65664)
            if nv is not None:must(nv['bytes']==65664,'Unexpected alias NVM geometry')
            entry=dict(label=label,status82=expected,CFG=info,NVM=nv,other_status_bits_unchanged=None if baseline is None else True,
                evidence='Main menu Save side effect; not direct FPGA/cursor/HDMI/audio readback')
            s['CFG_observations'].append(entry);s['latest_runtime_lines']=runtime();proof();journal();return raw
        try:
            s['before']=h.slim(identity('user',a['starting_user_epoch']));proof();s['runtime_before']=runtime()
            must(not api.remote_exists(sf,CFG),'Fresh baseline requires no prior CFG; do not guess a resume')
            s['NVM_before']=backup('before',NVM,65664);s['handoff_attempted']=True;journal()
            v=wire({'mister':'control','action':'assistant'},'acquire-once');s['epoch']=v.get('epoch');journal();must(bool(s['epoch']) and api.idle(v,'assistant',s['epoch']),'Assistant lease/epoch not proven');guard()
            initialize_keyboard()
            # Fresh boot: closed/page0/selection0. Enter selects pages/options; Right opens System.
            press('F12');time.sleep(.5);system_save();baseline=saved('baseline-Off',False)
            for label,expected in [('On',True),('final-Off',False)]:
                five_up();press('enter');five_up();press('enter');press('left');system_save();raw=saved(label,expected,baseline)
            must(raw==baseline,'Final Off does not exactly restore status baseline')
            press('esc');time.sleep(.3);guard();proof();s['result']='MENU_CFG_OFF_ON_OFF_PROVEN_PHYSICAL_OUTPUT_UNVERIFIED'
        except Exception as error:s.update(result='FAILED_STOPPED_NO_REPLAY',error=repr(error))
        finally:
            try:
                state=api.state(c)
                if s.get('epoch') and state['control'].get('mode')=='assistant' and state['control'].get('epoch')==s['epoch']:
                    v=wire({'mister':'control','action':'release_all'},'release-owned-inputs');must(api.idle(v,'assistant',s['epoch']),'Release not quiescent in owned epoch')
                    v=wire({'mister':'control','action':'user'},'handback-once');s['handback_epoch']=v.get('epoch');must(bool(s['handback_epoch']) and api.idle(v,'user',s['handback_epoch']),'Handback User epoch not proven')
                elif not api.idle(state['control'],'user'):
                    raise RuntimeError('Unknown ownership/outcome: no adoption; root recovery required')
                else:
                    s['ownership_already_User_no_adoption']=True
                    if s['result'].startswith('MENU_CFG_'):raise RuntimeError('Unexpected early ownership change prevents success')
                final=identity('user',s.get('handback_epoch'));s['final_state']=h.slim(final);proof();s['protected_originals_and_staging_unchanged']=True
                s['runtime_after']=runtime()
            except Exception as error:s['cleanup_errors'].append(repr(error))
            s['finished']=time.time();journal()
    print(json.dumps({k:s.get(k) for k in ['result','error','cleanup_errors','final_state','protected_originals_and_staging_unchanged','physical_HDMI_or_audio_acceptance']},indent=2))
    return 0 if s['result']=='MENU_CFG_OFF_ON_OFF_PROVEN_PHYSICAL_OUTPUT_UNVERIFIED' and not s['cleanup_errors'] else 1
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--action');p.add_argument('--action-sha256');p.add_argument('--admission');p.add_argument('--admission-sha256');a=p.parse_args()
    if a.execute:return execute(a.action,a.action_sha256,a.admission,a.admission_sha256)
    local();print(json.dumps(dict(state='UNFROZEN_LOCAL_ONLY_NO_DEVICE_ACCESS',script_sha256=sha(__file__),ready_sha256=READY_SHA,boot_journal_sha256=BOOT_SHA)));return 0
if __name__=='__main__':raise SystemExit(main())
