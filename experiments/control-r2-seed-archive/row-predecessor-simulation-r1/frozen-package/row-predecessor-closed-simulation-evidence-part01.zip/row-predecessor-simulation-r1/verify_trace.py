"""Streaming actual-scaler VCD checks; no simulator is launched here."""
import csv,hashlib,json
from pathlib import Path
COMMON=['o_clk','o_ce','o_reset_na','o_vacpt','o_vacptl','o_stride','o_rline','o_inter','o_bob_deint','o_iwfl','o_obuf0',
        'o_adrs_pre','o_flip_adrs_pre','o_adrs','o_adrsa','o_adrsb','o_read_pre','o_read','o_fload','o_hbcpt','o_flip_180']
def verify(path,output,variant,bob,reset):
    names=set(COMMON+(['o_vacpt_minus1'] if variant else []));codes={};scope=[];values={name:None for name in names}
    stats=dict(HDMI_edges=0,invariant_checks=0,product_checks=0,decrement_products=0,even_field_products=0,weave_products=0,
        consumed_decrement_Off=0,consumed_decrement_On=0,reset_retention_edges=0,ce_stall_edges=0,field0=0,field1=0)
    initialized=False;last_product=False;last_flip=False
    with Path(path).open() as f,Path(output).open('x',newline='') as out:
        writer=csv.writer(out);writer.writerow(['time']+COMMON[1:]);current=0;before=dict(values)
        def edge():
            nonlocal initialized,last_product,last_flip
            if before['o_clk']!=0 or values['o_clk']!=1:return
            stats['HDMI_edges']+=1
            row=values['o_vacpt']
            if row==1:initialized=True
            if initialized and row is not None:
                if variant:
                    assert values['o_vacpt_minus1']==(row-1)%4096,('RTL companion invariant',current,row,values['o_vacpt_minus1'])
                    stats['invariant_checks']+=1
                if values['o_reset_na']==0:stats['reset_retention_edges']+=1
            if values['o_ce']==0:stats['ce_stall_edges']+=1
            writer.writerow([current]+[values[k] for k in COMMON[1:]])
            oldrow=before['o_vacpt'];stride=before['o_stride'];critical=False
            valid=before['o_reset_na']==1 and values['o_reset_na']==1 and oldrow is not None and stride is not None
            if initialized and valid:
                operand=oldrow;field=None
                if before['o_iwfl'] is not None and before['o_obuf0'] is not None:
                    flags=before['o_iwfl'];index=before['o_obuf0']
                    if isinstance(flags,int):field=(flags>>index)&1
                    elif len(flags)>index and flags[-1-index] in '01':field=int(flags[-1-index])
                if before['o_inter']==1:
                    if field in (0,1):stats['field'+str(field)]+=1
                    if before['o_bob_deint']==1:
                        if field==0:
                            if oldrow!=0 and before['o_rline']!=1:operand=oldrow-1;critical=True;stats['decrement_products']+=1
                        else:operand=oldrow&~1;stats['even_field_products']+=1
                    else:stats['weave_products']+=1
                expected=operand*stride
                assert values['o_adrs_pre']==expected,('RTL product/address cycle',current,values['o_adrs_pre'],expected)
                stats['product_checks']+=1
                if before['o_adrsa']==1 and before['o_fload']==0:
                    if before['o_flip_180']==0 and last_product:stats['consumed_decrement_Off']+=1
                    if before['o_flip_180']==1 and last_flip:stats['consumed_decrement_On']+=1
                last_flip=last_product;last_product=critical
            else:last_product=False;last_flip=False
        header=True
        for raw in f:
            line=raw.strip()
            if header:
                tokens=line.split()
                if line.startswith('$scope'):scope.append(tokens[2])
                elif line.startswith('$upscope'):scope.pop()
                elif line.startswith('$var') and scope and scope[-1]=='dut':
                    name=tokens[4].split('[')[0]
                    if name in names:codes.setdefault(tokens[3],[]).append(name)
                elif line.startswith('$enddefinitions'):
                    found={x for items in codes.values() for x in items};assert found==names,('Missing VCD signals',names-found);header=False
                continue
            if line.startswith('#'):
                edge();before=dict(values);current=int(line[1:]);continue
            if not line or line.startswith('$'):continue
            if line[0] in 'bB':
                token,code=line.split();bits=token[1:]
            elif line[0] in '01xXzZuUwWlLhH-':bits,code=line[0],line[1:]
            else:continue
            value=int(bits,2) if bits and set(bits)<=set('01') else None
            for name in codes.get(code,[]):values[name]=bits if name=='o_iwfl' and value is None else value
        edge()
    assert stats['HDMI_edges']>50000 and stats['product_checks']>1000 and stats['field0']>0 and stats['field1']>0,stats
    if variant:assert stats['invariant_checks']>1000
    if bob:
        assert stats['decrement_products']>0 and stats['even_field_products']>0,stats
        assert stats['consumed_decrement_Off']>0 and stats['consumed_decrement_On']>0,stats
    else:assert stats['weave_products']>0,stats
    if reset:assert stats['reset_retention_edges']>0 and stats['ce_stall_edges']>0,stats
    with Path(output).open('rb') as f:stats['common_internal_trace_sha256']=hashlib.file_digest(f,'sha256').hexdigest()
    return stats
