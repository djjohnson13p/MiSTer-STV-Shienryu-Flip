"""First future worker step: exhaustive finite row-state and operand checks."""
def prove():
    states=operands=products=0
    for row in range(4096):
        predecessor=(row-1)%4096
        for operation in ('initialize','hold','increment','reset-retain'):
            newrow,newpred=row,predecessor
            if operation=='initialize':newrow,newpred=1,0
            if operation=='increment':newrow,newpred=(row+1)%4096,row
            assert newpred==(newrow-1)%4096;states+=1
        for inter in (0,1):
            for bob in (0,1):
                for field in (0,1):
                    for lagged_parity in (0,1):
                        old=new=row
                        if inter and bob:
                            if field==0:
                                if row!=0 and lagged_parity!=1:old=row-1;new=predecessor
                            else:old=new=row&~1
                        assert old==new;operands+=1
                        for stride in (0,1,127,128,129,256,960,1280,16383):
                            assert old*stride==new*stride;products+=1
    assert states==16384 and operands==65536 and products==589824
    return dict(row_values=4096,state_transitions=states,guarded_operand_cases=operands,representative_product_cases=products,
        all_stride_equivalence='Follows identical guarded integer operand, not a claim of exhaustive14-bit stride enumeration',
        reset_semantics='retained row and predecessor; first existing initialization establishes valid relation',timing_claim=False)
