library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;
use std.env.all;

entity tb_ascal_flip is
  generic (W : positive := 8; H : positive := 4; TEST_MODE : natural := 2; V_TOP : natural := 2; LOG_PREFIX : string := "case8x4");
end entity;

architecture bench of tb_ascal_flip is
  constant ROW_BYTES : positive := ((W*4+127)/128)*128;
  constant FRAME_WORDS : positive := ROW_BYTES*H/16;
  signal iclk : std_logic := '0';
  signal oclk : std_logic := '0';
  signal aclk : std_logic := '0';
  signal reset_n : std_logic := '0';
  signal flip : std_logic := '0';
  signal r,g,b : unsigned(7 downto 0);
  signal hs,vs,de,vbl,brd : std_logic;
  signal avl_addr : std_logic_vector(15 downto 0);
  signal avl_data : std_logic_vector(127 downto 0) := (others=>'0');
  signal avl_wdata : std_logic_vector(127 downto 0);
  signal avl_be : std_logic_vector(15 downto 0);
  signal avl_burst : std_logic_vector(7 downto 0);
  signal avl_read,avl_write : std_logic;
  signal avl_valid : std_logic := '0';
  signal avl_wait : std_logic := '0';
  signal remaining : natural := 0;
  signal read_word : natural := 0;
  signal accepted_reads : natural := 0;
  signal checked_pixels : natural := 0;
  signal finished : boolean := false;

  function pixel(x,y : natural) return unsigned is
    variable value : unsigned(31 downto 0);
  begin
    -- Independent, asymmetric picture oracle; alpha is an ignored marker.
    value(31 downto 24):=to_unsigned((y*29+x+17) mod 251,8);
    value(23 downto 16):=to_unsigned((x*3+31) mod 251,8);
    value(15 downto 8):=to_unsigned((y*7+61) mod 251,8);
    value(7 downto 0):=x"A5";
    return value;
  end function;

  function memory_word(address : natural) return std_logic_vector is
    variable data : unsigned(127 downto 0) := (others=>'0');
    variable byte_address,x,y : natural;
  begin
    for lane in 0 to 3 loop
      byte_address:=address*16+lane*4;
      y:=byte_address/ROW_BYTES;
      x:=(byte_address mod ROW_BYTES)/4;
      if x<W and y<H then
        data(127-lane*32 downto 96-lane*32):=pixel(x,y);
      else
        -- Padding/outside-picture reads must never become visible pixels.
        data(127-lane*32 downto 96-lane*32):=x"EECC99A5";
      end if;
    end loop;
    return std_logic_vector(data);
  end function;
begin
  iclk<=not iclk after 7 ns;
  oclk<=not oclk after 5 ns;
  aclk<=not aclk after 2 ns;
  reset_n<='1' after 100 ns;
  avl_wait<='1' when remaining>0 else '0';

  dut: entity work.ascal
    generic map (RAMBASE=>x"00000000",RAMSIZE=>x"00001000",INTER=>false,
      HEADER=>false,DOWNSCALE=>false,BYTESWAP=>false,PALETTE=>false,
      PALETTE2=>false,ADAPTIVE=>false,OHRES=>2048,IHRES=>64,
      N_DW=>128,N_AW=>16,N_BURST=>128)
    port map (
      i_r=>x"00",i_g=>x"00",i_b=>x"00",i_hs=>'0',i_vs=>'0',i_fl=>'0',
      i_de=>'0',i_ce=>'0',i_clk=>iclk,
      o_r=>r,o_g=>g,o_b=>b,o_hs=>hs,o_vs=>vs,o_de=>de,o_vbl=>vbl,o_brd=>brd,
      o_ce=>'1',o_clk=>oclk,o_border=>x"020304",
      o_fb_ena=>'1',o_fb_hsize=>W,o_fb_vsize=>H,o_fb_format=>"000110",
      o_fb_base=>x"00000000",o_fb_stride=>to_unsigned(ROW_BYTES,14),
      pal1_dr=>open,pal2_dr=>open,o_lltune=>open,
      iauto=>'0',himin=>0,himax=>W-1,vimin=>0,vimax=>H-1,
      i_hdmax=>open,i_vdmax=>open,run=>'1',freeze=>'1',mode=>"00000",flip_180=>flip,
      htotal=>256,hsstart=>200,hsend=>208,hdisp=>W+32,hmin=>16,hmax=>W+15,
      vtotal=>H+10,vsstart=>H+7,vsend=>H+8,vdisp=>H+4,vmin=>V_TOP,vmax=>H+V_TOP-1,
      poly_clk=>oclk,poly_dw=>(others=>'0'),poly_a=>(others=>'0'),poly_wr=>'0',
      avl_clk=>aclk,avl_waitrequest=>avl_wait,avl_readdata=>avl_data,
      avl_readdatavalid=>avl_valid,avl_burstcount=>avl_burst,avl_writedata=>avl_wdata,
      avl_address=>avl_addr,avl_write=>avl_write,avl_read=>avl_read,
      avl_byteenable=>avl_be,reset_na=>reset_n);

  avalon: process(aclk)
    file log : text open write_mode is LOG_PREFIX & "-reads.csv";
    variable row : line;
    variable addr,count : natural;
  begin
    if rising_edge(aclk) then
      avl_valid<='0';
      if reset_n='0' then
        remaining<=0;
      else
        assert avl_write/='1' report "Unexpected framebuffer write in frozen framebuffer-mode test" severity failure;
        if remaining>0 then
          avl_data<=memory_word(read_word);
          avl_valid<='1';
          read_word<=read_word+1;
          remaining<=remaining-1;
        end if;
        if avl_read='1' and avl_wait='0' then
          addr:=to_integer(unsigned(avl_addr));
          count:=to_integer(unsigned(avl_burst));
          assert count=8 report "Unexpected burst count" severity failure;
          assert addr+count<=4096/16 report "Avalon access outside allocated framebuffer" severity failure;
          assert addr mod 8=0 report "Unaligned burst address" severity failure;
          read_word<=addr;
          remaining<=count;
          accepted_reads<=accepted_reads+1;
          write(row,now);write(row,string'(","));write(row,addr);
          write(row,string'(","));write(row,count);writeline(log,row);
        end if;
      end if;
    end if;
  end process;

  capture: process
    file log : text open write_mode is LOG_PREFIX & "-pixels.csv";
    variable row : line;
    variable old_vs : std_logic := '0';
    variable frame,pindex,x,y,ex,ey,complete_frames : natural := 0;
    variable expected : unsigned(31 downto 0);
    variable is_flip : boolean;
  begin
    wait until rising_edge(oclk);
    wait for 1 ns;
    if reset_n='1' then
      if old_vs='1' and vs='0' then
        if frame>=3 then
          assert pindex=W*H report "Incomplete/oversize active picture in frame " & integer'image(frame) & " count=" & integer'image(pindex) severity failure;
          complete_frames:=complete_frames+1;
        end if;
        frame:=frame+1;
        pindex:=0;
        report "FRAME " & integer'image(frame) & " menu=" & std_logic'image(flip) severity note;
        if frame=11 then
          assert complete_frames=8 report "Missing checked frames" severity failure;
          assert checked_pixels=8*W*H report "Pixel coverage mismatch" severity failure;
          assert accepted_reads>20 report "Framebuffer reader did not run" severity failure;
          report "PASS: actual ascal Off/180/Off, mid-frame transition, " & integer'image(checked_pixels) & " pixels" severity note;
          finished<=true;
          stop;
        end if;
      end if;
      old_vs:=vs;
      if de='1' and brd='0' then
        x:=pindex mod W;y:=pindex/W;
        write(row,frame);write(row,string'(","));write(row,x);write(row,string'(","));write(row,y);
        write(row,string'(","));write(row,to_integer(r));write(row,string'(","));write(row,to_integer(g));write(row,string'(","));write(row,to_integer(b));writeline(log,row);
        if frame>=3 then
          assert pindex<W*H report "Too many active-picture pixels" severity failure;
          is_flip:=(TEST_MODE=1) or (TEST_MODE=2 and frame>=6 and frame<=8);
          if is_flip then ex:=W-1-x;ey:=H-1-y;else ex:=x;ey:=y;end if;
          expected:=pixel(ex,ey);
          assert r=expected(31 downto 24) and g=expected(23 downto 16) and b=expected(15 downto 8)
            report "Pixel mismatch frame=" & integer'image(frame) & " xy=" & integer'image(x) & "," & integer'image(y) & " expected=" & to_hstring(expected) & " actual=" & to_hstring(r&g&b)
            severity failure;
          checked_pixels<=checked_pixels+1;
        end if;
        pindex:=pindex+1;
        if TEST_MODE=1 and frame=1 then flip<='1';end if;
        if TEST_MODE=2 and frame=5 and pindex=W+4 then flip<='1';end if;
        if TEST_MODE=2 and frame=8 and pindex=W+4 then flip<='0';end if;
      end if;
    end if;
  end process;

  watchdog: process
  begin
    wait for 1 ms;
    assert finished report "Simulation did not reach required checked frames" severity failure;
    wait;
  end process;
end architecture;
