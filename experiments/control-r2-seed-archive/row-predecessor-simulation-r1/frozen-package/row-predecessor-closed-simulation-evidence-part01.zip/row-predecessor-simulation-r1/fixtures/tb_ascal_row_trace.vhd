library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;
use std.env.all;

entity tb_ascal_row_trace is
  generic (W : positive := 8; H : positive := 4; TEST_MODE : natural := 2; V_TOP : natural := 2; BOB : boolean := true; RESET_MID : boolean := false; CE_STALL : boolean := false; LOG_PREFIX : string := "case8x4");
end entity;

architecture bench of tb_ascal_row_trace is
  constant ROW_BYTES : positive := ((W*4+127)/128)*128;
  constant FRAME_WORDS : positive := ROW_BYTES*H/16;
  signal iclk : std_logic := '0';
  signal oclk : std_logic := '0';
  signal aclk : std_logic := '0';
  signal reset_n : std_logic := '0';
  signal flip : std_logic := '0';
  signal r,g,b : unsigned(7 downto 0);
  signal hs,vs,de,vbl,brd : std_logic;
  signal avl_addr : std_logic_vector(15 downto 0);
  signal avl_data : std_logic_vector(127 downto 0) := (others=>'0');
  signal avl_wdata : std_logic_vector(127 downto 0);
  signal avl_be : std_logic_vector(15 downto 0);
  signal avl_burst : std_logic_vector(7 downto 0);
  signal avl_read,avl_write : std_logic;
  signal avl_valid : std_logic := '0';
  signal avl_wait : std_logic := '0';
  signal remaining : natural := 0;
  signal read_word : natural := 0;
  signal accepted_reads : natural := 0;
  signal checked_pixels : natural := 0;
  signal finished : boolean := false;

  signal stim_vs,stim_fl,stim_de,stim_ce : std_logic := '0';
  signal output_ce : std_logic := '1';
  function flag(v : boolean) return std_logic is
  begin
    if v then return '1'; else return '0'; end if;
  end function;
  function pixel(x,y : natural) return unsigned is
    variable value : unsigned(31 downto 0);
  begin
    -- Independent, asymmetric picture oracle; alpha is an ignored marker.
    value(31 downto 24):=to_unsigned((y*29+x+17) mod 251,8);
    value(23 downto 16):=to_unsigned((x*3+31) mod 251,8);
    value(15 downto 8):=to_unsigned((y*7+61) mod 251,8);
    value(7 downto 0):=x"A5";
    return value;
  end function;

  function memory_word(address : natural) return std_logic_vector is
    variable data : unsigned(127 downto 0) := (others=>'0');
    variable byte_address,x,y : natural;
  begin
    for lane in 0 to 3 loop
      byte_address:=address*16+lane*4;
      y:=byte_address/ROW_BYTES;
      x:=(byte_address mod ROW_BYTES)/4;
      if x<W and y<H then
        data(127-lane*32 downto 96-lane*32):=pixel(x,y);
      else
        -- Padding/outside-picture reads must never become visible pixels.
        data(127-lane*32 downto 96-lane*32):=x"EECC99A5";
      end if;
    end loop;
    return std_logic_vector(data);
  end function;
begin
  iclk<=not iclk after 7 ns;
  oclk<=not oclk after 5 ns;
  aclk<=not aclk after 2 ns;
  reset_driver: process
  begin
    reset_n<='0';wait for 100 ns;reset_n<='1';
    if RESET_MID then wait for 479900 ns;reset_n<='0';wait for 100 ns;reset_n<='1';end if;
    wait;
  end process;
  -- Actual input field detection; freeze prevents writes to the golden framebuffer.
  input_fields: process(iclk)
    variable x,v : natural := 0;
    variable field : std_logic := '0';
  begin
    if rising_edge(iclk) then
      if reset_n='0' then
        x:=0;v:=0;field:='0';stim_ce<='0';stim_de<='0';stim_vs<='0';stim_fl<='0';
      elsif now>=150 us then
        stim_ce<='1';stim_fl<=field;
        if v=H/2+4 then stim_vs<='1';else stim_vs<='0';end if;
        if x<W and v<H/2 then stim_de<='1';else stim_de<='0';end if;
        if x=255 then
          x:=0;
          if v=H/2+7 then v:=0;field:=not field;else v:=v+1;end if;
        else x:=x+1;end if;
      end if;
    end if;
  end process;
  ce_driver: process(oclk)
    variable cycle : natural := 0;
  begin
    if rising_edge(oclk) then
      cycle:=cycle+1;
      if CE_STALL and cycle mod 7=3 then output_ce<='0';else output_ce<='1';end if;
    end if;
  end process;
  flip<='0','1' after 250 us,'0' after 650 us;
  avl_wait<='1' when remaining>0 else '0';

  dut: entity work.ascal
    generic map (RAMBASE=>x"00000000",RAMSIZE=>x"00001000",INTER=>true,
      HEADER=>false,DOWNSCALE=>false,BYTESWAP=>false,PALETTE=>false,
      PALETTE2=>false,ADAPTIVE=>false,OHRES=>2048,IHRES=>64,
      N_DW=>128,N_AW=>16,N_BURST=>128)
    port map (
      i_r=>x"00",i_g=>x"00",i_b=>x"00",i_hs=>'0',i_vs=>stim_vs,i_fl=>stim_fl,
      i_de=>stim_de,i_ce=>stim_ce,i_clk=>iclk,
      o_r=>r,o_g=>g,o_b=>b,o_hs=>hs,o_vs=>vs,o_de=>de,o_vbl=>vbl,o_brd=>brd,
      o_ce=>output_ce,o_clk=>oclk,o_border=>x"020304",
      o_fb_ena=>'1',o_fb_hsize=>W,o_fb_vsize=>H,o_fb_format=>"000110",
      o_fb_base=>x"00000000",o_fb_stride=>to_unsigned(ROW_BYTES,14),
      pal1_dr=>open,pal2_dr=>open,o_lltune=>open,
      iauto=>'0',himin=>0,himax=>W-1,vimin=>0,vimax=>H/2-1,
      i_hdmax=>open,i_vdmax=>open,run=>'1',freeze=>'1',mode=>"00000",flip_180=>flip,bob_deint=>flag(BOB),
      htotal=>256,hsstart=>200,hsend=>208,hdisp=>W+32,hmin=>16,hmax=>W+15,
      vtotal=>H+10,vsstart=>H+7,vsend=>H+8,vdisp=>H+4,vmin=>V_TOP,vmax=>H+V_TOP-1,
      poly_clk=>oclk,poly_dw=>(others=>'0'),poly_a=>(others=>'0'),poly_wr=>'0',
      avl_clk=>aclk,avl_waitrequest=>avl_wait,avl_readdata=>avl_data,
      avl_readdatavalid=>avl_valid,avl_burstcount=>avl_burst,avl_writedata=>avl_wdata,
      avl_address=>avl_addr,avl_write=>avl_write,avl_read=>avl_read,
      avl_byteenable=>avl_be,reset_na=>reset_n);

  avalon: process(aclk)
    file log : text open write_mode is LOG_PREFIX & "-reads.csv";
    variable row : line;
    variable addr,count : natural;
  begin
    if rising_edge(aclk) then
      avl_valid<='0';
      if reset_n='0' then
        remaining<=0;
      else
        assert avl_write/='1' report "Unexpected framebuffer write in frozen framebuffer-mode test" severity failure;
        if remaining>0 then
          avl_data<=memory_word(read_word);
          avl_valid<='1';
          read_word<=read_word+1;
          remaining<=remaining-1;
        end if;
        if avl_read='1' and avl_wait='0' then
          addr:=to_integer(unsigned(avl_addr));
          count:=to_integer(unsigned(avl_burst));
          assert count=8 report "Unexpected burst count" severity failure;
          assert addr+count<=4096/16 report "Avalon access outside allocated framebuffer" severity failure;
          assert addr mod 8=0 report "Unaligned burst address" severity failure;
          read_word<=addr;
          remaining<=count;
          accepted_reads<=accepted_reads+1;
          write(row,now);write(row,string'(","));write(row,addr);
          write(row,string'(","));write(row,count);writeline(log,row);
        end if;
      end if;
    end if;
  end process;

  -- Golden-reference output trace, not the progressive pixel oracle.
  capture: process
    file log : text open write_mode is LOG_PREFIX & "-pixels.csv";
    variable row : line;
  begin
    wait until rising_edge(oclk);wait for 1 ns;
    write(row,now);write(row,string'(","));write(row,std_logic'image(reset_n));write(row,string'(","));write(row,std_logic'image(output_ce));
    write(row,string'(","));write(row,std_logic'image(hs));write(row,string'(","));write(row,std_logic'image(vs));write(row,string'(","));write(row,std_logic'image(de));write(row,string'(","));write(row,std_logic'image(brd));
    write(row,string'(","));write(row,to_integer(r));write(row,string'(","));write(row,to_integer(g));write(row,string'(","));write(row,to_integer(b));writeline(log,row);
  end process;
  finish: process
  begin
    wait for 900 us;
    assert accepted_reads>20 report "Focused scaler reader did not run" severity failure;
    report "TRACE_PASS: actual scaler field/bob/reset golden-reference trace" severity note;
    stop;wait;
  end process;
end architecture;
