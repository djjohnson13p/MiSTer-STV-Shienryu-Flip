"""Fixed simulator-only worker; execute only through the root-reviewed Job adapter."""
import argparse,hashlib,json,os,re,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
from mathematics import prove
from verify_trace import verify
BASE=Path(__file__).resolve().parent
GHDL=Path('C:/Users/djjoh/MiSTer-Rebuild/Tools/ghdl-6.0.0-mingw64/distribution/bin/ghdl.exe')
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,value):
    with p.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
def old_captures():
    index=json.loads((BASE/'inherited-capture-hashes.json').read_text())
    assert len(index)==42
    for p,h in index.items():assert sha(p)==h,'Old capture changed: '+p
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--owned-worker',action='store_true');parser.add_argument('--output');args=parser.parse_args()
    assert args.owned_worker,'Use reviewed run_reviewed.py --run'
    out=Path(args.output).resolve();assert out==BASE/'guarded-run-r1' and out.is_dir()
    assert not (out/'worker-results.json').exists(),'No replay of a prior worker'
    manifest=json.loads((BASE/'manifest.json').read_text());results=[];commands=[];error=None
    # Canonical guard's legacy Quartus environment injection is irrelevant to this application.
    env=dict(os.environ);env.pop('QUARTUS_ROOTDIR',None);env.pop('GHDL_PREFIX',None)
    quartus_bin=os.path.normcase('C:/altera_lite/25.1std/quartus/bin64')
    env['PATH']=str(GHDL.parent)+os.pathsep+os.pathsep.join(x for x in env.get('PATH','').split(os.pathsep) if os.path.normcase(x)!=quartus_bin)
    def command(argv,cwd,label):
        assert Path(argv[0]).resolve()==GHDL.resolve(),'Only the pinned GHDL executable may be launched'
        assert cwd.resolve().is_relative_to(out) and not cwd.exists(),'Fresh capture/elaboration cwd required'
        cwd.mkdir(parents=True);log=cwd/'command.log'
        with log.open('x',encoding='utf-8') as stream:r=subprocess.run(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        text=log.read_text(encoding='utf-8',errors='replace');row=dict(label=label,command=argv,cwd=str(cwd),exit_code=r.returncode,log_sha256=sha(log));commands.append(row)
        print(json.dumps(row),flush=True);assert r.returncode==0,'GHDL failure: '+label
        return text
    try:
        old_captures()
        # First semantic step; no simulator starts unless all finite mathematical cases pass.
        proof=prove();save(out/'mathematics-result.json',proof);print(json.dumps(dict(mathematics=proof)),flush=True)
        version=command([str(GHDL),'--version'],out/'tool-version','pinned-tool-version');assert 'GHDL 6.0.0' in version
        fixtures=[BASE/'fixtures'/name for name in manifest['fixtures']]
        for flavor in ('reference','variant'):
            # Exact FPGA source syntax/elaboration, then the identical inherited simulation shim.
            for exactness in ('exact','sim'):
                lib=out/f'library-{flavor}-{exactness}';assert not lib.exists();lib.mkdir()
                common=[str(GHDL),'--std=08','--workdir='+str(lib)]
                command([common[0],'-a',*common[1:],str(BASE/f'{flavor}.{exactness}.vhd'),*[str(p) for p in fixtures]],out/f'analyze-{flavor}-{exactness}','analyze-'+flavor+'-'+exactness)
                for entity in manifest['entities']:
                    command([common[0],'-e',*common[1:],entity],out/f'elaborate-{flavor}-{exactness}-{entity}','elaborate-'+flavor+'-'+exactness+'-'+entity)
        for case in manifest['cases']:
            pair={}
            for flavor in ('reference','variant'):
                cwd=out/'cases'/case['name']/flavor;lib=out/f'library-{flavor}-sim'
                argv=[str(GHDL),'-r','--std=08','--workdir='+str(lib),case['entity'],
                    '-gW='+str(case['W']),'-gH='+str(case['H']),'-gTEST_MODE='+str(case['mode']),'-gV_TOP=2','-gLOG_PREFIX=capture']
                if case['focused']:argv+=['-gBOB='+str(case['bob']).lower(),'-gRESET_MID='+str(case['reset']).lower(),'-gCE_STALL='+str(case['reset']).lower()]
                argv+=['--assert-level=error','--ieee-asserts=disable','--stop-time=1ms']
                if case['focused']:argv+=['--vcd=trace.vcd']
                text=command(argv,cwd,case['name']+'-'+flavor)
                for name in ('capture-reads.csv','capture-pixels.csv'):assert (cwd/name).is_file() and (cwd/name).stat().st_size>0
                if case['focused']:
                    assert 'TRACE_PASS: actual scaler field/bob/reset golden-reference trace' in text
                    stats=verify(cwd/'trace.vcd',cwd/'internal-trace.csv',flavor=='variant',case['bob'],case['reset'])
                else:
                    match=re.search(r'PASS: actual ascal Off/180/Off, mid-frame transition, (\d+) pixels',text)
                    assert match and int(match[1])==8*case['W']*case['H'],'Independent pixel oracle/coverage did not complete'
                    stats=dict(independent_oracle_pixels=int(match[1]))
                    if case['entity']=='tb_ascal_flip24_stall':
                        stalled=re.search(r'AVALON_STALLED_CYCLES=(\d+)',text);assert stalled and int(stalled[1])>0;stats['stalled_command_cycles']=int(stalled[1])
                pair[flavor]=dict(stats=stats,reads_sha256=sha(cwd/'capture-reads.csv'),pixels_sha256=sha(cwd/'capture-pixels.csv'))
            assert pair['reference']['reads_sha256']==pair['variant']['reads_sha256'],'Avalon address/time/burst trace differs'
            assert pair['reference']['pixels_sha256']==pair['variant']['pixels_sha256'],'RGB/control trace differs'
            if case['focused']:assert pair['reference']['stats']['common_internal_trace_sha256']==pair['variant']['stats']['common_internal_trace_sha256'],'Internal row/address/flip/read pipeline differs'
            results.append(dict(case=case['name'],flavors=pair,scope='Actual RTL golden trace' if case['focused'] else 'Actual RTL independent pixel oracle and golden read trace'))
        old_captures()
    except Exception as exc:error=repr(exc)
    finally:
        # All subprocess.run calls have returned; the outer Job guard proves whole-tree/handle termination.
        members={}
        for p in sorted(out.rglob('*')):
            if p.is_file() and p.name not in ('live.json','result.json','fullflow.log'):members[p.relative_to(out).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p))
        save(out/'worker-results.json',dict(state='PASS' if error is None else 'FAILED_STOPPED',cases=results,error=error,commands=commands,
            members_before_final_report=members,scope='Simulation only; no FPGA timing/hardware claim',old_captures_preserved=error is None))
    return 0 if error is None else 1
if __name__=='__main__':raise SystemExit(main())
