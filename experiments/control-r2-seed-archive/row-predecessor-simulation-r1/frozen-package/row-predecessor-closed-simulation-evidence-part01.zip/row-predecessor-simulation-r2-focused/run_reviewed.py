"""Default validates the simulator template only. --run requires exact root admission."""
import argparse,hashlib,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
LAB=BASE.parents[2]
PYTHON=Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
MIB=1024**2;GIB=1024**3
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=512*MIB,tree_rss_bytes=384*MIB,
    admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=4*GIB)
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def validate():
    m=load(BASE/'manifest.json');assert m['source_commit']=='7e987bb9ef0361356be22be13551e4626902f3a7' and m['limits']==LIMITS
    assert sha(BASE/'quartus_job_guard.py')==sha(LAB/'scripts/quartus_job_guard.py')==GUARD_SHA
    for p,h in m['bound_files'].items():assert sha(p)==h,'Bound simulator input changed: '+p
    assert m['reference_exact_sha256']=='c958d7499eefe7bf2cc4f094aec951b4dbadf4a88b00820ddd0de2291a8a9134'
    assert Path(sys.executable).resolve()==PYTHON.resolve()
    return m
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',action='store_true');p.add_argument('--review');p.add_argument('--review-sha256');a=p.parse_args();m=validate()
    if not a.run:
        print(json.dumps(dict(state='UNFROZEN_REVIEW_ONLY_NO_MATH_GHDL_JOB_OR_OUTPUT_CREATION',manifest_sha256=sha(BASE/'manifest.json'),limits=LIMITS,cases=len(m['cases']))));return 0
    review=Path(a.review);assert review.is_absolute() and review.is_file() and not review.is_symlink() and sha(review)==a.review_sha256
    q=load(review);assert q['reviewer']=='root' and q['decision']=='ACCEPTED_ROW_PREDECESSOR_FOCUSED_SIMULATION_ONLY'
    assert q['manifest_sha256']==sha(BASE/'manifest.json') and q['runner_sha256']==sha(__file__) and q['limits']==LIMITS
    assert q['source_commit']==m['source_commit'] and q['no_Quartus_or_device_action'] is True
    out=BASE/'guarded-run-r2';assert not out.exists(),'Existing attempt preserved; no automatic resume/replay';out.mkdir()
    spec=importlib.util.spec_from_file_location('canonical_owned_application_guard',BASE/'quartus_job_guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
    def inputs():return {**{p:sha(p) for p in m['bound_files']},str(BASE/'manifest.json'):sha(BASE/'manifest.json'),str(review):sha(review)}
    g.LAB=LAB;g.BASE=out;g.TREE=out;g.BASELINE=m['source_commit'];g.EXE=PYTHON
    g.COMMAND=[str(PYTHON),'-B','-X','utf8','-u',str(BASE/'simulate.py'),'--owned-worker','--output',str(out)]
    g.RUN_KIND='row-predecessor-focused-math-and-GHDL-only';g.LIMITS=dict(LIMITS);g.inputs=inputs
    before=inputs();g.save(out/'admission.json',dict(root_review=str(review),root_review_sha256=a.review_sha256,manifest_sha256=sha(BASE/'manifest.json'),limits=LIMITS,
        command=g.COMMAND,legacy_guard_quartus_sh_hash_field='Pinned Python application hash; no Quartus executable is launched'))
    code=g.run(before);result=load(out/'result.json')
    source_ok=result.get('changed_bound_inputs')=={}
    if (out/'worker-results.json').exists():source_ok=source_ok and load(out/'worker-results.json')['state']=='PASS'
    else:source_ok=False
    g.save(out/'adapter-readback.json',dict(root_review_sha256=a.review_sha256,manifest_sha256=sha(BASE/'manifest.json'),inputs_unchanged=source_ok,
        native_build_executed=False,scope='Simulation only; no timing or hardware acceptance',adapter_success=code==0 and source_ok))
    return 0 if code==0 and source_ok else 1
if __name__=='__main__':raise SystemExit(main())
