# Focused replay r2 — pending root review

R1 terminal1 is a reference reset/toggle-protocol failure at480.385us, after the fixture hard reset480.000–480.100us. The8 progressive cases passed actual pixel oracles and complete reference/variant Avalon+RGB CSV equality. All179 bound inputs remain unchanged.

This separate replay keeps all4 exact/sim scaler sources, the inherited zero-offset shift shim, focused fixture, checker and math byte-identical. Only case selection/stimulus generics change: bob with output CE gaps, and weave, both RESET_MID=false. Do not repair the inherited reset protocol or claim arbitrary-reset RTL verification. The original reset branch is stopped. Mathematics still covers companion reset retention.

Future reviewed run uses new guarded-run-r2 only, fresh libraries/elaboration/capture cwd for every command, reference before variant, exact-source analysis/elaboration then identical SIM-only shim execution. Same pinned Python/GHDL6.0.0, hidden processes, canonical Job guard,512MiB private/384MiB RSS/12GiB admission/4GiB floor/no wall. No Quartus/device action. Both focused cases must cover fields0/1 and compare full RGB/control, Avalon address/time/burst and internal address/control CSVs. Bob must consume the predecessor-product path with flip Off and On; output CE gaps must be observed.

Default validation hashes only. --run additionally needs exact root admission ACCEPTED_ROW_PREDECESSOR_FOCUSED_SIMULATION_ONLY binding manifest/runner/source/limits. No execution performed during preparation. No FPGA timing benefit or hardware acceptance claimed.
