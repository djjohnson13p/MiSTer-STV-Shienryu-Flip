$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$base = 'C:\Users\djjoh\Downloads\MiSTer-Rebuild-Kit\MiSTer-Rebuild-Kit\core-lab\research\shienryu-timing-20261024\row-predecessor-seed05-fit-sta-r1'
$name = 'CoreLab-Shienryu-RowPredecessor-Seed05-FitASMSTA-Q251-R1'
$user = 'DESKTOP-8SVI9NM\djjohnson13p'
if ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name -ne $user) { throw 'Current principal changed' }
if (Get-ScheduledTask -TaskName $name -TaskPath '\' -ErrorAction SilentlyContinue) { throw 'Exact task already exists; do not duplicate' }
$pins = Get-Content -Raw -LiteralPath (Join-Path $base 'frozen-pins.json') | ConvertFrom-Json
$actionPath = Join-Path $base 'scheduler-action-inline.ps1'
$hasher = [Security.Cryptography.SHA256]::Create()
try { $hashBytes = $hasher.ComputeHash([IO.File]::ReadAllBytes($actionPath)) } finally { $hasher.Dispose() }
$actionHash = ([BitConverter]::ToString($hashBytes)).Replace('-', '').ToLowerInvariant()
if ($actionHash -ne $pins.'scheduler-action-inline.ps1') { throw 'Frozen action source changed' }
$inline = Get-Content -Raw -LiteralPath $actionPath
$arguments = '-NoProfile -NonInteractive -WindowStyle Hidden -EncodedCommand ' + [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($inline))
$execute = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
$action = New-ScheduledTaskAction -Execute $execute -Argument $arguments -WorkingDirectory $base
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden
$task = New-ScheduledTask -Action $action -Principal $principal -Settings $settings
Register-ScheduledTask -TaskName $name -TaskPath '\' -InputObject $task -ErrorAction Stop | Out-Null
$xmlText = Export-ScheduledTask -TaskName $name -TaskPath '\'
$xmlText | Set-Content -LiteralPath (Join-Path $base 'registered-task.xml') -Encoding UTF8
[xml]$xml = $xmlText
if ($xml.SelectSingleNode("//*[local-name()='ExecutionTimeLimit']").InnerText -ne 'PT0S') { throw 'Task execution timer is not disabled' }
if ($xml.SelectSingleNode("//*[local-name()='Triggers']").HasChildNodes) { throw 'Unexpected automatic task trigger' }
if ($xml.SelectSingleNode("//*[local-name()='RestartOnFailure']")) { throw 'Unexpected automatic retries' }
if ($xml.SelectSingleNode("//*[local-name()='LogonType']").InnerText -ne 'InteractiveToken') { throw 'Unexpected logon type' }
$runLevelNode = $xml.SelectSingleNode("//*[local-name()='RunLevel']")
# LeastPrivilege is the XML default and was omitted by this host in the prior reviewed task.
if ($runLevelNode -and $runLevelNode.InnerText -ne 'LeastPrivilege') { throw 'Unexpected run level' }
if ($xml.SelectSingleNode("//*[local-name()='UserId']").InnerText -ne [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value) { throw 'Registered user differs' }
if ($xml.SelectSingleNode("//*[local-name()='MultipleInstancesPolicy']").InnerText -ne 'IgnoreNew') { throw 'Unexpected multiple-instance policy' }
if ($xml.SelectSingleNode("//*[local-name()='Hidden']").InnerText -ne 'true') { throw 'Task is not hidden' }
$registered = Get-ScheduledTask -TaskName $name -TaskPath '\'
if ($registered.Principal.RunLevel -ne 'Limited') { throw 'Registered principal is not Limited' }
if ($registered.Actions.Count -ne 1 -or $registered.Actions[0].Execute -ne $execute -or $registered.Actions[0].Arguments -ne $arguments -or $registered.Actions[0].WorkingDirectory -ne $base) { throw 'Registered action differs' }
[pscustomobject]@{task_name=$name; task_path='\'; action_source_sha256=$actionHash; registering_exec_pid=$PID; utc=(Get-Date).ToUniversalTime().ToString('o'); no_triggers=$true; no_retries=$true; execution_time_limit='PT0S'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $base 'registration-receipt.json') -Encoding UTF8
Start-ScheduledTask -TaskName $name -TaskPath '\'
[pscustomobject]@{task_name=$name; demand_start_requested=$true; utc=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $base 'start-receipt.json') -Encoding UTF8
Get-Content -LiteralPath (Join-Path $base 'start-receipt.json')
