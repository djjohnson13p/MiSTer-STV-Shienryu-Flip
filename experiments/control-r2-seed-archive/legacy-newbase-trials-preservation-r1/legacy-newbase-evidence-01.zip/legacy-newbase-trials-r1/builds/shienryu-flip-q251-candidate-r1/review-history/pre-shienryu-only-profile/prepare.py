"""Template plan by default. --freeze requires an exact root-reviewed candidate commit; never launches a task or compiler."""
import argparse
import datetime as dt
import hashlib
import json
import re
from pathlib import Path
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
LAB = BASE.parents[1]
REPO = LAB / 'cores/Saturn_MiSTer'
BASE_PIN = 'c072434a61c88c1d9f5dfae09d502cc1b3e7c326'
GUARD_SHA = '5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
PYTHON = Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
GIT = PYTHON.parent.parent / 'native/git/cmd/git.exe'
QUARTUS = Path('C:/altera_lite/25.1std/quartus')
GIB = 1024 ** 3
LIMITS = dict(wall_seconds=None, cleanup_reserve_seconds=20, job_private_bytes=14*GIB,
              tree_rss_bytes=13*GIB, admission_free_commit_bytes=16*GIB,
              continuous_free_commit_floor_bytes=2*GIB)
COMMAND = [str(QUARTUS / 'bin64/quartus_sh.exe'), '--flow', 'compile', 'STV_DS', '-c', 'STV_DS']
SCRIPTS = ('prepare.py', 'run_flow.py', 'launch_task.py', 'quartus_job_guard.py',
           'scheduler-action-inline.ps1', 'register-start-inline.ps1', 'PLAN.md', 'template-reuse-provenance.json')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output([str(GIT), '-C', str(REPO), *args])


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def checkout_variation(raw, canonical):
    if raw == canonical:
        return 'none'
    assert b'\0' not in raw and b'\0' not in canonical, 'Binary checkout difference'
    raw.decode('utf-8')
    canonical.decode('utf-8')
    assert b'\r\n' in raw and raw.replace(b'\r\n', b'\n') == canonical, 'Non-line-ending checkout difference'
    return 'CRLF-to-LF-only'


FEATURE_PATHS = {'Saturn.sv', 'sys/emu_ports.vh', 'sys/sys_top.v', 'sys/ascal.vhd'}
UPSTREAM_BASELINE = LAB / 'builds/shienryu-upstream-q251-baseline-r1'
UPSTREAM_MANIFEST_SHA = '88d8a293fb9b89ce89fe62b4efb639d5e6a3132568a1fab5566705c9ca34455f'
REQUIRED_REFERENCES = {
    'research/shienryu-timing-20261024/PRESERVATION-REVALIDATED.json',
    'research/shienryu-preservation-20261024/inventory.json',
    'research/shienryu-timing-20261024/source-port-review.json',
    'research/shienryu-timing-20261024/CONSTRAINT-REVIEW.json',
    'research/shienryu-timing-20261024/ROOT-ALL-CORNER-TIMING-REVIEW.json',
    'builds/shienryu-upstream-q251-baseline-r1/ROOT-SAVED-FIT-REVIEW.json',
    'builds/shienryu-upstream-q251-baseline-r1/qsf-version-metadata-review.json',
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freeze', action='store_true')
    parser.add_argument('--candidate-commit')
    parser.add_argument('--source-review')
    parser.add_argument('--source-review-sha256')
    args = parser.parse_args()
    assert Path(sys.executable).resolve() == PYTHON.resolve(), 'Use pinned Python'
    assert sha(LAB / 'scripts/quartus_job_guard.py') == sha(BASE / 'quartus_job_guard.py') == GUARD_SHA
    tools = [PYTHON, GIT] + [QUARTUS / 'bin64' / (name + '.exe')
        for name in ('quartus_sh', 'quartus_map', 'quartus_fit', 'quartus_sta', 'quartus_asm')]
    tool_bindings = {str(path): sha(path) for path in tools}
    plan = dict(state='template-only-no-candidate-source-read-or-pin-no-archive-no-task-no-compile',
        base_commit=BASE_PIN, candidate_commit_not_pinned=True, source_repository=str(REPO),
        project='STV_DS', revision='STV_DS', command=COMMAND, limits=LIMITS,
        guard_sha256=GUARD_SHA, tool_bindings=tool_bindings, excluded_top_paths=['releases'],
        required_reference_receipts=sorted(REQUIRED_REFERENCES),
        freeze_requires='Exact committed candidate, clean reviewed branch, root source-review path/SHA256, exact approved feature-only changed paths and bound prior/current evidence',
        scope='Minimal requested180-degree flip port only; unchanged seed/settings/clocks/SDC; no DSE/timing campaign; inherited STA is not all-corner or hardware acceptance')
    if not args.freeze:
        print(json.dumps(plan, indent=2))
        return 0
    candidate_pin = args.candidate_commit
    assert re.fullmatch('[0-9a-f]{40}', candidate_pin or '') and candidate_pin != BASE_PIN, 'Exact distinct candidate commit required'
    assert re.fullmatch('[0-9a-f]{64}', args.source_review_sha256 or ''), 'Root source-review SHA256 required'
    review_path = Path(args.source_review or '').resolve()
    assert review_path.is_file() and sha(review_path) == args.source_review_sha256, 'Root source review missing or changed'
    review = json.loads(review_path.read_text(encoding='utf-8-sig'))
    assert review['reviewer'] == 'root' and review['decision'] == 'ACCEPTED_SHIENRYU_FLIP_SOURCE_FOR_COMPILE'
    assert review['base_commit'] == BASE_PIN and review['candidate_commit'] == candidate_pin
    reference_evidence = review['reference_evidence_sha256']
    assert REQUIRED_REFERENCES <= set(reference_evidence), 'Root source review must bind old preservation and current baseline/constraint evidence'
    for name, digest in reference_evidence.items():
        assert not Path(name).is_absolute() and (LAB / name).resolve().is_relative_to(LAB.resolve())
        assert re.fullmatch('[0-9a-f]{64}', digest) and sha(LAB / name) == digest, 'Bound evidence changed: ' + name
    assert sha(UPSTREAM_BASELINE / 'input-manifest.json') == UPSTREAM_MANIFEST_SHA
    upstream_manifest = json.loads((UPSTREAM_BASELINE / 'input-manifest.json').read_text())
    upstream_baseline_files = upstream_manifest['baseline_files']
    assert git('rev-parse', 'HEAD').decode().strip() == candidate_pin
    assert git('branch', '--show-current').decode().strip() == 'lab/shienryu-flip-timing'
    assert not git('status', '--porcelain'), 'Reviewed committed candidate checkout must be clean'
    subprocess.run([str(GIT), '-C', str(REPO), 'merge-base', '--is-ancestor', BASE_PIN, candidate_pin], check=True)
    changed_paths = sorted(name.decode() for name in git('diff', '--name-only', '-z', BASE_PIN, candidate_pin).split(b'\0') if name)
    assert changed_paths and set(changed_paths) <= FEATURE_PATHS, 'Only reviewed minimal feature-path edits allowed; no constraints/settings/PLL changes'
    assert changed_paths == sorted(review['changed_paths']), 'Candidate differs from root-reviewed paths'
    top_paths = [name.decode('utf-8') for name in git('ls-tree', '--name-only', '-z', candidate_pin).split(b'\0')
                 if name and name != b'releases']
    assert 'STV_DS.qpf' in top_paths and 'STV_DS.qsf' in top_paths and 'releases' not in top_paths
    entries = {}
    for entry in filter(None, git('ls-tree', '-rz', candidate_pin).split(b'\0')):
        metadata, raw_name = entry.split(b'\t', 1)
        mode, kind, blob = metadata.split()
        name = raw_name.decode('utf-8')
        if name.startswith('releases/'):
            continue
        assert mode == b'100644' and kind == b'blob', 'Unexpected source entry: ' + name
        entries[name] = blob.decode('ascii')
    for name in ('tree', 'upstream-inputs.zip', 'input-manifest.json', 'frozen-pins.json'):
        assert not (BASE / name).exists(), 'Preserve existing preparation: ' + name
    archive = BASE / 'upstream-inputs.zip'
    subprocess.run([str(GIT), '-C', str(REPO), '-c', 'core.autocrlf=false', '-c', 'core.eol=lf',
        'archive', '--format=zip', '--output=' + str(archive), candidate_pin, '--', *top_paths], check=True)
    tree = BASE / 'tree'
    tree.mkdir()
    baseline = {}
    worktree_files = {}
    with zipfile.ZipFile(archive) as source:
        assert {entry.filename for entry in source.infolist() if not entry.is_dir()} == set(entries)
        for entry in source.infolist():
            destination = tree / entry.filename
            assert destination.resolve().is_relative_to(tree.resolve())
            if entry.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            content = source.read(entry)
            blob = hashlib.sha1(b'blob ' + str(len(content)).encode('ascii') + b'\0' + content).hexdigest()
            assert blob == entries[entry.filename], 'Canonical Git archive mismatch: ' + entry.filename
            checkout = REPO / entry.filename
            assert checkout.is_file() and not checkout.is_symlink(), entry.filename
            raw = checkout.read_bytes()
            variation = checkout_variation(raw, content)
            baseline[entry.filename] = dict(bytes=len(content), sha256=hashlib.sha256(content).hexdigest(), git_blob_sha1=blob)
            worktree_files[entry.filename] = dict(raw_bytes=len(raw), raw_sha256=hashlib.sha256(raw).hexdigest(),
                git_canonical_bytes=len(content), git_canonical_sha256=baseline[entry.filename]['sha256'],
                line_ending_variation=variation)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(content)
    q17, q25 = tree / 'sys/pll_q17.qip', tree / 'sys/pll_q25.qip'
    assert not q25.exists()
    with q25.open('xb') as stream:
        stream.write(q17.read_bytes())
    files = {path.relative_to(tree).as_posix(): dict(bytes=path.stat().st_size, sha256=sha(path))
             for path in sorted(tree.rglob('*')) if path.is_file()}
    assert set(files) == set(baseline) | {'sys/pll_q25.qip'}
    assert all(files[name]['sha256'] == row['sha256'] for name, row in baseline.items())
    assert set(baseline) == set(upstream_baseline_files), 'Minimal candidate may not add/delete archived source paths'
    assert all(baseline[name]['sha256'] == row['sha256'] for name, row in upstream_baseline_files.items() if name not in changed_paths), 'Unapproved base source/settings/clock/constraint change'
    assert not git('status', '--porcelain') and git('rev-parse', 'HEAD').decode().strip() == candidate_pin
    manifest = dict(state='frozen-not-launched', prepared_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        source_commit=candidate_pin, base_commit=BASE_PIN, source_repository=str(REPO), source_archive_sha256=sha(archive),
        source_review_path=str(review_path), source_review_sha256=sha(review_path),
        reference_evidence_sha256=reference_evidence, approved_changed_paths=changed_paths, upstream_baseline_files=upstream_baseline_files,
        archive_top_paths=top_paths, excluded_top_paths=['releases'], archive_command=plan['command'],
        baseline_files=baseline, worktree_files=worktree_files, source_files=files,
        only_added_compile_input=dict(path='sys/pll_q25.qip', byte_identical_to='sys/pll_q17.qip', sha256=sha(q25)),
        tool_bindings=tool_bindings, guard_sha256=GUARD_SHA, limits=LIMITS,
        project='STV_DS', revision='STV_DS', command=COMMAND,
        scheduler=dict(task_name='CoreLab-Shienryu-Flip-Candidate-FullFlow-Q251-R1',
            user='DESKTOP-8SVI9NM\\djjohnson13p', logon_type='Interactive', run_level='Limited',
            execution_time_limit='PT0S', triggers=[], retries=0, hidden=True),
        generated_files=['build_id.v', 'jtag.cdf', 'STV_DS_assignment_defaults.qdf'],
        generated_build_id_policy='Absent before launch; unchanged upstream preflow generates date macro and CDF; validate and hash after flow',
        checkout_validation_policy='Exact Git blob bytes or UTF-8/no-NUL CRLF-to-LF checkout equivalence only. Snapshot always uses exact Git archive bytes, including CRLF stored in Git; no newline normalization of original source.',
        source_and_timing_policy='Candidate archive is exact reviewed commit; every base file outside approved feature paths remains unchanged, including all QPF/QSF/SDC/PLL bytes; seed1/ALL processors/fitter settings unchanged; no DSE or tuning.',
        expected_metadata_change='Prior baseline Quartus changed only STV_DS.qsf version17Standard-to25Lite plus exact LF-to-CRLF conversion. Candidate raw hashes/flags/exit must remain honest; any observed delta requires a separate precise root audit after compilation.',
        timing_acceptance=False, all_corner_sta_still_required=True)
    manifest['archive_command'] = [str(GIT), '-C', str(REPO), '-c', 'core.autocrlf=false', '-c', 'core.eol=lf',
        'archive', '--format=zip', '--output=' + str(archive), candidate_pin, '--', *top_paths]
    save(BASE / 'input-manifest.json', manifest)
    pins = {name: sha(BASE / name) for name in (*SCRIPTS, 'input-manifest.json', 'upstream-inputs.zip')}
    save(BASE / 'frozen-pins.json', pins)
    print(json.dumps(dict(state='frozen-not-launched', files=len(files), baseline_files=len(baseline),
        frozen_pins_sha256=sha(BASE / 'frozen-pins.json'), task_registered=False, native_job_started=False), indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
