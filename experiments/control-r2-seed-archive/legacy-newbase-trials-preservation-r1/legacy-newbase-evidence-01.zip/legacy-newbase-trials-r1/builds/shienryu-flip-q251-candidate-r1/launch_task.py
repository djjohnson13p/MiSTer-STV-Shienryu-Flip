"""Local validation by default. --start registers and demand-starts exactly one OS-owned task."""
import argparse
import base64
import json
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
PYTHON = 'C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start', action='store_true')
    args = parser.parse_args()
    if not (BASE / 'frozen-pins.json').exists():
        assert not args.start, 'No root-reviewed candidate commit frozen'
        print(json.dumps(dict(state='template-not-frozen-no-task-no-native-job')))
        return 0
    # Importing the adapter performs no native job, task registration or output write.
    sys.path.insert(0, str(BASE))
    import run_flow
    manifest, pins = run_flow.validate()
    if not args.start:
        print(json.dumps(dict(state='local-validation-only-no-task-or-native-job', scheduler=manifest['scheduler'], pins=pins), indent=2))
        return 0
    for name in ('task-registration-attempt.json', 'registered-task.xml', 'registration-receipt.json',
                 'start-receipt.json', 'scheduler-action-start.json', 'prelaunch.json', 'live.json', 'result.json'):
        assert not (BASE / name).exists(), 'Preserve previous attempt: ' + name
    run_flow.validate_pristine(manifest)
    run_flow.no_overlap()
    resources = run_flow.read_resources()
    if not resources['admission_pass']:
        print(json.dumps(dict(state='deferred-before-registration-no-task-no-native-job', resources=resources), indent=2))
        return 2
    with (BASE / 'task-registration-attempt.json').open('x', encoding='utf-8') as stream:
        json.dump(dict(task_name=manifest['scheduler']['task_name'], pins=pins, no_quartus_overlap_observed=True), stream, indent=2)
    source = (BASE / 'register-start-inline.ps1').read_text()
    encoded = base64.b64encode(source.encode('utf-16-le')).decode('ascii')
    reply = subprocess.run([run_flow.POWERSHELL, '-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden',
        '-EncodedCommand', encoded], capture_output=True, text=True)
    (BASE / 'registration-stdout.txt').write_text(reply.stdout, encoding='utf-8')
    (BASE / 'registration-stderr.txt').write_text(reply.stderr, encoding='utf-8')
    print(json.dumps(dict(registration_exit=reply.returncode, task_name=manifest['scheduler']['task_name'],
        start_receipt_exists=(BASE / 'start-receipt.json').exists(), do_not_repeat=True)))
    return reply.returncode


if __name__ == '__main__':
    raise SystemExit(main())
