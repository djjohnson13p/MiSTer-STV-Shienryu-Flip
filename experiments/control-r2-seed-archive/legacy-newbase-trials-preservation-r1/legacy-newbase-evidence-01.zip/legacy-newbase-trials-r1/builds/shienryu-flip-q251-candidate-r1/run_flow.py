"""One reviewed flip-candidate STV_DS full flow through the canonical guard. Default dry run never starts a child or task."""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
TREE = BASE / 'tree'
GUARD_SHA = '5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
POWERSHELL = 'C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def no_overlap():
    reply = subprocess.check_output([POWERSHELL, '-NoProfile', '-NonInteractive', '-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"], text=True).strip()
    assert not reply or not json.loads(reply), 'Quartus overlap observed; no native job launched'


def validate():
    pins = json.loads((BASE / 'frozen-pins.json').read_text())
    for name, expected in pins.items():
        assert sha(BASE / name) == expected, 'Frozen adapter/input changed: ' + name
    manifest = json.loads((BASE / 'input-manifest.json').read_text())
    assert manifest['base_commit'] == 'c072434a61c88c1d9f5dfae09d502cc1b3e7c326'
    assert re.fullmatch('[0-9a-f]{40}', manifest['source_commit']) and manifest['source_commit'] != manifest['base_commit']
    assert sha(manifest['source_review_path']) == manifest['source_review_sha256']
    for name, digest in manifest['reference_evidence_sha256'].items():
        assert sha(BASE.parents[1] / name) == digest, 'Bound prior/current evidence changed: ' + name
    assert manifest['project'] == manifest['revision'] == 'STV_DS'
    assert sha(BASE / 'quartus_job_guard.py') == manifest['guard_sha256'] == GUARD_SHA
    for path, expected in manifest['tool_bindings'].items():
        assert sha(path) == expected, 'Pinned tool changed: ' + path
    for name, row in manifest['source_files'].items():
        assert sha(TREE / name) == row['sha256'], 'Snapshot source changed: ' + name
    assert (TREE / 'sys/pll_q17.qip').read_bytes() == (TREE / 'sys/pll_q25.qip').read_bytes()
    qsf = (TREE / 'STV_DS.qsf').read_text(encoding='utf-8-sig')
    assert re.search(r'^set_global_assignment -name SEED 1\s*$', qsf, re.M)
    assert re.search(r'^set_global_assignment -name NUM_PARALLEL_PROCESSORS ALL\s*$', qsf, re.M)
    assert re.search(r'^set_global_assignment -name TIMEQUEST_MULTICORNER_ANALYSIS OFF\s*$', qsf, re.M)
    qpf = (TREE / 'STV_DS.qpf').read_text(encoding='utf-8-sig')
    assert re.search(r'^PROJECT_REVISION\s*=\s*"STV_DS"\s*$', qpf, re.M)
    assert 'set_global_assignment -name VERILOG_MACRO "STV_BUILD=1"' in qsf
    assert 'source sys/sys_dual_sdram.tcl' in qsf
    assert 'set_global_assignment -name VERILOG_MACRO "MISTER_DUAL_SDRAM=1"' in (TREE / 'sys/sys_dual_sdram.tcl').read_text()
    assert set(manifest['source_files']) == set(manifest['baseline_files']) | {'sys/pll_q25.qip'}
    assert all(manifest['source_files'][name]['sha256'] == row['sha256'] for name, row in manifest['upstream_baseline_files'].items() if name not in manifest['approved_changed_paths'])
    return manifest, pins


def validate_pristine(manifest):
    assert set(path.relative_to(TREE).as_posix() for path in TREE.rglob('*') if path.is_file()) == set(manifest['source_files']), 'Full flow requires a pristine snapshot with no saved databases or generated outputs'


def read_resources():
    # Read-only native memory sample; never creates a Job, task or compiler process.
    spec = importlib.util.spec_from_file_location('shienryu_resource_probe_guard', BASE / 'quartus_job_guard.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    api = module.Windows()
    value = module.Performance(cb=module.C.sizeof(module.Performance))
    api.checked(api.p.GetPerformanceInfo(module.C.byref(value), value.cb), 'GetPerformanceInfo')
    free = (value.limit - value.commit) * value.page
    threshold = 12 * 1024**3
    return dict(observed_utc=module.stamp(), free_commit_bytes=free, admission_free_commit_bytes=threshold,
        admission_pass=free >= threshold, committed_bytes=value.commit*value.page,
        commit_limit_bytes=value.limit*value.page, physical_available_bytes=value.available*value.page,
        physical_total_bytes=value.physical*value.page, no_job_or_task_created=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if not (BASE / 'frozen-pins.json').exists():
        assert not args.run, 'Exact root-reviewed candidate commit has not been frozen'
        print(json.dumps(dict(state='template-not-frozen-no-native-job', command=['C:/altera_lite/25.1std/quartus/bin64/quartus_sh.exe', '--flow', 'compile', 'STV_DS', '-c', 'STV_DS'])))
        return 0
    manifest, pins = validate()
    guard_path = BASE / 'quartus_job_guard.py'
    spec = importlib.util.spec_from_file_location('shienryu_flip_candidate_guard', guard_path)
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)

    def bound_inputs():
        # All archived project/source bytes and the sole compatibility alias are protected.
        # build_id.v is intentionally absent here: the unchanged preflow hook creates it.
        return {name: sha(TREE / name) for name in manifest['source_files']}

    # Replace every historical project/application/output/policy binding explicitly.
    guard.LAB = BASE.parents[1]
    guard.BASE = BASE
    guard.TREE = TREE
    guard.QUARTUS = Path('C:/altera_lite/25.1std/quartus')
    guard.EXE = guard.QUARTUS / 'bin64/quartus_sh.exe'
    guard.COMMAND = [str(guard.EXE), '--flow', 'compile', 'STV_DS', '-c', 'STV_DS']
    guard.BASELINE = manifest['source_commit']
    guard.RUN_KIND = 'shienryu-reviewed-minimal-flip-candidate-fullflow-no-wall-cutoff'
    guard.LIMITS = dict(wall_seconds=None, cleanup_reserve_seconds=20, job_private_bytes=10*1024**3,
        tree_rss_bytes=9*1024**3, admission_free_commit_bytes=12*1024**3,
        continuous_free_commit_floor_bytes=2*1024**3)
    guard.inputs = bound_inputs
    assert guard.LIMITS == manifest['limits'] and guard.COMMAND == manifest['command']
    plan = dict(state='prepared-dry-run-no-native-job', command=guard.COMMAND, cwd=str(TREE),
        limits=guard.LIMITS, source_commit=guard.BASELINE,
        bound_source_files=len(manifest['source_files']), guard_sha256=sha(guard_path),
        frozen_pins_sha256=sha(BASE / 'frozen-pins.json'), scheduler=manifest['scheduler'],
        timing_acceptance=False, all_corner_sta_still_required=True)
    if not args.run:
        print(json.dumps(plan, indent=2))
        return 0
    validate_pristine(manifest)
    for name in ('prelaunch.json', 'fullflow.log', 'live.json', 'result.json'):
        assert not (BASE / name).exists(), 'Previous run evidence exists: ' + name
    scheduler_start = json.loads((BASE / 'scheduler-action-start.json').read_text(encoding='utf-8-sig'))
    assert scheduler_start['pid'] == os.getppid(), 'Use reviewed OS-owned Task Scheduler launch'
    assert scheduler_start['parent_name'].lower() in ('svchost.exe', 'taskeng.exe'), 'Action parent is not Task Scheduler'
    no_overlap()
    local_started = dt.date.today()
    plan['scheduler_action_start'] = scheduler_start
    guard.save(BASE / 'prelaunch.json', plan)
    code = guard.run(bound_inputs())
    result = json.loads((BASE / 'result.json').read_text())
    changes = result.get('changed_bound_inputs', {})
    generated = {name: sha(TREE / name) for name in manifest['generated_files'] if (TREE / name).is_file()}
    build_id = (TREE / 'build_id.v').read_bytes() if (TREE / 'build_id.v').is_file() else b''
    match = re.fullmatch(rb'`define BUILD_DATE "([0-9]{6})"', build_id)
    valid_date = False
    if match:
        date = dt.datetime.strptime(match[1].decode(), '%y%m%d').date()
        valid_date = local_started <= date <= dt.date.today()
    readback = dict(bound_source_changes=changes, generated_file_hashes=generated,
        build_id_text=build_id.decode('ascii', errors='replace'), generated_build_id_matches_upstream_contract=valid_date,
        source_integrity_ok=not changes and 'input_hashes_after' in result,
        flow_exit_is_not_timing_acceptance=True, timing_acceptance=False, all_corner_sta_still_required=True)
    readback['adapter_success'] = code == 0 and readback['source_integrity_ok'] and valid_date
    guard.save(BASE / 'integrity-readback.json', readback)
    return 0 if readback['adapter_success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
