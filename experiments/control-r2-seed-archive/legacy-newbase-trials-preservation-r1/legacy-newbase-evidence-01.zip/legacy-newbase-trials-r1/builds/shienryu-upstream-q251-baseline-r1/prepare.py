"""Read-only plan by default. --freeze snapshots unchanged pinned STV_DS source; never launches a task or compiler."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
LAB = BASE.parents[1]
REPO = LAB / 'cores/Saturn_MiSTer'
PIN = 'c072434a61c88c1d9f5dfae09d502cc1b3e7c326'
GUARD_SHA = '5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
PYTHON = Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
GIT = PYTHON.parent.parent / 'native/git/cmd/git.exe'
QUARTUS = Path('C:/altera_lite/25.1std/quartus')
GIB = 1024 ** 3
LIMITS = dict(wall_seconds=None, cleanup_reserve_seconds=20, job_private_bytes=14*GIB,
              tree_rss_bytes=13*GIB, admission_free_commit_bytes=16*GIB,
              continuous_free_commit_floor_bytes=2*GIB)
COMMAND = [str(QUARTUS / 'bin64/quartus_sh.exe'), '--flow', 'compile', 'STV_DS', '-c', 'STV_DS']
SCRIPTS = ('prepare.py', 'run_flow.py', 'launch_task.py', 'quartus_job_guard.py',
           'scheduler-action-inline.ps1', 'register-start-inline.ps1')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output([str(GIT), '-C', str(REPO), *args])


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def checkout_variation(raw, canonical):
    if raw == canonical:
        return 'none'
    assert b'\0' not in raw and b'\0' not in canonical, 'Binary checkout difference'
    raw.decode('utf-8')
    canonical.decode('utf-8')
    assert b'\r\n' in raw and raw.replace(b'\r\n', b'\n') == canonical, 'Non-line-ending checkout difference'
    return 'CRLF-to-LF-only'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freeze', action='store_true')
    args = parser.parse_args()
    assert Path(sys.executable).resolve() == PYTHON.resolve(), 'Use pinned Python'
    assert git('rev-parse', 'HEAD').decode().strip() == PIN
    assert git('branch', '--show-current').decode().strip() == 'lab/shienryu-flip-timing'
    assert not git('status', '--porcelain'), 'Baseline checkout must be clean'
    assert sha(LAB / 'scripts/quartus_job_guard.py') == sha(BASE / 'quartus_job_guard.py') == GUARD_SHA
    tools = [PYTHON, GIT] + [QUARTUS / 'bin64' / (name + '.exe')
        for name in ('quartus_sh', 'quartus_map', 'quartus_fit', 'quartus_sta', 'quartus_asm')]
    tool_bindings = {str(path): sha(path) for path in tools}
    top_paths = [name.decode('utf-8') for name in git('ls-tree', '--name-only', '-z', PIN).split(b'\0')
                 if name and name != b'releases']
    assert 'STV_DS.qpf' in top_paths and 'STV_DS.qsf' in top_paths and 'releases' not in top_paths
    entries = {}
    for entry in filter(None, git('ls-tree', '-rz', PIN).split(b'\0')):
        metadata, raw_name = entry.split(b'\t', 1)
        mode, kind, blob = metadata.split()
        name = raw_name.decode('utf-8')
        if name.startswith('releases/'):
            continue
        assert mode == b'100644' and kind == b'blob', 'Unexpected source entry: ' + name
        entries[name] = blob.decode('ascii')
    plan = dict(state='template-only-no-frozen-source-no-task-no-compile', source_commit=PIN,
        source_repository=str(REPO), project='STV_DS', revision='STV_DS', command=COMMAND,
        limits=LIMITS, guard_sha256=GUARD_SHA, tool_bindings=tool_bindings,
        archive_top_paths=top_paths, tracked_source_files=len(entries), excluded_top_paths=['releases'],
        scope='Unchanged full A&S, fit, inherited STA and assembly; no DSE/tuning/flip changes; reports require independent review')
    if not args.freeze:
        print(json.dumps(plan, indent=2))
        return 0
    for name in ('tree', 'upstream-inputs.zip', 'input-manifest.json', 'frozen-pins.json'):
        assert not (BASE / name).exists(), 'Preserve existing preparation: ' + name
    archive = BASE / 'upstream-inputs.zip'
    subprocess.run([str(GIT), '-C', str(REPO), '-c', 'core.autocrlf=false', '-c', 'core.eol=lf',
        'archive', '--format=zip', '--output=' + str(archive), PIN, '--', *top_paths], check=True)
    tree = BASE / 'tree'
    tree.mkdir()
    baseline = {}
    worktree_files = {}
    with zipfile.ZipFile(archive) as source:
        assert {entry.filename for entry in source.infolist() if not entry.is_dir()} == set(entries)
        for entry in source.infolist():
            destination = tree / entry.filename
            assert destination.resolve().is_relative_to(tree.resolve())
            if entry.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            content = source.read(entry)
            blob = hashlib.sha1(b'blob ' + str(len(content)).encode('ascii') + b'\0' + content).hexdigest()
            assert blob == entries[entry.filename], 'Canonical Git archive mismatch: ' + entry.filename
            checkout = REPO / entry.filename
            assert checkout.is_file() and not checkout.is_symlink(), entry.filename
            raw = checkout.read_bytes()
            variation = checkout_variation(raw, content)
            baseline[entry.filename] = dict(bytes=len(content), sha256=hashlib.sha256(content).hexdigest(), git_blob_sha1=blob)
            worktree_files[entry.filename] = dict(raw_bytes=len(raw), raw_sha256=hashlib.sha256(raw).hexdigest(),
                git_canonical_bytes=len(content), git_canonical_sha256=baseline[entry.filename]['sha256'],
                line_ending_variation=variation)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(content)
    q17, q25 = tree / 'sys/pll_q17.qip', tree / 'sys/pll_q25.qip'
    assert not q25.exists()
    with q25.open('xb') as stream:
        stream.write(q17.read_bytes())
    files = {path.relative_to(tree).as_posix(): dict(bytes=path.stat().st_size, sha256=sha(path))
             for path in sorted(tree.rglob('*')) if path.is_file()}
    assert set(files) == set(baseline) | {'sys/pll_q25.qip'}
    assert all(files[name]['sha256'] == row['sha256'] for name, row in baseline.items())
    assert not git('status', '--porcelain') and git('rev-parse', 'HEAD').decode().strip() == PIN
    manifest = dict(state='frozen-not-launched', prepared_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        source_commit=PIN, source_repository=str(REPO), source_archive_sha256=sha(archive),
        archive_top_paths=top_paths, excluded_top_paths=['releases'], archive_command=plan['command'],
        baseline_files=baseline, worktree_files=worktree_files, source_files=files,
        only_added_compile_input=dict(path='sys/pll_q25.qip', byte_identical_to='sys/pll_q17.qip', sha256=sha(q25)),
        tool_bindings=tool_bindings, guard_sha256=GUARD_SHA, limits=LIMITS,
        project='STV_DS', revision='STV_DS', command=COMMAND,
        scheduler=dict(task_name='CoreLab-Shienryu-Upstream-Baseline-FullFlow-Q251-R1',
            user='DESKTOP-8SVI9NM\\djjohnson13p', logon_type='Interactive', run_level='Limited',
            execution_time_limit='PT0S', triggers=[], retries=0, hidden=True),
        generated_files=['build_id.v', 'jtag.cdf', 'STV_DS_assignment_defaults.qdf'],
        generated_build_id_policy='Absent before launch; unchanged upstream preflow generates date macro and CDF; validate and hash after flow',
        checkout_validation_policy='Exact Git blob bytes or UTF-8/no-NUL CRLF-to-LF checkout equivalence only. Snapshot always uses exact Git archive bytes, including CRLF stored in Git; no newline normalization of original source.',
        source_and_timing_policy='All source including QPF/QSF/SDC/PLL retains pinned Git bytes; seed1/ALL processors/current fitter settings unchanged; no DSE, tuning or flip changes.',
        expected_metadata_change='Quartus may update only STV_DS.qsf LAST_QUARTUS_VERSION 17.0.2 Standard Edition to 25.1std.0 Lite Edition. Raw hashes/changed-input flags must remain honest and require independent root audit.',
        timing_acceptance=False, all_corner_sta_still_required=True)
    manifest['archive_command'] = [str(GIT), '-C', str(REPO), '-c', 'core.autocrlf=false', '-c', 'core.eol=lf',
        'archive', '--format=zip', '--output=' + str(archive), PIN, '--', *top_paths]
    save(BASE / 'input-manifest.json', manifest)
    pins = {name: sha(BASE / name) for name in (*SCRIPTS, 'input-manifest.json', 'upstream-inputs.zip')}
    save(BASE / 'frozen-pins.json', pins)
    print(json.dumps(dict(state='frozen-not-launched', files=len(files), baseline_files=len(baseline),
        frozen_pins_sha256=sha(BASE / 'frozen-pins.json'), task_registered=False, native_job_started=False), indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
