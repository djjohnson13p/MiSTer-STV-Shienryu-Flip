# Unchanged current dual-RAM ST-V baseline, Quartus 25.1

This folder prepares one isolated unchanged upstream `STV_DS` compile from `c072434a61c88c1d9f5dfae09d502cc1b3e7c326`. No flip edit, seed change, timing-option change, DSE exploration or clock/constraint change is included. The archive includes every source top-level path except `releases`; Git metadata is not archived. Source bytes are exact Git blobs. Git-stored CRLF is preserved; checkout CRLF conversion is never substituted for canonical source. The sole added compile input is `sys/pll_q25.qip`, byte-identical to the supplied `sys/pll_q17.qip`.

The canonical guard is unchanged, SHA256 `5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9`. The project adapter explicitly overrides every inherited project/application/output/limit binding. Limits are 14 GiB Job private memory, 13 GiB whole-tree RSS, 16 GiB admission free commit and a 2 GiB continuous free-commit floor. There is no wall-clock cutoff. These provisional STV limits require review against actual telemetry; historical Quartus peak memory is a different metric from Job private/RSS. A resource stop is inconclusive for timing.

Default `prepare.py`, `run_flow.py` and `launch_task.py` invocations are read-only plans/validation. `prepare.py --freeze` creates the one source archive/copy/manifests, never a task or compiler. All compiler execution is through the owned Windows Job. A unique hidden, limited, InteractiveToken, on-demand Task Scheduler action supplies durable ownership; XML readback requires PT0S execution limit, no triggers/retries and IgnoreNew. Existing run receipts and the exact existing task are refused. Fresh commit admission before registration and independent guard admission before compiler creation remain mandatory.

Root must review the frozen scripts, manifest, diffs and resource sample before invoking the launch command below. This preparation does not register a task or start Quartus. A fresh native memory sample must pass the unchanged 16 GiB threshold at launch. Do not terminate unrelated applications or change pagefile settings to make admission pass.

Proposed commands, with the workspace root as working directory:

```powershell
& 'C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B 'core-lab/builds/shienryu-upstream-q251-baseline-r1/run_flow.py'
& 'C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B 'core-lab/builds/shienryu-upstream-q251-baseline-r1/launch_task.py'
# Only after root review and a passing fresh resource sample:
& 'C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B 'core-lab/builds/shienryu-upstream-q251-baseline-r1/launch_task.py' --start
```

The scheduler runs the fixed native command `C:/altera_lite/25.1std/quartus/bin64/quartus_sh.exe --flow compile STV_DS -c STV_DS` with `tree` as working directory. It preserves SEED 1, ALL processors, TIMEQUEST_MULTICORNER_ANALYSIS OFF and every upstream implementation/SDC/PLL assignment. No 2700-second inherited timeout exists. Elapsed time triggers progress review. Terminal membership, signaled handles and independent handle cleanup must be proved before exact-task removal or any later compile.

All source inputs remain byte-protected. Quartus may update `STV_DS.qsf` LAST_QUARTUS_VERSION from `17.0.2 Standard Edition` to `25.1std.0 Lite Edition`. The raw guard change receipt, `source_integrity_ok` and adapter exit remain conservative; no metadata exception is silently accepted. Root must independently audit any exact metadata-only difference while preserving the original raw flags. Unchanged `sys/build_id.tcl` generates `build_id.v` and `jtag.cdf`; the adapter validates the date macro and hashes generated files.

Flow exit 0 and an RBF do not establish timing acceptance. After a successful terminal fit, preserve the full fitted tree and perform all-available-corner STA on an isolated hashed copy, with actual STV clock inventory, setup/hold/recovery/removal, min pulse width, clock transfers, applied/ignored SDC and unconstrained-path coverage. Current upstream false-path exceptions require an interpretation audit. No empty/NA row is a pass. Historical experimental source, fork/tag and installed RBF/MRA stay untouched.
