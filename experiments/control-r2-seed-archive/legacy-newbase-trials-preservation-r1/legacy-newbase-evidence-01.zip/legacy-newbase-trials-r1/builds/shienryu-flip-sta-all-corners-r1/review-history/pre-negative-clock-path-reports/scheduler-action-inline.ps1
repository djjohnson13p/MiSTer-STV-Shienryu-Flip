$ErrorActionPreference = 'Stop'
$base = 'C:\Users\djjoh\Downloads\MiSTer-Rebuild-Kit\MiSTer-Rebuild-Kit\core-lab\builds\shienryu-flip-sta-all-corners-r1'
$own = Get-CimInstance Win32_Process -Filter "ProcessId=$PID"
$parent = Get-CimInstance Win32_Process -Filter "ProcessId=$($own.ParentProcessId)"
[pscustomobject]@{utc=(Get-Date).ToUniversalTime().ToString('o'); pid=$PID; parent_pid=$own.ParentProcessId; parent_name=$parent.Name} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $base 'scheduler-action-start.json') -Encoding UTF8
& 'C:\Users\djjoh\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -B -X utf8 -u (Join-Path $base 'run_sta.py') --run 1> (Join-Path $base 'scheduler-stdout.log') 2> (Join-Path $base 'scheduler-stderr.log')
$code = $LASTEXITCODE
[pscustomobject]@{exit_code=$code; utc=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $base 'scheduler-action-exit.json') -Encoding UTF8
exit $code
