# Saved fitted database only. No map/fit/assembly, assignment export or SDC edit.
set out [file normalize [file join [file dirname [info script]] reports]]
if {![file isdirectory $out]} {error "Prepared report directory is missing"}
set inventory ""
set coverage ""
set global_summary ""
set opened 0
set netlist 0
set failed [catch {
    project_open STV_DS -revision STV_DS
    set opened 1
    create_timing_netlist
    set netlist 1
    read_sdc
    update_timing_netlist
    set conditions [get_available_operating_conditions -all]
    set condition_count [get_collection_size $conditions]
    if {$condition_count < 2} {error "All available corner coverage is not established"}
    set inventory [open [file join $out corner-inventory.tsv] {WRONLY CREAT EXCL}]
    puts $inventory "index\toperating_condition\tmodel\tgrade\tspeed\ttemperature_C\tvoltage_mV\tclock_count"
    set coverage [open [file join $out clock-check-coverage.tsv] {WRONLY CREAT EXCL}]
    puts $coverage "corner\tclock\tclock_object\tperiod_ns\tpositive_registers\tnegative_registers\tcheck\treturned_path_count\tworst_slack_ns\tclassification"
    set global_summary [open [file join $out global-check-coverage.tsv] {WRONLY CREAT EXCL}]
    puts $global_summary "corner\tcheck\treturned_path_count\tworst_slack_ns\tclassification"
    set index 0
    set expected_clocks -1
    foreach_in_collection condition $conditions {
        incr index
        set_operating_conditions $condition
        update_timing_netlist
        set current [get_operating_conditions]
        set label [get_operating_conditions_info -display_name $current]
        set model [get_operating_conditions_info -model $current]
        set grade [get_operating_conditions_info -grade $current]
        set speed [get_operating_conditions_info -speed $current]
        set temperature [get_operating_conditions_info -temperature $current]
        set voltage [get_operating_conditions_info -voltage $current]
        set clocks [get_clocks]
        set clock_count [get_collection_size $clocks]
        if {$clock_count < 1} {error "No actual clocks at $label"}
        if {$expected_clocks < 0} {set expected_clocks $clock_count}
        if {$clock_count != $expected_clocks} {error "Clock inventory changed across operating conditions"}
        puts $inventory "$index\t$label\t$model\t$grade\t$speed\t$temperature\t$voltage\t$clock_count"
        flush $inventory
        set prefix [file join $out [format "corner-%02d" $index]]
        report_clocks -file ${prefix}-constraints.rpt
        foreach kind {setup hold recovery removal} {
            report_clock_transfers -$kind -append -file ${prefix}-constraints.rpt
        }
        report_sdc -append -file ${prefix}-constraints.rpt
        report_sdc -ignored -append -file ${prefix}-constraints.rpt
        check_timing -append -file ${prefix}-constraints.rpt
        report_ucp -append -file ${prefix}-constraints.rpt
        report_clock_fmax_summary -file ${prefix}-fmax.rpt
        foreach kind {setup hold recovery removal} {
            report_timing -$kind -npaths 50 -detail full_path -file ${prefix}-${kind}.rpt
            set global_paths [get_timing_paths -$kind -npaths 1]
            set global_count [get_collection_size $global_paths]
            set global_slack NA
            set global_class NO_PATHS_REQUIRES_REVIEW
            foreach_in_collection path $global_paths {
                set global_slack [get_path_info -slack $path]
                set global_class PATH_FOUND_REQUIRES_TIMING_REVIEW
            }
            puts $global_summary "$index\t$kind\t$global_count\t$global_slack\t$global_class"
            set clocks_with_paths 0
            foreach_in_collection clock $clocks {
                set name [get_clock_info -name $clock]
                set period [get_clock_info -period $clock]
                set positive [get_clock_info -nreg_pos $clock]
                set negative [get_clock_info -nreg_neg $clock]
                # Preserve the actual clock object. Never reinterpret names containing [] as globs.
                set paths [get_timing_paths -$kind -to_clock $clock -npaths 1]
                set count [get_collection_size $paths]
                set slack NA
                set classification NO_PATHS_REQUIRES_REVIEW
                foreach_in_collection path $paths {
                    set destination [get_path_info -to_clock $path]
                    if {$destination eq ""} {error "Clock-bound path has no destination clock: $name / $kind"}
                    set destination_name [get_clock_info -name $destination]
                    if {$destination_name ne $name} {error "Clock binding mismatch: expected $name, got $destination_name"}
                    set slack [get_path_info -slack $path]
                    set classification EXACT_CLOCK_PATH_REQUIRES_TIMING_REVIEW
                }
                if {$count > 0} {incr clocks_with_paths}
                puts $coverage "$index\t$name\t$clock\t$period\t$positive\t$negative\t$kind\t$count\t$slack\t$classification"
            }
            if {$global_count > 0 && $clocks_with_paths == 0} {error "Global paths exist but all clock-bound queries are empty: $label / $kind"}
            flush $coverage
            flush $global_summary
        }
        report_min_pulse_width -nworst 50 -detail full_path -file ${prefix}-min-pulse-width.rpt
    }
    if {$index != $condition_count} {error "Not all available operating conditions were analyzed"}
} message options]
foreach channel [list $inventory $coverage $global_summary] {
    if {$channel ne ""} {catch {close $channel}}
}
if {$netlist} {catch {delete_timing_netlist}}
if {$opened} {catch {project_close -dont_export_assignments}}
if {$failed} {
    puts stderr $message
    if {[dict exists $options -errorinfo]} {puts stderr [dict get $options -errorinfo]}
    qexit -error
}
puts "SUPERBOND_SAVED_FIT_ALL_AVAILABLE_CORNERS_REPORTS_COMPLETE_NOT_TIMING_ACCEPTANCE"
qexit -success
