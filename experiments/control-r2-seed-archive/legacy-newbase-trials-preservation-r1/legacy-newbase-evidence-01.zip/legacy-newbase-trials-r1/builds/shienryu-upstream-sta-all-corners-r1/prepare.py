"""Template only by default; --prepare requires a root-accepted terminal STV fit. Never launches STA or a task."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
LAB=BASE.parents[1]
FIT=BASE.parent/'shienryu-upstream-q251-baseline-r1'
PYTHON=Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
STA=Path('C:/altera_lite/25.1std/quartus/bin64/quartus_sta.exe')
POWERSHELL='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
PIN='c072434a61c88c1d9f5dfae09d502cc1b3e7c326'
FIT_MANIFEST_SHA='88d8a293fb9b89ce89fe62b4efb639d5e6a3132568a1fab5566705c9ca34455f'
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
TCL_SHA='e39695c97542326e543e2dd9c93aec61ea94a75b7d28c70efbd4d4cf9f261c9c'
API=BASE.parent/'superbond-q251-sta-api-help-r1/api-verification.json'
API_SHA='d6dfede92508114484377c4adb7bfd046a827ab4ce0d41347bde4effa67836d5'
CONSTRAINTS=LAB/'research/shienryu-timing-20261024/CONSTRAINT-REVIEW.json'
CONSTRAINTS_SHA='3f71dc9996f068c1c25e10ae29e6bb3705b95140fe43e435856e2ef6130f6f38'
QSF='STV_DS.qsf'
GIB=1024**3
FIT_LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=14*GIB,
    tree_rss_bytes=13*GIB,admission_free_commit_bytes=16*GIB,continuous_free_commit_floor_bytes=2*GIB)
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,
    tree_rss_bytes=9*GIB,admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)
SCRIPTS=('prepare.py','run_sta.py','launch_task.py','quartus_job_guard.py','sta_all_corners.tcl',
    'scheduler-action-inline.ps1','register-start-inline.ps1','PLAN.md','template-reuse-provenance.json')
EVIDENCE=('result.json','input-manifest.json','frozen-pins.json','integrity-readback.json',
    'scheduler-action-exit.json','terminal-task-cleanup.json','tree/output_files/STV_DS.fit.summary',
    'tree/output_files/STV_DS.fit.rpt','tree/output_files/STV_DS.flow.rpt')
INVENTORY_KEYS=('generated_names','map_database_names','fit_database_names','primary_cmp_names')

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def save(path,value):
    with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2);stream.write('\n')

def snapshot(tree):
    found={}
    for path in sorted(tree.rglob('*')):
        assert not path.is_symlink(),'Unsupported symlink: '+str(path)
        if path.is_file():found[path.relative_to(tree).as_posix()]=dict(bytes=path.stat().st_size,sha256=sha(path))
    return found

def no_overlap():
    scan=subprocess.check_output([POWERSHELL,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not scan or not json.loads(scan),'Quartus still active; do not read or copy a live fitted tree'

def safe_evidence_name(name):
    assert isinstance(name,str) and name and not Path(name).is_absolute() and '\\' not in name
    assert all(part not in ('','.','..') for part in name.split('/'))
    assert (FIT/name).resolve().is_relative_to(FIT.resolve())
    return name

def prerequisites(args):
    # This check precedes all reads of terminal evidence or the fitted tree.
    no_overlap()
    assert re.fullmatch('[0-9a-f]{64}',args.fit_result_sha256 or ''),'Root-accepted terminal result SHA256 required'
    assert re.fullmatch('[0-9a-f]{64}',args.fit_review_sha256 or ''),'Root fit review SHA256 required'
    review_path=Path(args.fit_review or '').resolve()
    assert review_path.is_file() and sha(review_path)==args.fit_review_sha256,'Root fit review missing or changed'
    review=json.loads(review_path.read_text(encoding='utf-8-sig'))
    assert review['reviewer']=='root' and review['decision']=='ACCEPTED_FOR_SAVED_FIT_STA'
    assert Path(review['fit_directory']).resolve()==FIT.resolve()
    evidence={name:sha(FIT/name) for name in EVIDENCE}
    assert all(review['evidence_sha256'].get(name)==digest for name,digest in evidence.items()),'Root review does not bind every terminal/report prerequisite'
    assert evidence['result.json']==args.fit_result_sha256 and evidence['input-manifest.json']==FIT_MANIFEST_SHA
    fitted=json.loads((FIT/'result.json').read_text())
    assert fitted['state']=='terminal' and fitted['launcher_success'] and fitted['flow_exit_code']==0
    assert fitted['all_job_processes_terminal'] and fitted['all_handles_closed'] and fitted['errors']==[]
    assert 'input_hashes_after' in fitted
    fit_plan=json.loads((FIT/'input-manifest.json').read_text())
    assert fit_plan['source_commit']==PIN and fit_plan['project']==fit_plan['revision']=='STV_DS'
    assert fit_plan['limits']==FIT_LIMITS
    for name,digest in json.loads((FIT/'frozen-pins.json').read_text()).items():assert sha(FIT/name)==digest,'Frozen full-flow input changed: '+name
    integrity=json.loads((FIT/'integrity-readback.json').read_text())
    metadata_case=fitted['changed_bound_inputs']!={}
    metadata_delta=None
    if metadata_case:
        audit_name=safe_evidence_name(review['metadata_only_qsf_audit'])
        audit_sha=sha(FIT/audit_name)
        assert review['evidence_sha256'].get(audit_name)==audit_sha,'Root review must bind exact QSF metadata audit'
        audit=json.loads((FIT/audit_name).read_text(encoding='utf-8-sig'))
        assert audit['reviewer']=='root' and audit['decision']=='EXACT_LAST_QUARTUS_VERSION_AND_LF_TO_CRLF_ONLY'
        assert audit['all_other_protected_inputs_unchanged'] is True
        before_map=fitted['input_hashes_before'];after_map=fitted['input_hashes_after']
        before=fit_plan['source_files'][QSF]['sha256'];after=sha(FIT/'tree'/QSF)
        delta={QSF:dict(before=before,after=after)}
        assert fitted['changed_bound_inputs']==integrity['bound_source_changes']==delta
        assert audit['qsf_before_sha256']==before and audit['qsf_after_sha256']==after
        assert set(before_map)==set(after_map) and before_map[QSF]==before and after_map[QSF]==after
        assert all(after_map[name]==digest for name,digest in before_map.items() if name!=QSF)
        assert integrity['adapter_success'] is False and integrity['source_integrity_ok'] is False
        with zipfile.ZipFile(FIT/'upstream-inputs.zip') as archive:old_qsf=archive.read(QSF)
        old_literal=b'set_global_assignment -name LAST_QUARTUS_VERSION "17.0.2 Standard Edition"'
        new_literal=b'set_global_assignment -name LAST_QUARTUS_VERSION "25.1std.0 Lite Edition"'
        assert hashlib.sha256(old_qsf).hexdigest()==before
        assert b'\r' not in old_qsf and old_qsf.count(b'\n')>0,'Archived QSF must be verified LF-only'
        assert old_qsf.count(old_literal)==1
        expected_qsf=old_qsf.replace(old_literal,new_literal,1).replace(b'\n',b'\r\n')
        assert (FIT/'tree'/QSF).read_bytes()==expected_qsf,'QSF differs beyond the exact version literal and LF-to-CRLF transformation'
        evidence[audit_name]=audit_sha
        metadata_delta=dict(path=QSF,before_sha256=before,after_sha256=after,audit_file=audit_name,audit_sha256=audit_sha,
            raw_adapter_success=False,raw_source_integrity_ok=False,raw_scheduler_exit_code=1,
            line_ending_conversion='Verified LF-only archive to CRLF, every newline converted exactly once',
            before_lf_count=old_qsf.count(b'\n'),after_crlf_count=expected_qsf.count(b'\r\n'),
            scope='Exact LAST_QUARTUS_VERSION replacement plus verified LF-to-CRLF conversion only; all raw full-flow receipts preserved')
    else:
        assert integrity['adapter_success'] and integrity['source_integrity_ok'] and integrity['bound_source_changes']=={}
    assert integrity['generated_build_id_matches_upstream_contract']
    expected_adapter_exit=1 if metadata_case else 0
    assert json.loads((FIT/'scheduler-action-exit.json').read_text(encoding='utf-8-sig'))['exit_code']==expected_adapter_exit
    cleanup=json.loads((FIT/'terminal-task-cleanup.json').read_text(encoding='utf-8-sig'))
    assert cleanup['task_name']==fit_plan['scheduler']['task_name'] and cleanup['exact_task_unregistered']
    assert cleanup['all_job_processes_terminal'] and cleanup['all_handles_closed'] and cleanup['errors']==[]
    assert cleanup['remaining_owned_or_quartus_processes']==[] and cleanup['last_task_result']==expected_adapter_exit
    summary=(FIT/'tree/output_files/STV_DS.fit.summary').read_text()
    assert 'Fitter Status : Successful' in summary and 'Timing Models : Final' in summary and '5CSEBA6U23I7' in summary
    assert (FIT/'tree/output_files/STV_DS.fit.rpt').stat().st_size>10000
    for name,row in fit_plan['source_files'].items():
        expected=metadata_delta['after_sha256'] if metadata_case and name==QSF else row['sha256']
        assert sha(FIT/'tree'/name)==expected,'Completed source changed: '+name
    inventory_name=safe_evidence_name(review['fit_input_inventory'])
    assert review['evidence_sha256'].get(inventory_name)==sha(FIT/inventory_name),'Root must bind actual completed-fit database inventory'
    inventory=json.loads((FIT/inventory_name).read_text(encoding='utf-8-sig'))
    assert inventory['reviewer']=='root' and inventory['decision']=='ACCEPTED_SAVED_FIT_INPUT_INVENTORY'
    assert inventory['source_commit']==PIN and inventory['project']==inventory['revision']=='STV_DS'
    for key in INVENTORY_KEYS:
        assert isinstance(inventory[key],list) and inventory[key] and len(inventory[key])==len(set(inventory[key]))
        for name in inventory[key]:safe_evidence_name(name)
    assert set(inventory['primary_cmp_names'])<=set(inventory['fit_database_names'])
    assert set(inventory['files_sha256'])==set().union(*(set(inventory[key]) for key in INVENTORY_KEYS))
    evidence[inventory_name]=sha(FIT/inventory_name)
    no_overlap()
    return review_path,evidence,fit_plan,metadata_delta,inventory

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--fit-result-sha256');parser.add_argument('--fit-review');parser.add_argument('--fit-review-sha256')
    args=parser.parse_args()
    assert Path(sys.executable).resolve()==PYTHON.resolve(),'Use pinned Python'
    assert sha(LAB/'scripts/quartus_job_guard.py')==sha(BASE/'quartus_job_guard.py')==GUARD_SHA
    assert sha(BASE/'sta_all_corners.tcl')==TCL_SHA and sha(API)==API_SHA
    assert sha(CONSTRAINTS)==CONSTRAINTS_SHA
    plan=dict(state='template-only-no-fit-database-read-or-copy-no-task-no-sta',fitted_directory=str(FIT),
        source_commit=PIN,fitted_input_manifest_sha256=FIT_MANIFEST_SHA,
        command=[str(STA),'-t',str(BASE/'sta_all_corners.tcl')],limits=LIMITS,fitted_fullflow_limits=FIT_LIMITS,
        remaining_pins=['Root-accepted terminal full-flow result SHA256','Root fit review path and SHA256',
            'Root-bound actual generated/map/fit/primary-CMP inventory after native completion',
            'Root-bound exact QSF version literal plus verified LF-only-to-CRLF audit if a raw delta exists'],
        required_acceptance_evidence=list(EVIDENCE),operating_conditions='All actual available conditions, dynamically enumerated',
        clocks='Actual exact clock objects and dynamic counts, no inherited project count',
        zero_paths='Explicit review rows, never PASS; review applicability and incoming transfers',timing_acceptance=False)
    if not args.prepare:print(json.dumps(plan,indent=2));return 0
    for name in ('tree','reports','sta-manifest.json','copied-fitted-files.json','frozen-pins.json'):
        assert not (BASE/name).exists(),'Preserve existing preparation: '+name
    review_path,evidence,fit_plan,metadata_delta,inventory=prerequisites(args)
    copied=snapshot(FIT/'tree');assert copied,'Terminal fitted tree is empty'
    for name,digest in inventory['files_sha256'].items():assert name in copied and copied[name]['sha256']==digest,'Actual reviewed fitted input differs: '+name
    actual_declared_generated={name for name in fit_plan['generated_files'] if name in copied}
    assert actual_declared_generated<=set(inventory['generated_names']),'Root inventory must protect every present declared generated input'
    source_names=sorted(fit_plan['source_files'])
    for name in source_names:assert name in copied
    tree=BASE/'tree';tree.mkdir()
    for name,row in copied.items():
        source=FIT/'tree'/name;target=tree/name;target.parent.mkdir(parents=True,exist_ok=True)
        with source.open('rb') as incoming,target.open('xb') as outgoing:shutil.copyfileobj(incoming,outgoing)
        assert sha(target)==row['sha256'],'Fitted copy changed during preparation: '+name
    assert snapshot(FIT/'tree')==copied,'Original fitted tree changed during copy'
    save(BASE/'copied-fitted-files.json',copied);(BASE/'reports').mkdir()
    scheduler=dict(fit_plan['scheduler']);scheduler.update(task_name='CoreLab-Shienryu-Upstream-STA-AllCorners-Q251-R1',
        working_directory=str(BASE),action_source='scheduler-action-inline.ps1',registration_source='register-start-inline.ps1',
        action_source_sha256=sha(BASE/'scheduler-action-inline.ps1'),registration_source_sha256=sha(BASE/'register-start-inline.ps1'))
    manifest=dict(state='prepared-root-accepted-upstream-all-corner-sta-not-launched',prepared_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        source_commit=PIN,project='STV_DS',revision='STV_DS',fitted_directory=str(FIT),fitted_evidence_sha256=evidence,
        fit_review_path=str(review_path),fit_review_sha256=sha(review_path),accepted_input_metadata_delta=metadata_delta,
        copied_file_count=len(copied),copied_bytes=sum(row['bytes'] for row in copied.values()),copied_manifest_sha256=sha(BASE/'copied-fitted-files.json'),
        source_names=source_names,guard_sha256=GUARD_SHA,sta_tcl_sha256=TCL_SHA,
        api_help_receipt=str(API),api_help_receipt_sha256=API_SHA,constraint_review_path=str(CONSTRAINTS),constraint_review_sha256=CONSTRAINTS_SHA,
        tool_bindings={str(path):sha(path) for path in (PYTHON,STA)},limits=LIMITS,fitted_fullflow_limits=FIT_LIMITS,scheduler=scheduler,command=plan['command'],
        operation='Saved fitted unchanged STV_DS all-available-corner STA only; no map, fit, assembly, source, clock, SDC or seed change',
        zero_paths=plan['zero_paths'],timing_acceptance=False,
        coverage_policy='Enumerate actual available operating conditions and exact clock objects; derive row counts from native inventory; no fixed prior-project corner/clock count',
        working_database='Report every copy-local cache change/addition; require immutable original fitted tree, source/generated/map inputs and actual root-inventoried primary CMP')
    manifest.update({key:inventory[key] for key in INVENTORY_KEYS})
    save(BASE/'sta-manifest.json',manifest)
    save(BASE/'frozen-pins.json',{name:sha(BASE/name) for name in (*SCRIPTS,'sta-manifest.json','copied-fitted-files.json')})
    print(json.dumps(dict(state=manifest['state'],copied_files=len(copied),copied_bytes=manifest['copied_bytes'],
        frozen_pins_sha256=sha(BASE/'frozen-pins.json'),no_task_or_native_launch=True),indent=2));return 0

if __name__=='__main__':raise SystemExit(main())
