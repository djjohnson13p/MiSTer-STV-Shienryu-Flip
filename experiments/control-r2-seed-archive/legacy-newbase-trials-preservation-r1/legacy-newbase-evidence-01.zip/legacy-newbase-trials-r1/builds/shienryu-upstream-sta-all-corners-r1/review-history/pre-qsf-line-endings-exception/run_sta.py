"""One copy-isolated upstream STV_DS saved-fit all-corner STA. Default validates locally only."""
import argparse
import csv
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
TREE=BASE/'tree'
POWERSHELL='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
GIB=1024**3
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=14*GIB,
    tree_rss_bytes=13*GIB,admission_free_commit_bytes=16*GIB,continuous_free_commit_floor_bytes=2*GIB)

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def names(tree):return {path.relative_to(tree).as_posix() for path in tree.rglob('*') if path.is_file()}

def no_overlap():
    scan=subprocess.check_output([POWERSHELL,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not scan or not json.loads(scan),'Quartus overlap'

def validate():
    pins=json.loads((BASE/'frozen-pins.json').read_text())
    for name,digest in pins.items():assert sha(BASE/name)==digest,'Frozen STA input changed: '+name
    m=json.loads((BASE/'sta-manifest.json').read_text());original=Path(m['fitted_directory'])
    assert m['source_commit']=='c072434a61c88c1d9f5dfae09d502cc1b3e7c326'
    assert m['project']==m['revision']=='STV_DS'
    assert m['limits']==LIMITS and m['guard_sha256']==sha(BASE/'quartus_job_guard.py')==GUARD_SHA
    assert sha(BASE/'sta_all_corners.tcl')==m['sta_tcl_sha256']=='e39695c97542326e543e2dd9c93aec61ea94a75b7d28c70efbd4d4cf9f261c9c'
    assert sha(m['api_help_receipt'])==m['api_help_receipt_sha256']
    assert sha(m['fit_review_path'])==m['fit_review_sha256']
    assert sha(m['constraint_review_path'])==m['constraint_review_sha256']
    for name,digest in m['fitted_evidence_sha256'].items():assert sha(original/name)==digest,'Original baseline receipt/report changed: '+name
    for path,digest in m['tool_bindings'].items():assert sha(path)==digest,'Pinned STA tool changed: '+path
    copied=json.loads((BASE/'copied-fitted-files.json').read_text())
    assert sha(BASE/'copied-fitted-files.json')==m['copied_manifest_sha256'] and len(copied)==m['copied_file_count']
    assert names(original/'tree')==set(copied),'Original fitted file membership changed'
    for name,row in copied.items():
        assert sha(original/'tree'/name)==row['sha256'],'Original fitted tree changed: '+name
        assert sha(TREE/name)==row['sha256'],'Prepared STA tree changed: '+name
    for key in ('action_source','registration_source'):assert sha(BASE/m['scheduler'][key])==m['scheduler'][key+'_sha256']
    return m,pins

def validate_pristine(m):
    copied=json.loads((BASE/'copied-fitted-files.json').read_text())
    assert names(TREE)==set(copied),'Prepared STA tree contains another attempt or unbound file'
    assert not any((BASE/'reports').iterdir()),'STA report attempt already exists'

def table(name):
    with (BASE/'reports'/name).open(newline='') as stream:return list(csv.DictReader(stream,delimiter='\t'))

def read_resources():
    # Read-only native memory sample; never creates a Job, task or compiler process.
    spec = importlib.util.spec_from_file_location('shienryu_resource_probe_guard', BASE / 'quartus_job_guard.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    api = module.Windows()
    value = module.Performance(cb=module.C.sizeof(module.Performance))
    api.checked(api.p.GetPerformanceInfo(module.C.byref(value), value.cb), 'GetPerformanceInfo')
    free = (value.limit - value.commit) * value.page
    threshold = 16 * 1024**3
    return dict(observed_utc=module.stamp(), free_commit_bytes=free, admission_free_commit_bytes=threshold,
        admission_pass=free >= threshold, committed_bytes=value.commit*value.page,
        commit_limit_bytes=value.limit*value.page, physical_available_bytes=value.available*value.page,
        physical_total_bytes=value.physical*value.page, no_job_or_task_created=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
    if not (BASE/'frozen-pins.json').exists():
        assert not args.run,'Root-accepted terminal upstream fitted copy has not been prepared'
        print(json.dumps(dict(state='template-only-no-database-read-no-task-no-sta',root_accepted_terminal_upstream_required=True)));return 0
    m,pins=validate();copied=json.loads((BASE/'copied-fitted-files.json').read_text());original=Path(m['fitted_directory'])
    spec=importlib.util.spec_from_file_location('shienryu_upstream_saved_fit_all_corner_guard',BASE/'quartus_job_guard.py')
    guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
    bound_names=sorted(set(m['source_names']+m['generated_names']+m['map_database_names']+m['fit_database_names']))
    def inputs():return {name:sha(TREE/name) for name in bound_names}
    guard.LAB=BASE.parents[1];guard.BASE=BASE;guard.TREE=TREE;guard.BASELINE=m['source_commit']
    guard.QUARTUS=Path('C:/altera_lite/25.1std/quartus');guard.EXE=guard.QUARTUS/'bin64/quartus_sta.exe'
    guard.COMMAND=[str(guard.EXE),'-t',str(BASE/'sta_all_corners.tcl')]
    guard.RUN_KIND='shienryu-upstream-saved-fit-all-available-corner-sta-no-wall';guard.LIMITS=dict(LIMITS);guard.inputs=inputs
    assert guard.COMMAND==m['command'] and guard.LIMITS==m['limits']
    plan=dict(state='local-dry-run-no-task-or-native-job',command=guard.COMMAND,cwd=str(TREE),output=str(BASE),
        source_commit=m['source_commit'],copied_files=len(copied),
        protected_source_and_fitted_inputs=len(bound_names),manifest_sha256=sha(BASE/'sta-manifest.json'),
        adapter_sha256=sha(__file__),sta_tcl_sha256=m['sta_tcl_sha256'],guard_sha256=GUARD_SHA,limits=guard.LIMITS,
        scope=m['operation'],timing_acceptance=False)
    if not args.run:print(json.dumps(plan,indent=2));return 0
    validate_pristine(m)
    for name in ('prelaunch.json','fullflow.log','live.json','result.json','preservation-readback.json'):
        assert not (BASE/name).exists(),'Preserve previous attempt: '+name
    action=json.loads((BASE/'scheduler-action-start.json').read_text(encoding='utf-8-sig'))
    assert action['pid']==os.getppid() and action['parent_name'].lower() in ('svchost.exe','taskeng.exe'),'Use reviewed OS-owned Task Scheduler launch'
    no_overlap();plan.update(scheduler_action_start=action,scheduler_task_name=m['scheduler']['task_name'])
    guard.save(BASE/'prelaunch.json',plan);code=guard.run(inputs())
    original_members=names(original/'tree');working_members=names(TREE)
    original_changed=[name for name,row in copied.items() if name not in original_members or sha(original/'tree'/name)!=row['sha256']]
    original_added=sorted(original_members-set(copied))
    local_changed={name:dict(before=row['sha256'],after=sha(TREE/name) if name in working_members else None)
        for name,row in copied.items() if name not in working_members or sha(TREE/name)!=row['sha256']}
    local_added={name:sha(TREE/name) for name in sorted(working_members-set(copied))}
    immutable=set(m['source_names']+m['generated_names']+m['map_database_names']+m['primary_cmp_names'])
    protected_changes={name:row for name,row in local_changed.items() if name in immutable}
    coverage={};coverage_error=None
    try:
        corners=table('corner-inventory.tsv');perclock=table('clock-check-coverage.tsv');global_rows=table('global-check-coverage.tsv')
        coverage=dict(corners=len(corners),clock_counts=[int(row['clock_count']) for row in corners],
            per_clock_rows=len(perclock),global_rows=len(global_rows),zero_path_rows=sum(row['returned_path_count']=='0' for row in perclock))
        coverage['complete_dynamic_row_counts']=(len(corners)>=2 and len(set(coverage['clock_counts']))==1 and
            all(count>0 for count in coverage['clock_counts']) and
            [int(row['index']) for row in corners]==list(range(1,len(corners)+1)) and
            len(perclock)==sum(coverage['clock_counts'])*4 and len(global_rows)==len(corners)*4)
        coverage['constraints_and_mpw_reports_present']=all((BASE/'reports'/f'corner-{index:02d}-{kind}.rpt').is_file()
            for index in range(1,len(corners)+1) for kind in ('constraints','min-pulse-width'))
    except Exception as error:coverage_error=str(error)
    readback=dict(original_fitted_files_changed=original_changed,original_fitted_files_added=original_added,
        original_fit_result_sha256=sha(original/'result.json'),local_working_files_changed=local_changed,
        local_working_files_added=local_added,protected_source_generated_map_primary_cmp_changes=protected_changes,
        coverage=coverage,coverage_error=coverage_error,zero_path_transfer_applicability_review_required=True,
        STA_exit_is_not_timing_acceptance=True,timing_acceptance=False)
    guard.save(BASE/'preservation-readback.json',readback)
    return 0 if code==0 and not original_changed and not original_added and not protected_changes and not coverage_error and coverage.get('complete_dynamic_row_counts') and coverage.get('constraints_and_mpw_reports_present') else 1

if __name__=='__main__':raise SystemExit(main())
