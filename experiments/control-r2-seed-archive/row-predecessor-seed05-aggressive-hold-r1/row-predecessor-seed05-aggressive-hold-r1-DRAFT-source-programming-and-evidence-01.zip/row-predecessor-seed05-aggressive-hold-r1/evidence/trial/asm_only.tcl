# Assembler only from root-qualified one fixed batch seed fit. No map/fit/STA or assignment export.
package require ::quartus::flow
project_open STV_DS -revision STV_DS
puts "SHIENRYU_BATCH_ASSEMBLER_ONLY_BEGIN"
if {[catch {
    set seed [get_global_assignment -name SEED]
    if {$seed ne "@SEED@"} {error "Stored QSF seed is not exactly@SEED@: $seed"}
    puts "SHIENRYU_BATCH_STORED_SEED_READBACK=$seed"
    execute_module -tool asm -dont_export_assignments
} message]} {
    post_message -type error $message
    project_close -dont_export_assignments
    qexit -error
}
project_close -dont_export_assignments
puts "SHIENRYU_BATCH_ASSEMBLER_ONLY_COMPLETE"
