"""Bounded native result checks. Coverage body is copied exactly from reviewed seed2 STA."""
import csv
import datetime as dt
import hashlib
import math
from pathlib import Path
import re
REQUIRED_CONDITIONS=[dict(model=model,temperature_C=temp,status='PENDING_NOT_ANALYZED') for model in ('slow','fast') for temp in (-40,0,85,100)]
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def rows(p):
    with p.open(newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def coverage(stage):
    BASE=stage
    def table(name):return rows(BASE/'reports'/name)
    timing_matrix=[dict(row) for row in REQUIRED_CONDITIONS]
    coverage={};coverage_error=None
    try:
        corners=table('corner-inventory.tsv');perclock=table('clock-check-coverage.tsv');global_rows=table('global-check-coverage.tsv')
        coverage=dict(corners=len(corners),clock_counts=[int(row['clock_count']) for row in corners],
            per_clock_rows=len(perclock),global_rows=len(global_rows),zero_path_rows=sum(row['returned_path_count']=='0' for row in perclock))
        actual_conditions={(row['model'].lower(),float(row['temperature_C'])) for row in corners}
        expected_conditions={(row['model'],float(row['temperature_C'])) for row in REQUIRED_CONDITIONS}
        for corner in corners:
            key=(corner['model'].lower(),float(corner['temperature_C']))
            target=next((row for row in timing_matrix if (row['model'],float(row['temperature_C']))==key),None)
            if target is not None:
                target['status']='ANALYZED_REQUIRES_SLACK_REVIEW'
                target['native_corner']=int(corner['index'])
                target['checks']={row['check']:dict(slack_ns=None if row['worst_slack_ns']=='NA' else float(row['worst_slack_ns']),classification=row['classification']) for row in global_rows if int(row['corner'])==int(corner['index'])}
                target['minimum_pulse_width']='NATIVE_REPORT_REQUIRES_REVIEW' if (BASE/'reports'/f"corner-{int(corner['index']):02d}-min-pulse-width.rpt").is_file() else 'PENDING_NOT_ANALYZED'
        coverage['required_eight_conditions_complete']=len(corners)==8 and actual_conditions==expected_conditions
        assert coverage['required_eight_conditions_complete'],'All8 Slow/Fast x -40/0/85/100C conditions required; absent cases stay pending'
        coverage['complete_dynamic_row_counts']=(len(corners)>=2 and len(set(coverage['clock_counts']))==1 and
            all(count>0 for count in coverage['clock_counts']) and
            [int(row['index']) for row in corners]==list(range(1,len(corners)+1)) and
            len(perclock)==sum(coverage['clock_counts'])*4 and len(global_rows)==len(corners)*4)
        coverage['constraints_and_mpw_reports_present']=all((BASE/'reports'/f'corner-{index:02d}-{kind}.rpt').is_file()
            for index in range(1,len(corners)+1) for kind in ('constraints','min-pulse-width'))
        # Required reporting-only old-mode coverage; no excluded or absent path is a pass.
        mode_rows=table('old-mode-check-coverage.tsv')
        expected_mode_keys={(int(corner['index']),variant,kind) for corner in corners
            for variant in ('default','no_duplicates') for kind in ('setup','hold')}
        mode_keys=[(int(row['corner']),row['collection_variant'],row['check']) for row in mode_rows]
        coverage['old_mode_rows']=len(mode_rows)
        coverage['old_mode_complete_dynamic_rows']=(len(mode_keys)==len(expected_mode_keys) and set(mode_keys)==expected_mode_keys)
        assert coverage['old_mode_complete_dynamic_rows'],'Missing, duplicate or unexpected old-mode coverage rows'
        mode_reports={};mode_counts={}
        for row in mode_rows:
            corner=int(row['corner']);variant=row['collection_variant'];kind=row['check']
            assert row['source_expression']=='ascal|o_flip_180'
            keepers=int(row['keepers_count']);registers=int(row['registers_count']);paths=int(row['returned_path_count'])
            assert keepers>=0 and registers>=0 and paths in (0,1)
            key=f'{corner}:{variant}';counts=dict(keepers=keepers,registers=registers)
            assert key not in mode_counts or mode_counts[key]==counts,'Mode collection counts differ between setup/hold rows'
            mode_counts[key]=counts
            expected_report=f'corner-{corner:02d}-old-mode-{variant}-{kind}.rpt'
            if keepers==0:
                assert paths==0 and row['worst_slack_ns']=='NA' and row['report_file']=='NA'
                assert row['classification']=='NO_MATCHING_KEEPERS_REQUIRES_REVIEW'
                assert not (BASE/'reports'/expected_report).exists(),'Zero-collection timing report must not exist'
            else:
                assert row['report_file']==expected_report
                report=BASE/'reports'/expected_report
                assert report.is_file() and report.stat().st_size>0,'Missing native targeted full-path report'
                mode_reports[expected_report]=sha(report)
                if paths==0:
                    assert row['worst_slack_ns']=='NA' and row['classification']=='NO_PATHS_REQUIRES_REVIEW'
                else:
                    assert math.isfinite(float(row['worst_slack_ns'])) and row['classification']=='PATH_FOUND_REQUIRES_TIMING_REVIEW'
        coverage['old_mode_collection_counts']=mode_counts
        coverage['old_mode_no_matching_rows']=sum(row['keepers_count']=='0' for row in mode_rows)
        coverage['old_mode_no_timed_path_rows']=sum(row['returned_path_count']=='0' for row in mode_rows)
        coverage['old_mode_report_sha256']=mode_reports
        coverage['old_mode_coverage_sha256']=sha(BASE/'reports/old-mode-check-coverage.tsv')
        coverage['old_mode_diagnostic_reports_complete']=True
        coverage['fixed_profile_mode_paths_present']=all(int(row['keepers_count'])>0 and int(row['registers_count'])>0 and int(row['returned_path_count'])>0 for row in mode_rows)
        assert coverage['fixed_profile_mode_paths_present'],'Fixed profile requires nonempty mode keeper/register and timed-path queries; zero/NA is not a pass'
    except Exception as error:coverage_error=str(error)
    assert coverage_error is None,coverage_error
    for key in ('required_eight_conditions_complete','complete_dynamic_row_counts','constraints_and_mpw_reports_present','old_mode_complete_dynamic_rows','old_mode_diagnostic_reports_complete','fixed_profile_mode_paths_present'):
        assert coverage.get(key) is True,'Coverage qualification failed: '+key
    return coverage,timing_matrix

def fit(stage,seed,qualifier):
    tree=stage/'tree';rpt=tree/'output_files/STV_DS.fit.rpt'
    log=(stage/'fullflow.log').read_text(encoding='utf-8',errors='replace')
    q=qualifier.fit_report_qualification(rpt.read_text(encoding='latin-1'),(tree/'output_files/STV_DS.fit.summary').read_text(encoding='latin-1'),log)
    # Reuse native parser; replace its seed2-only predicates explicitly, never rewrite native logs.
    q.pop('actual_seed_is2');q.pop('stored_seed2_readback');q.pop('passed')
    q['actual_seed_matches']=q['actual_placement_seed']==seed
    q['stored_seed_readback']=f'SHIENRYU_BATCH_STORED_SEED_READBACK={seed}' in log
    q['fit_report_sha256']=sha(rpt)
    q['native_report_fresh']=rpt.stat().st_mtime>=dt.datetime.fromisoformat(__import__('json').loads((stage/'result.json').read_text())['started_utc']).timestamp()-2
    q['passed']=all(q[k] for k in ('actual_seed_matches','stored_seed_readback','no_post_fit_input','zero_requested_and_achieved_placement_and_routing','fitter_only','child_reads_stored_settings_without_export','fitter_successful','native_report_fresh'))
    return q

def output_stats(tree):
    out={}
    for n in ('output_files/STV_DS.rbf','output_files/STV_DS.sof'):
        p=tree/n;out[n]=dict(mtime_ns=p.stat().st_mtime_ns,bytes=p.stat().st_size,sha256=sha(p))
    return out

def assembly(stage,seed,result,before,inherited):
    tree=stage/'tree';outputs=output_stats(tree);started=dt.datetime.fromisoformat(result['started_utc']).timestamp()
    report=tree/'output_files/STV_DS.asm.rpt';text=report.read_text(encoding='latin-1');log=(stage/'fullflow.log').read_text(encoding='utf-8',errors='replace')
    modules=re.findall(r'Info: Running Quartus Prime ([^\r\n]+)',log)
    q=dict(outputs=outputs,assembler_successful=bool(re.search(r';\s*Assembler Status\s*;\s*Successful',text)),
        fresh_RBF_and_SOF=all(v['bytes']>0 and v['mtime_ns']>before[n]['mtime_ns'] and v['mtime_ns']/1e9>=started-2 for n,v in outputs.items()),
        fresh_report=sha(report)!=inherited['output_files/STV_DS.asm.rpt']['sha256'] and report.stat().st_mtime>=started-2,
        assembler_only=modules.count('Assembler')==1 and all(x in ('Shell','Assembler') for x in modules),
        stored_seed_readback=f'SHIENRYU_BATCH_STORED_SEED_READBACK={seed}' in log,asm_report_sha256=sha(report))
    q['passed']=all(q[k] for k in ('assembler_successful','fresh_RBF_and_SOF','fresh_report','assembler_only','stored_seed_readback'))
    return q

def constraint_signature(p):
    chosen=[];diagnostics={}
    for line in p.read_text(encoding='latin-1').splitlines():
        if not line.startswith(';'):continue
        cells=[' '.join(x.split()) for x in line.strip().strip(';').split(';')]
        first=cells[0]
        if re.fullmatch('[a-z_]+',first) and len(cells)==2 and cells[1].isdigit():diagnostics[first]=int(cells[1])
        if re.match(r'^(create_|set_|derive_)',first) or ('Unconstrained' in first and len(cells)==3 and all(x.isdigit() for x in cells[1:])):
            chosen.append(cells)
    assert len(chosen)>20 and {'no_clock','multiple_clock','virtual_clock','no_input_delay','no_output_delay'}<=set(diagnostics)
    return dict(applied_and_ignored_SDC_rows=sorted(chosen),check_timing_summary=diagnostics)

def reference(reports):
    per=rows(reports/'clock-check-coverage.tsv');corners=rows(reports/'corner-inventory.tsv')
    assert len(corners)==8 and len(per)==416
    assert all(float(c['voltage_mV'])==1100 and c['grade']=='Industrial' and c['speed']==('7' if c['model']=='slow' else 'M') and c['clock_count']=='13' for c in corners)
    def keys(c):return sorted((r['clock'],r['clock_object'],r['period_ns'],r['check'],r['returned_path_count']=='0') for r in per if r['corner']==str(c))
    expected=keys(1);assert len(expected)==52 and len(set(expected))==52
    assert all(keys(c)==expected for c in range(1,9))
    signatures=[constraint_signature(reports/f'corner-{c:02d}-constraints.rpt') for c in range(1,9)]
    assert all(x==signatures[0] for x in signatures),'Reference constraints differ across corners'
    return dict(clock_check_keys=expected,constraint_signature=signatures[0],empty_rows_per_corner=sum(x[-1] for x in expected),
        empty_rows_are_not_passes=True,reference_reports=str(reports.resolve()))

def timing(stage,expected):
    cov,matrix=coverage(stage);reports=stage/'reports';actual=reference(reports)
    assert actual['clock_check_keys']==[tuple(x) for x in expected['clock_check_keys']],'Clock identity/period/object or zero-path applicability changed'
    assert actual['constraint_signature']==expected['constraint_signature'],'Applied/ignored SDC or check_timing/UCP summary changed; root review required'
    global_rows=rows(reports/'global-check-coverage.tsv');per=rows(reports/'clock-check-coverage.tsv');mode=rows(reports/'old-mode-check-coverage.tsv')
    assert len({(r['corner'],r['check']) for r in global_rows})==32 and all(r['returned_path_count']=='1' for r in global_rows)
    assert len({(r['corner'],r['clock'],r['check']) for r in per})==416
    clean=all(math.isfinite(float(r['worst_slack_ns'])) and float(r['worst_slack_ns'])>=0 for r in global_rows+mode)
    clean=clean and all(math.isfinite(float(r['worst_slack_ns'])) and float(r['worst_slack_ns'])>=0 for r in per if r['returned_path_count']!='0')
    for c,target in enumerate(matrix,1):
        # Matrix order is model/temperature; native ordering is explicitly looked up.
        native=target['native_corner'];mpw=reports/f'corner-{native:02d}-min-pulse-width.rpt'
        text=mpw.read_text(encoding='latin-1');m=re.search(r'Report Minimum Pulse Width: Found (\d+) results \((\d+) violated\)\.\s+Worst case slack is ([+\-0-9.]+)',text)
        assert m and int(m[1])>0 and math.isfinite(float(m[3])),'Missing/ambiguous MPW native summary'
        target['minimum_pulse_width']=dict(slack_ns=float(m[3]),violated=int(m[2]),reported_paths=int(m[1]),sha256=sha(mpw))
        clean=clean and int(m[2])==0 and float(m[3])>=0
        for check,row in target['checks'].items():row['pass']=row['slack_ns'] is not None and row['slack_ns']>=0
        target['status']='PASS' if all(x['pass'] for x in target['checks'].values()) and int(m[2])==0 and float(m[3])>=0 else 'FAIL'
    negative=[]
    for corner in range(1,9):
        for kind in ('setup','hold','recovery','removal'):
            items=[r for r in per if r['corner']==str(corner) and r['check']==kind]
            for index,row in enumerate(items,1):
                if row['returned_path_count']!='0' and float(row['worst_slack_ns'])<0:
                    p=reports/f'corner-{corner:02d}-{kind}-clock-{index:03d}-negative.rpt'
                    assert p.is_file() and p.stat().st_size>0,'Negative-clock full path report missing'
                    negative.append(dict(corner=corner,clock=row['clock'],check=kind,slack_ns=float(row['worst_slack_ns']),path=p.name,sha256=sha(p)))
    return dict(qualified_clean_candidate=clean,timing_condition_matrix=matrix,coverage=cov,negative_clock_rows=negative,
        constraint_report_sha256={f'corner-{c:02d}':sha(reports/f'corner-{c:02d}-constraints.rpt') for c in range(1,9)},
        inherited_empty_rows_qualified_not_passed=True,full_board_signoff=False)
