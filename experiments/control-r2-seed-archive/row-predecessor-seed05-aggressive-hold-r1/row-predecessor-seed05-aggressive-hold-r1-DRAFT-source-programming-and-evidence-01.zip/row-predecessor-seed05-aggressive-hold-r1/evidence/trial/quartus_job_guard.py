"""Reusable Windows Job guard; launch only through a reviewed project adapter."""
import argparse
import ctypes as C
from ctypes import wintypes as W
import datetime as dt
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

LAB = Path(__file__).resolve().parents[1]
BASE = LAB / 'builds/triple-play-q251-baseline-r1'
TREE = BASE / 'tree'
QUARTUS = Path('C:/altera_lite/25.1std/quartus')
EXE = QUARTUS / 'bin64/quartus_sh.exe'
COMMAND = [str(EXE), '--flow', 'compile', 'MegaDrive', '-c', 'MegaDrive']
GIB = 1024 ** 3
LIMITS = dict(wall_seconds=None, cleanup_reserve_seconds=20,
              job_private_bytes=8 * GIB, tree_rss_bytes=13 * GIB // 2,
              admission_free_commit_bytes=21 * GIB // 2,
              continuous_free_commit_floor_bytes=2 * GIB)
BASELINE = 'becbdee78c48e6eb536871cd03c869f43d7afa4d'
RUN_KIND = 'quartus-baseline'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    for attempt in range(6):
        try:
            os.replace(temporary, path)
            return
        except OSError as error:
            if getattr(error, 'winerror', None) not in (5, 32, 33) or attempt == 5:
                raise
            time.sleep(.05)


def exception_details(error, operation):
    return dict(operation=operation, utc=stamp(), type=type(error).__name__,
                repr=repr(error), message=str(error), errno=getattr(error, 'errno', None),
                winerror=getattr(error, 'winerror', None), filename=getattr(error, 'filename', None),
                filename2=getattr(error, 'filename2', None),
                traceback=''.join(traceback.format_exception(type(error), error, error.__traceback__)))


def record_telemetry_warning(result, error, operation):
    detail = exception_details(error, operation)
    result['telemetry_warning_count'] = result.get('telemetry_warning_count', 0) + 1
    warnings = result.setdefault('telemetry_warnings', [])
    fields = ('operation', 'type', 'errno', 'winerror', 'filename', 'filename2')
    for previous in warnings:
        if all(previous.get(key) == detail.get(key) for key in fields):
            previous['count'] += 1
            previous['last_utc'] = detail['utc']
            return
    detail.update(count=1, last_utc=detail['utc'])
    warnings.append(detail)
    del warnings[:-8]
    print(json.dumps({'telemetry_warning': detail}), flush=True)


def inputs():
    if not EXE.is_file() or not TREE.is_dir():
        raise RuntimeError('Installed Quartus or prepared snapshot is missing')
    qsf = (TREE / 'MegaDrive.qsf').read_text(encoding='utf-8-sig')
    qpf = (TREE / 'MegaDrive.qpf').read_text(encoding='utf-8-sig')
    if not re.search(r'^PROJECT_REVISION\s*=\s*"MegaDrive"\s*$', qpf, re.M):
        raise RuntimeError('Unexpected project revision')
    if not re.search(r'^set_global_assignment -name NUM_PARALLEL_PROCESSORS ALL\s*$', qsf, re.M):
        raise RuntimeError('Original ALL processor setting must be retained')
    original = TREE / 'sys/pll_q17.qip'
    alias = TREE / 'sys/pll_q25.qip'
    if original.read_bytes() != alias.read_bytes():
        raise RuntimeError('Q25 compatibility list must exactly match supplied Q17 bytes')
    if sha(original) != '9d662ba114d5c02e82c0f500e7e9600e02962549c74a84fd5bf2ce34abb69a76':
        raise RuntimeError('Supplied Q17 list differs from reviewed baseline')
    bound = [TREE / name for name in ('MegaDrive.qpf', 'MegaDrive.qsf', 'MegaDrive.sdc',
             'sys/sys.qip', 'sys/sys.tcl', 'sys/sys_analog.tcl', 'sys/sys_top.sdc',
             'sys/pll_q17.qip', 'sys/pll_q25.qip', 'sys/build_id.tcl', 'files.qip')]
    for folder in ('rtl/pll', 'sys/pll_hdmi', 'sys/pll_audio', 'sys/pll_cfg'):
        bound.extend(p for p in (TREE / folder).rglob('*') if p.is_file())
    bound.extend(TREE / name for name in ('rtl/pll.v', 'rtl/pll.qip', 'sys/pll_hdmi.v',
                 'sys/pll_hdmi.qip', 'sys/pll_audio.v', 'sys/pll_audio.qip', 'sys/pll_cfg.qip'))
    return {p.relative_to(TREE).as_posix(): sha(p) for p in sorted(set(bound))}


class BasicLimits(C.Structure):
    _fields_ = [('process_time', C.c_int64), ('job_time', C.c_int64), ('flags', W.DWORD),
                ('min_ws', C.c_size_t), ('max_ws', C.c_size_t), ('active_limit', W.DWORD),
                ('affinity', C.c_size_t), ('priority', W.DWORD), ('scheduling', W.DWORD)]


class IO(C.Structure):
    _fields_ = [(n, C.c_uint64) for n in ('read_ops', 'write_ops', 'other_ops', 'read_bytes', 'write_bytes', 'other_bytes')]


class ExtendedLimits(C.Structure):
    _fields_ = [('basic', BasicLimits), ('io', IO), ('process_memory', C.c_size_t),
                ('job_memory', C.c_size_t), ('peak_process_memory', C.c_size_t), ('peak_job_memory', C.c_size_t)]


class Accounting(C.Structure):
    _fields_ = [(n, C.c_int64) for n in ('user', 'kernel', 'period_user', 'period_kernel')] + [
        (n, W.DWORD) for n in ('faults', 'total', 'active', 'terminated')]


class Performance(C.Structure):
    _fields_ = [('cb', W.DWORD)] + [(n, C.c_size_t) for n in
        ('commit', 'limit', 'peak', 'physical', 'available', 'cache', 'ktotal', 'kpaged', 'knonpaged', 'page')] + [
        (n, W.DWORD) for n in ('handles', 'processes', 'threads')]


class Memory(C.Structure):
    _fields_ = [('cb', W.DWORD), ('faults', W.DWORD)] + [(n, C.c_size_t) for n in
        ('peak_ws', 'ws', 'peak_paged', 'paged', 'peak_nonpaged', 'nonpaged', 'pagefile', 'peak_pagefile', 'private')]


class Startup(C.Structure):
    _fields_ = [('cb', W.DWORD), ('reserved', W.LPWSTR), ('desktop', W.LPWSTR), ('title', W.LPWSTR)] + [
        (n, W.DWORD) for n in ('x', 'y', 'xsize', 'ysize', 'xchars', 'ychars', 'fill', 'flags')] + [
        ('show', W.WORD), ('reserved_size', W.WORD), ('reserved_ptr', C.c_void_p),
        ('stdin', W.HANDLE), ('stdout', W.HANDLE), ('stderr', W.HANDLE)]


class StartupEx(C.Structure):
    _fields_ = [('startup', Startup), ('attributes', C.c_void_p)]


class ProcessInfo(C.Structure):
    _fields_ = [('process', W.HANDLE), ('thread', W.HANDLE), ('pid', W.DWORD), ('tid', W.DWORD)]


class Windows:
    def __init__(self):
        self.k = C.WinDLL('kernel32', use_last_error=True)
        self.p = C.WinDLL('psapi', use_last_error=True)
        signatures = {
            'CreateJobObjectW': ([C.c_void_p, W.LPCWSTR], W.HANDLE),
            'SetInformationJobObject': ([W.HANDLE, C.c_int, C.c_void_p, W.DWORD], W.BOOL),
            'QueryInformationJobObject': ([W.HANDLE, C.c_int, C.c_void_p, W.DWORD, C.POINTER(W.DWORD)], W.BOOL),
            'TerminateJobObject': ([W.HANDLE, W.UINT], W.BOOL),
            'InitializeProcThreadAttributeList': ([C.c_void_p, W.DWORD, W.DWORD, C.POINTER(C.c_size_t)], W.BOOL),
            'UpdateProcThreadAttribute': ([C.c_void_p, W.DWORD, C.c_size_t, C.c_void_p, C.c_size_t, C.c_void_p, C.c_void_p], W.BOOL),
            'DeleteProcThreadAttributeList': ([C.c_void_p], None),
            'CreateProcessW': ([W.LPCWSTR, W.LPWSTR, C.c_void_p, C.c_void_p, W.BOOL, W.DWORD,
                                C.c_void_p, W.LPCWSTR, C.POINTER(StartupEx), C.POINTER(ProcessInfo)], W.BOOL),
            'ResumeThread': ([W.HANDLE], W.DWORD),
            'WaitForSingleObject': ([W.HANDLE, W.DWORD], W.DWORD),
            'OpenProcess': ([W.DWORD, W.BOOL, W.DWORD], W.HANDLE),
            'GetExitCodeProcess': ([W.HANDLE, C.POINTER(W.DWORD)], W.BOOL),
            'CloseHandle': ([W.HANDLE], W.BOOL),
        }
        for name, (args, result) in signatures.items():
            method = getattr(self.k, name)
            method.argtypes, method.restype = args, result
        self.p.GetPerformanceInfo.argtypes = [C.POINTER(Performance), W.DWORD]
        self.p.GetPerformanceInfo.restype = W.BOOL
        self.p.GetProcessMemoryInfo.argtypes = [W.HANDLE, C.POINTER(Memory), W.DWORD]
        self.p.GetProcessMemoryInfo.restype = W.BOOL

    def checked(self, result, operation):
        if not result:
            raise OSError(C.get_last_error(), operation)
        return result

    def free(self):
        info = Performance(cb=C.sizeof(Performance))
        self.checked(self.p.GetPerformanceInfo(C.byref(info), info.cb), 'GetPerformanceInfo')
        return (info.limit - info.commit) * info.page

    def ended(self, handle):
        value = self.k.WaitForSingleObject(handle, 0)
        if value not in (0, 258):
            raise OSError(C.get_last_error(), 'WaitForSingleObject')
        return value == 0

    def query(self, job, kind, value):
        self.checked(self.k.QueryInformationJobObject(job, kind, C.byref(value), C.sizeof(value), None), 'QueryInformationJobObject')
        return value

    def pids(self, job):
        for count in (64, 256, 1024, 4096):
            class Pids(C.Structure):
                _fields_ = [('assigned', W.DWORD), ('listed', W.DWORD), ('ids', C.c_size_t * count)]
            value = Pids()
            okay = self.k.QueryInformationJobObject(job, 3, C.byref(value), C.sizeof(value), None)
            if okay:
                if value.assigned != value.listed or value.listed > count:
                    raise RuntimeError('Incomplete Job membership list')
                return list(value.ids[:value.listed])
            if C.get_last_error() != 234:
                raise OSError(C.get_last_error(), 'Query Job membership')
        raise RuntimeError('Job membership exceeded bounded capacity')


def run(before):
    started = time.monotonic()
    api = Windows()
    result = dict(state='starting', kind=RUN_KIND, started_utc=stamp(), baseline_commit=BASELINE,
                  command=COMMAND, cwd=str(TREE), python=sys.version, limits=LIMITS,
                  launcher_sha256=sha(__file__), application_sha256=sha(COMMAND[0]),
                  quartus_sh_sha256=sha(EXE), input_hashes_before=before,
                  peak_tree_rss_bytes=0, peak_job_private_bytes=0, minimum_free_commit_bytes=None,
                  ownership='atomic JOB_LIST, suspended root, no breakaway, kill-on-close', errors=[])
    paths = [BASE / name for name in ('fullflow.log', 'live.json', 'result.json')]
    if any(p.exists() for p in paths):
        raise RuntimeError('Existing launch outputs are preserved; refusing another run')
    free = api.free()
    result['admission_free_commit_bytes'] = free
    if free < LIMITS['admission_free_commit_bytes']:
        result.update(state='deferred-before-launch', no_child_launched=True)
        save(BASE / 'result.json', result)
        print(json.dumps({'state': result['state'], 'free_commit_bytes': free}), flush=True)
        return 2
    job = root = thread = None
    held = {}
    stage = 'fullflow startup'
    log_offset = 0
    last_live = last_print = 0.0
    save(BASE / 'live.json', result)
    try:
        job = api.checked(api.k.CreateJobObjectW(None, None), 'CreateJobObjectW')
        limits = ExtendedLimits()
        limits.basic.flags = 0x2000 | 0x200  # KILL_ON_JOB_CLOSE | JOB_MEMORY; no BREAKAWAY flags.
        limits.job_memory = LIMITS['job_private_bytes']
        api.checked(api.k.SetInformationJobObject(job, 9, C.byref(limits), C.sizeof(limits)), 'Set Job limits')
        actual = api.query(job, 9, ExtendedLimits())
        if actual.basic.flags != limits.basic.flags or actual.job_memory != limits.job_memory:
            raise RuntimeError('Job limits did not read back exactly')
        with paths[0].open('xb', buffering=0) as log, open(os.devnull, 'rb', buffering=0) as null:
            log_handle, null_handle = msvcrt.get_osfhandle(log.fileno()), msvcrt.get_osfhandle(null.fileno())
            size = C.c_size_t()
            api.k.InitializeProcThreadAttributeList(None, 2, 0, C.byref(size))
            if C.get_last_error() != 122 or not size.value:
                raise OSError(C.get_last_error(), 'Size process attributes')
            storage = C.create_string_buffer(size.value)
            attributes = C.cast(storage, C.c_void_p)
            api.checked(api.k.InitializeProcThreadAttributeList(attributes, 2, 0, C.byref(size)), 'Initialize process attributes')
            try:
                job_list = (W.HANDLE * 1)(job)
                handles = (W.HANDLE * 2)(null_handle, log_handle)
                api.checked(api.k.UpdateProcThreadAttribute(attributes, 0, 0x2000D, job_list,
                            C.sizeof(job_list), None, None), 'Set atomic JOB_LIST')
                api.checked(api.k.UpdateProcThreadAttribute(attributes, 0, 0x20002, handles,
                            C.sizeof(handles), None, None), 'Set inherited HANDLE_LIST')
                startup = StartupEx()
                startup.startup.cb = C.sizeof(startup)
                startup.startup.flags = 0x100  # STARTF_USESTDHANDLES
                startup.startup.stdin, startup.startup.stdout, startup.startup.stderr = null_handle, log_handle, log_handle
                startup.attributes = attributes
                info = ProcessInfo()
                environment = dict(os.environ)
                for name in tuple(environment):
                    if name.startswith(('GIT_TRACE', 'QUARTUS_ROOTDIR')):
                        environment.pop(name)
                environment['QUARTUS_ROOTDIR'] = str(QUARTUS)
                environment['PATH'] = str(QUARTUS / 'bin64') + os.pathsep + environment.get('PATH', '')
                block = C.create_unicode_buffer('\0'.join(k + '=' + v for k, v in sorted(environment.items(), key=lambda x: x[0].upper())) + '\0\0')
                os.set_handle_inheritable(null_handle, True)
                os.set_handle_inheritable(log_handle, True)
                try:
                    api.checked(api.k.CreateProcessW(COMMAND[0], C.create_unicode_buffer(subprocess.list2cmdline(COMMAND)),
                                None, None, True, 0x00080000 | 0x00000400 | 0x08000000 | 0x4,
                                block, str(TREE), C.byref(startup), C.byref(info)), 'Atomic suspended CreateProcessW')
                    # Adopt both creation handles before any fallible cleanup or resume.
                    root, thread = info.process, info.thread
                    result['root_pid'] = info.pid
                finally:
                    os.set_handle_inheritable(log_handle, False)
                    os.set_handle_inheritable(null_handle, False)
            finally:
                api.k.DeleteProcThreadAttributeList(attributes)
            if result['root_pid'] not in api.pids(job):
                raise RuntimeError('Suspended root is absent from its Job')
            if api.k.ResumeThread(thread) == 0xffffffff:
                raise OSError(C.get_last_error(), 'ResumeThread')
            api.checked(api.k.CloseHandle(thread), 'Close root thread')
            thread = None
            result['state'] = 'running'
            print(f"LIVE root_pid={result['root_pid']} stage={stage}", flush=True)
            while True:
                members = api.pids(job)
                account = api.query(job, 1, Accounting())
                ended = api.ended(root)
                if ended and account.active == 0 and not members:
                    break
                rss = private = 0
                for pid in members:
                    if pid in held and api.ended(held[pid]):
                        api.checked(api.k.CloseHandle(held[pid]), 'Close ended reused PID handle')
                        del held[pid]
                    if pid not in held:
                        handle = api.k.OpenProcess(0x101010, False, pid)  # SYNCHRONIZE | QUERY_LIMITED_INFORMATION | VM_READ
                        if not handle:
                            error = C.get_last_error()
                            if error in (5, 87) and pid not in api.pids(job):
                                result.setdefault('proven_exited_before_bind', []).append(pid)
                                continue
                            raise OSError(error, 'Open contained Job member')
                        held[pid] = handle
                    memory = Memory(cb=C.sizeof(Memory))
                    if not api.p.GetProcessMemoryInfo(held[pid], C.byref(memory), memory.cb):
                        error = C.get_last_error()
                        if api.ended(held[pid]):
                            continue
                        raise OSError(error, 'Get contained member memory')
                    rss += memory.ws
                    private += memory.private
                free = api.free()
                peak = api.query(job, 9, ExtendedLimits()).peak_job_memory
                result['peak_tree_rss_bytes'] = max(result['peak_tree_rss_bytes'], rss)
                result['peak_job_private_bytes'] = max(result['peak_job_private_bytes'], peak)
                result['minimum_free_commit_bytes'] = min(result['minimum_free_commit_bytes'] or free, free)
                elapsed = time.monotonic() - started
                added = b''
                try:
                    with paths[0].open('rb') as reader:
                        reader.seek(log_offset)
                        pending = reader.read()
                        next_offset = reader.tell()
                    added, log_offset = pending, next_offset
                except OSError as error:
                    if getattr(error, 'winerror', None) not in (5, 32, 33) and not (
                            isinstance(error, PermissionError) and error.errno == 13):
                        raise
                    record_telemetry_warning(result, error, 'running progress log tail')
                old_stage = stage
                for line in added.decode('utf-8', errors='replace').splitlines():
                    for name, label in (('quartus_map', 'analysis/synthesis'), ('quartus_fit', 'fitter'),
                                        ('quartus_asm', 'assembler'), ('quartus_sta', 'timing analyzer')):
                        if re.search(r'\b' + name + r'(?:\.exe)?\b', line, re.I):
                            stage = label
                if rss > LIMITS['tree_rss_bytes']:
                    raise RuntimeError('Tree RSS cap exceeded')
                if free < LIMITS['continuous_free_commit_floor_bytes']:
                    raise RuntimeError('SYSTEM free commit floor crossed')
                if LIMITS['wall_seconds'] is not None and elapsed >= LIMITS['wall_seconds'] - LIMITS['cleanup_reserve_seconds']:
                    raise RuntimeError('Active wall budget expired; cleanup reserve retained')
                result.update(stage=stage, elapsed_seconds=round(elapsed, 3), live_job_pids=members,
                              live_job_rss_bytes=rss, live_member_private_bytes=private, free_commit_bytes=free)
                if elapsed - last_live >= 5 or stage != old_stage:
                    try:
                        save(BASE / 'live.json', result)
                    except OSError as error:
                        if getattr(error, 'winerror', None) not in (5, 32, 33):
                            raise
                        record_telemetry_warning(result, error, 'running live status publication')
                    last_live = elapsed
                if elapsed - last_print >= 60 or stage != old_stage:
                    print(f"LIVE {elapsed:.0f}s {stage}; RSS={rss/GIB:.2f}GiB free_commit={free/GIB:.2f}GiB", flush=True)
                    last_print = elapsed
                time.sleep(1)
    except BaseException as error:
        result['errors'].append(repr(error))
        result.setdefault('exception_details', []).append(exception_details(error, 'active compiler monitor'))
    finally:
        cleanup_end = time.monotonic() + 20
        terminal = False
        if job:
            try:
                terminal = not api.pids(job) and api.query(job, 1, Accounting()).active == 0 and (not root or api.ended(root)) and all(api.ended(h) for h in held.values())
            except BaseException as error:
                result['errors'].append('final membership: ' + repr(error))
                result.setdefault('exception_details', []).append(exception_details(error, 'final membership'))
            if not terminal:
                try:
                    api.checked(api.k.TerminateJobObject(job, 1), 'Terminate only owned Job')
                    result['job_termination_requested'] = True
                except BaseException as error:
                    result['errors'].append('termination: ' + repr(error))
                    result.setdefault('exception_details', []).append(exception_details(error, 'owned Job termination'))
            while time.monotonic() < cleanup_end:
                try:
                    terminal = not api.pids(job) and api.query(job, 1, Accounting()).active == 0 and (not root or api.ended(root)) and all(api.ended(h) for h in held.values())
                    if terminal:
                        break
                except BaseException as error:
                    result['errors'].append('terminal wait: ' + repr(error))
                    result.setdefault('exception_details', []).append(exception_details(error, 'terminal wait'))
                    break
                time.sleep(.1)
            try:
                result['final_job_pids'] = api.pids(job)
                info = api.query(job, 1, Accounting())
                result.update(final_job_active_processes=info.active, total_job_processes=info.total)
                result['peak_job_private_bytes'] = max(result['peak_job_private_bytes'], api.query(job, 9, ExtendedLimits()).peak_job_memory)
                result['held_processes_all_signaled'] = all(api.ended(h) for h in held.values())
                terminal = terminal and result['held_processes_all_signaled']
            except BaseException as error:
                terminal = False
                result['errors'].append('terminal proof: ' + repr(error))
                result.setdefault('exception_details', []).append(exception_details(error, 'terminal proof'))
        if root:
            try:
                result['root_signaled'] = api.ended(root)
                if result['root_signaled']:
                    code = W.DWORD()
                    api.checked(api.k.GetExitCodeProcess(root, C.byref(code)), 'Get root exit code')
                    result['flow_exit_code'] = code.value
            except BaseException as error:
                result['errors'].append('root exit: ' + repr(error))
                result.setdefault('exception_details', []).append(exception_details(error, 'root exit'))
        result['all_job_processes_terminal'] = terminal
        # Every close is attempted independently, including after monitor/termination errors.
        for label, handle in [('thread', thread), *[(f'member {pid}', h) for pid, h in held.items()], ('root', root), ('job', job)]:
            if handle:
                try:
                    api.checked(api.k.CloseHandle(handle), 'Close ' + label)
                except BaseException as error:
                    result['errors'].append('close: ' + repr(error))
                    result.setdefault('exception_details', []).append(exception_details(error, 'close ' + label))
        result['all_handles_closed'] = not any(e.startswith('close:') for e in result['errors'])
        if job and not terminal:
            result['kill_on_close_fallback_not_terminal_proof'] = True
        try:
            after = inputs()
            result['input_hashes_after'] = after
            result['changed_bound_inputs'] = {name: {'before': before.get(name), 'after': after.get(name)}
                for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)}
        except BaseException as error:
            result['errors'].append('input readback: ' + repr(error))
            result.setdefault('exception_details', []).append(exception_details(error, 'input readback'))
        result.update(state='terminal', ended_utc=stamp(), elapsed_seconds=round(time.monotonic() - started, 3))
        result['launcher_success'] = result.get('flow_exit_code') == 0 and terminal and result['all_handles_closed'] and not result['errors']
        result['clean_flow_or_timing_acceptance'] = False  # Root must inspect actual reports/diagnostics.
        save(BASE / 'result.json', result)
        save(BASE / 'live.json', result)
        print(json.dumps({k: result.get(k) for k in ('state', 'flow_exit_code', 'launcher_success',
              'elapsed_seconds', 'peak_tree_rss_bytes', 'peak_job_private_bytes', 'all_job_processes_terminal', 'errors')}), flush=True)
    return 0 if result['launcher_success'] else 1


def main():
    global BASE, COMMAND, RUN_KIND
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--run', action='store_true', help='Launch the ONE fixed baseline fullflow; otherwise dry-run only')
    modes.add_argument('--smoke', action='store_true', help='Launch only a tiny pinned-Python exit-0 child in the same Job; never Quartus')
    args = parser.parse_args()
    before = inputs()
    if not args.run and not args.smoke:
        print(json.dumps(dict(state='dry-run-no-job-no-child-no-output-writes', command=COMMAND,
              cwd=str(TREE), limits=LIMITS, baseline_commit=BASELINE, bound_inputs=len(before),
              q17_q25_identical=True, original_processor_setting='ALL'), indent=2))
        return 0
    if args.smoke:
        BASE = BASE / 'launcher-smoke-r2'
        BASE.mkdir(exist_ok=False)
        COMMAND = [sys.executable, '-B', '-c', 'import time; print("OWNED_JOB_SMOKE_EXIT0", flush=True); time.sleep(0.25)']
        RUN_KIND = 'tiny-python-ownership-smoke-not-quartus'
    return run(before)


if __name__ == '__main__':
    raise SystemExit('Module only: use a separately reviewed project adapter; no child launched')
