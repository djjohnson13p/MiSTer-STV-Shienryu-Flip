"""One isolated saved-map seed5 fit/ASM/STA task. Default template check; explicit root review precedes --start."""
import argparse
import base64
import json
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
import trial as batch

def cleanup():
    # Called after the synchronous scheduler action returns, never from the running task.
    batch.validate();result=batch.load(BASE/'experiment-result.json');batch.no_overlap()
    native_outcomes={}
    for p in (BASE/'stages').iterdir():
        r=p/'result.json'
        if r.exists():
            row=batch.load(r)
            if row.get('state')=='deferred-before-launch' and row.get('no_child_launched') is True:continue
            assert row['state']=='terminal' and row['all_job_processes_terminal'] and row['all_handles_closed']
            assert row['final_job_active_processes']==0 and row['errors']==[]
            assert set(row.get('changed_bound_inputs',{}))<=({'db/STV_DS.tiscmp.fastest_slow_1100mv_85c.ddb'} if p.name=='sta' else set()),'Guard input integrity failure requires root recovery'
            native_outcomes[p.name]={k:row.get(k) for k in ('flow_exit_code','launcher_success','errors','changed_bound_inputs')}
            # Nonzero native/trial exit is retained; never substitute timing success for safe closure.
    assert (BASE/'scheduler-action-exit.json').exists()
    assert batch.load(BASE/'scheduler-action-exit.json')['exit_code']==result['exit_code']
    assert not (BASE/'terminal-task-cleanup.json').exists()
    # Exact registered encoded action and Ready state are checked before unregister.
    script=r'''$ErrorActionPreference='Stop'
$base='@BASE@'
$name='@TASK@'
$task=Get-ScheduledTask -TaskName $name -TaskPath '\'
$info=Get-ScheduledTaskInfo -TaskName $name -TaskPath '\'
if ($task.State -ne 'Ready') {throw 'Exact experiment task is not Ready'}
$inline=Get-Content -Raw -LiteralPath (Join-Path $base 'scheduler-action-inline.ps1')
$arguments='-NoProfile -NonInteractive -WindowStyle Hidden -EncodedCommand '+[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($inline))
$exe='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
if ($task.Actions.Count -ne 1 -or $task.Actions[0].Execute -ne $exe -or $task.Actions[0].Arguments -ne $arguments -or $task.Actions[0].WorkingDirectory -ne $base) {throw 'Exact registered action differs'}
$exit=Get-Content -Raw -LiteralPath (Join-Path $base 'scheduler-action-exit.json') | ConvertFrom-Json
if ($info.LastTaskResult -ne $exit.exit_code) {throw 'Task result differs'}
$native=@(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'})
if ($native.Count) {throw 'Quartus still active'}
Unregister-ScheduledTask -TaskName $name -TaskPath '\' -Confirm:$false
if (Get-ScheduledTask -TaskName $name -TaskPath '\' -ErrorAction SilentlyContinue) {throw 'Exact task still registered'}
[pscustomobject]@{task_name=$name;exact_registered_action_verified=$true;exact_task_unregistered=$true;last_task_result=$info.LastTaskResult;all_job_processes_terminal=$true;all_handles_closed=$true;remaining_owned_or_quartus_processes=@();errors=@();utc=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json
'''.replace('@BASE@',str(BASE)).replace('@TASK@',batch.TASK)
    reply=subprocess.run([batch.PS,'-NoProfile','-NonInteractive','-WindowStyle','Hidden','-EncodedCommand',base64.b64encode(script.encode('utf-16-le')).decode()],capture_output=True,text=True)
    assert reply.returncode==0,reply.stderr
    receipt=json.loads(reply.stdout);receipt['experiment_result_sha256']=batch.sha(BASE/'experiment-result.json')
    receipt['root_admission_sha256']=batch.load(BASE/'trial-manifest.json')['root_admission_sha256']
    receipt['native_stage_outcomes']=native_outcomes;receipt['recorded_trial_exit_code']=result['exit_code']
    receipt['generated_by']='experiment-cleanup-audit-not-manual-root-review';batch.save(BASE/'terminal-task-cleanup.json',receipt)
    print(json.dumps(receipt,indent=2));return 0

def main():
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group();g.add_argument('--start',action='store_true');g.add_argument('--cleanup',action='store_true')
    p.add_argument('--review');p.add_argument('--review-sha256');a=p.parse_args();batch.template_pins()
    if a.cleanup:return cleanup()
    if not a.start:
        print(json.dumps(dict(state='TEMPLATE_ONLY_NO_EXTRACTION_DB_TASK_OR_NATIVE_JOB',frozen=(BASE/'frozen-pins.json').exists())));return 0
    m=batch.validate();batch.frozen_review(a.review,a.review_sha256);batch.no_overlap()
    for name in ('launch-admission.json','task-registration-attempt.json','registered-task.xml','registration-receipt.json','start-receipt.json','scheduler-action-start.json','experiment-result.json','preservation-index.json'):
        assert not (BASE/name).exists(),'Previous attempt exists; never retry automatically: '+name
    assert not (BASE/'stages').exists(),'Never replay an occupied trial'
    batch.check_snapshot(batch.PARENT/'stages/full/tree',batch.load(BASE/'parent-files.json'))
    resources=batch.resources()
    if not resources['admission_pass']:print(json.dumps(dict(state='DEFERRED_NO_TASK_NO_JOB',resources=resources)));return 2
    batch.save(BASE/'launch-admission.json',dict(review_path=str(Path(a.review).resolve()),review_sha256=a.review_sha256))
    batch.save(BASE/'task-registration-attempt.json',dict(task_name=batch.TASK,frozen_pins_sha256=batch.sha(BASE/'frozen-pins.json'),root_admission_sha256=m['root_admission_sha256']))
    source=(BASE/'register-start-inline.ps1').read_text();encoded=base64.b64encode(source.encode('utf-16-le')).decode()
    reply=subprocess.run([batch.PS,'-NoProfile','-NonInteractive','-WindowStyle','Hidden','-EncodedCommand',encoded],capture_output=True,text=True)
    (BASE/'registration-stdout.txt').write_text(reply.stdout,encoding='utf-8');(BASE/'registration-stderr.txt').write_text(reply.stderr,encoding='utf-8')
    print(json.dumps(dict(registration_exit=reply.returncode,task_name=batch.TASK,do_not_repeat=True)));return reply.returncode

if __name__=='__main__':raise SystemExit(main())
