"""One root-reviewed saved-map seed5 trial on exact6eb; default is static plan only."""
import argparse,datetime as dt,hashlib,importlib.util,json,math,os,re,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
LAB=BASE.parents[2]
PARENT=BASE.parent/'row-predecessor-native-draft-r1'
SOURCE='6eb9367e2d64c18b0b109d221a0bc07d35d493b4'
VARIANT='73ca65c64ef89e037e3995ca1faa56e3f7b8a1480b1a2f20190fb3d17b41ef57'
SEED=5
TASK='CoreLab-Shienryu-Seed05-AggressiveHold-FitASMSTA-Q251-R1'
PS='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
PYTHON=Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
QUARTUS=Path('C:/altera_lite/25.1std/quartus')
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
GIB=1024**3
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,tree_rss_bytes=9*GIB,admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)
PRIMARY='db/STV_DS.cmp.cdb'
BINARIES=['output_files/STV_DS.rbf','output_files/STV_DS.sof']
BASELINE_QSF5='a7b89e1e946dbee5cca617b720618a5b1c7287219b3e6b3dfb230112b1e3ac6f'
HOLD_LINE=b'set_global_assignment -name TDC_AGGRESSIVE_HOLD_CLOSURE_EFFORT ON\r\n'
FILES=('trial.py','checks.py','launch_task.py','quartus_job_guard.py','fit_only.tcl','asm_only.tcl','sta_all_corners.tcl','scheduler-action-inline.ps1','register-start-inline.ps1','PLAN.md','provenance.json','reuse-adapter.diff','local-validation.json')

def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def load(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')

def stamp():return dt.datetime.now(dt.timezone.utc).isoformat()

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def no_overlap():
    value=subprocess.check_output([PS,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not value or not json.loads(value),'Quartus active: no parent-tree access/copy or next stage'

def snapshot(tree):
    result={}
    for p in sorted(tree.rglob('*')):
        assert not p.is_symlink(),'Symlink forbidden'
        if p.is_file():result[p.relative_to(tree).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p))
    return result

def check_snapshot(tree,expected):assert snapshot(tree)==expected,'Immutable checkpoint changed: '+str(tree)

def safe_name(name):
    assert isinstance(name,str) and name and not Path(name).is_absolute() and '\\' not in name
    assert all(part not in ('','.','..') for part in name.split('/'));return name

def copy_checkpoint(parent,target,expected):
    no_overlap();check_snapshot(parent,expected)
    assert not target.exists(),'Never replay/overwrite a seed or stage'
    assert shutil.disk_usage(BASE).free>=sum(x['bytes'] for x in expected.values())+2*GIB,'Copy disk headroom below2GiB'
    target.mkdir(parents=True)
    for name,row in expected.items():
        safe_name(name);dst=target/name;dst.parent.mkdir(parents=True,exist_ok=True)
        with (parent/name).open('rb') as a,dst.open('xb') as b:shutil.copyfileobj(a,b)
        assert sha(dst)==row['sha256']
    check_snapshot(parent,expected);check_snapshot(target,expected)

def terminal(directory):
    r=load(directory/'result.json')
    assert r['state']=='terminal' and r['flow_exit_code']==0 and r['launcher_success'] and r['errors']==[]
    assert r['all_job_processes_terminal'] and r['all_handles_closed'] and r['final_job_active_processes']==0
    return r

def resources():
    g=module(BASE/'quartus_job_guard.py','batch_resource_guard');api=g.Windows();v=g.Performance(cb=g.C.sizeof(g.Performance))
    api.checked(api.p.GetPerformanceInfo(g.C.byref(v),v.cb),'GetPerformanceInfo')
    free=(v.limit-v.commit)*v.page;return dict(free_commit_bytes=free,admission_pass=free>=LIMITS['admission_free_commit_bytes'])

def template_pins():
    pins=load(BASE/'template-pins.json');assert set(pins)==set(FILES)
    for n,h in pins.items():assert sha(BASE/safe_name(n))==h,'Template changed: '+n
    assert sha(BASE/'quartus_job_guard.py')==sha(LAB/'scripts/quartus_job_guard.py')==GUARD_SHA
    for p,h in load(BASE/'provenance.json')['external_bound_files'].items():assert sha(p)==h,'Reference changed: '+p
    return pins

def parent_proofs():
    e=load(PARENT/'experiment-result.json');q=load(PARENT/'stages/full/qualification.json')
    assert e['source_commit']==SOURCE and e['variant_exact_sha256']==VARIANT and e['seed']==4 and e['BUILD_DATE']=='261025'
    assert e['exit_code']==0 and e['state']=='COMPLETED_MEASUREMENT_REQUIRES_ROOT_REVIEW'
    assert sha(PARENT/'preservation-index.json')==e['preservation_index_sha256']
    for st in ('full','sta'):terminal(PARENT/'stages'/st)
    assert q['passed'] and q['actual_placement_seed']==4 and q['no_post_fit_input'] and q['zero_requested_and_achieved_placement_and_routing']
    c=load(PARENT/'terminal-task-cleanup.json')
    assert c['task_name']=='CoreLab-Shienryu-RowPredecessor-Seed04-FullAndSTA-Q251-R1'
    assert c['exact_registered_action_verified'] and c['exact_task_unregistered'] and c['last_task_result']==0
    assert c['all_job_processes_terminal'] and c['all_handles_closed'] and c['remaining_owned_or_quartus_processes']==[] and c['errors']==[]
    assert load(PARENT/'scheduler-action-exit.json')['exit_code']==0
    decision=load(BASE/'provenance.json')['hypothesis_path'];h=load(Path(decision))
    assert h['decision']=='RECOMMEND_ONE_SEED05_FITTER_TRIAL_ON_UNCHANGED_6EB_MAPPED_DESIGN'
    source=load(PARENT/'input-manifest.json');assert source['source_commit']==SOURCE and source['variant_exact_sha256']==VARIANT
    receipt=source['source_commit_receipt'];assert sha(Path(receipt['path']))==receipt['sha256']
    assert load(Path(receipt['path']))['source_commit']==SOURCE
    return source

def admission(path,digest):
    assert Path(path).is_absolute() and re.fullmatch('[0-9a-f]{64}',digest or '') and sha(Path(path))==digest
    a=load(Path(path));assert a['reviewer']=='root' and a['decision']=='ACCEPTED_ROW_PREDECESSOR_SEED05_AGGRESSIVE_HOLD_TRIAL'
    assert a['source_commit']==SOURCE and a['variant_exact_sha256']==VARIANT and a['seed']==SEED and a['BUILD_DATE']=='261025'
    assert a['limits']==LIMITS and a['template_pins_sha256']==sha(BASE/'template-pins.json')
    assert a['parent_checkpoint_sha256']==sha(PARENT/'stages/full/checkpoint.json')
    proof=load(BASE/'provenance.json')
    assert a['hypothesis_sha256']==proof['external_bound_files'][proof['hypothesis_path']]
    assert a['parent_root_final_review_sha256']==proof['external_bound_files'][proof['parent_root_final_review_path']]
    assert a['targeted_hold_trial_selected'] is True and a['one_trial_only'] is True
    assert a['experimental_QSF_assignment']=='TDC_AGGRESSIVE_HOLD_CLOSURE_EFFORT ON'
    assert a['timing_acceptance'] is False and a['hardware_acceptance'] is False
    parent_proofs();return a

def freeze(path,digest):
    template_pins();a=admission(path,digest);no_overlap()
    for n in ('trial-manifest.json','parent-files.json','frozen-pins.json','stages','experiment-result.json'):
        assert not (BASE/n).exists(),'Occupied trial: '+n
    original=load(PARENT/'stages/full/checkpoint.json');assert len(original)==1051
    check_snapshot(PARENT/'stages/full/tree',original)
    src=load(PARENT/'input-manifest.json');names=sorted(src['source_files']);assert len(names)==203
    roles=dict(source_names=names,generated_names=['build_id.v','jtag.cdf'],
        map_database_names=['db/STV_DS.db_info','db/STV_DS.map.cdb','db/STV_DS.map.hdb','db/STV_DS.map.rdb'],
        fit_database_names=sorted(n for n in original if n==PRIMARY or n.startswith('db/STV_DS.tiscmp.') and n.endswith('.ddb')),
        primary_cmp_names=[PRIMARY])
    assert roles['fit_database_names']==load(BASE/'provenance.json')['actual_parent_fit_roles']
    assert all(n in original for v in roles.values() for n in v)
    assert (PARENT/'stages/full/tree/build_id.v').read_bytes()==b'`define BUILD_DATE "261025"'
    assert sha(PARENT/'stages/full/tree/sys/ascal.vhd')==VARIANT
    qsf=(PARENT/'stages/full/tree/STV_DS.qsf').read_bytes();needle=b'set_global_assignment -name SEED 4\r\n'
    assert qsf.count(needle)==1 and b'25.1std.0 Lite Edition' in qsf and qsf.count(b'\n')==qsf.count(b'\r\n')
    pre=qsf.replace(needle,b'set_global_assignment -name SEED 5\r\n',1)
    assert hashlib.sha256(pre).hexdigest()==BASELINE_QSF5 and pre.endswith(b'\r\n') and b'TDC_AGGRESSIVE_HOLD_CLOSURE_EFFORT' not in pre
    reference=load(Path(load(BASE/'provenance.json')['baseline_seed05_start_path']))
    assert {n for n in original if original[n]!=reference[n]}=={'STV_DS.qsf'}
    assert reference['STV_DS.qsf']==dict(bytes=len(pre),sha256=BASELINE_QSF5)
    for p,h in a['tool_bindings'].items():assert sha(Path(p))==h
    expected_tools={str(PYTHON)}|{str(QUARTUS/'bin64'/n) for n in ('quartus_sh.exe','quartus_fit.exe','quartus_asm.exe','quartus_sta.exe')}
    assert set(a['tool_bindings'])==expected_tools
    save(BASE/'parent-files.json',original)
    save(BASE/'trial-manifest.json',dict(operation='ONE_SAVED_MAP_SEED05_AGGRESSIVE_HOLD_FIT_ASM_ALL8_STA',source_commit=SOURCE,
        variant_exact_sha256=VARIANT,seed=SEED,BUILD_DATE='261025',parent_directory=str(PARENT/'stages/full/tree'),
        parent_checkpoint_sha256=sha(PARENT/'stages/full/checkpoint.json'),parent_files_sha256=sha(BASE/'parent-files.json'),
        root_admission=str(Path(path).resolve()),root_admission_sha256=digest,limits=LIMITS,roles=roles,
        template_pins_sha256=sha(BASE/'template-pins.json'),coverage_reference_sha256=sha(PARENT/'coverage-reference.json'),
        tool_bindings=a['tool_bindings'],seed_start_QSF_sha256=hashlib.sha256(pre+HOLD_LINE).hexdigest(),baseline_seed05_QSF_sha256=BASELINE_QSF5,experimental_QSF_assignment='TDC_AGGRESSIVE_HOLD_CLOSURE_EFFORT ON',
        inherited_fit_caches_present=True,manual_root_review=False))
    pins=template_pins();save(BASE/'frozen-pins.json',{**pins,**{n:sha(BASE/n) for n in ('parent-files.json','trial-manifest.json')}})
    return dict(state='FROZEN_NO_TREE_COPY_TASK_OR_NATIVE_JOB',frozen_pins_sha256=sha(BASE/'frozen-pins.json'),root_frozen_review_still_required=True)

def validate():
    template_pins()
    for n,h in load(BASE/'frozen-pins.json').items():assert sha(BASE/n)==h
    m=load(BASE/'trial-manifest.json');assert m['source_commit']==SOURCE and m['seed']==SEED and m['limits']==LIMITS
    assert m['operation']=='ONE_SAVED_MAP_SEED05_AGGRESSIVE_HOLD_FIT_ASM_ALL8_STA'
    assert m['parent_checkpoint_sha256']==sha(PARENT/'stages/full/checkpoint.json') and m['parent_files_sha256']==sha(BASE/'parent-files.json')
    assert m['coverage_reference_sha256']==sha(PARENT/'coverage-reference.json')
    admission(m['root_admission'],m['root_admission_sha256'])
    for p,h in m['tool_bindings'].items():assert sha(Path(p))==h
    return m

def frozen_review(path,digest):
    assert Path(path).is_absolute() and re.fullmatch('[0-9a-f]{64}',digest or '') and sha(Path(path))==digest
    r=load(Path(path));assert r['reviewer']=='root' and r['decision']=='ACCEPTED_FROZEN_SEED05_AGGRESSIVE_HOLD_FOR_LAUNCH'
    assert r['task']==TASK and r['source_commit']==SOURCE and r['seed']==SEED
    assert r['frozen_pins_sha256']==sha(BASE/'frozen-pins.json');return r

def guarded(stage,kind,m):
    no_overlap();tree=stage/'tree';roles=m['roles'];keys=('source_names','generated_names','map_database_names')
    if kind=='asm':keys+=('primary_cmp_names',)
    if kind=='sta':keys+=('fit_database_names',)
    bound=sorted(set().union(*(set(roles[k]) for k in keys))|(set(BINARIES) if kind=='sta' else set()))
    name='sta_all_corners.tcl' if kind=='sta' else kind+'_only.tcl';raw=(BASE/name).read_bytes()
    if kind!='sta':assert raw.count(b'@SEED@')==2;raw=raw.replace(b'@SEED@',str(SEED).encode())
    tcl=stage/name
    with tcl.open('xb') as f:f.write(raw)
    static={str((BASE/n).resolve()):h for n,h in load(BASE/'frozen-pins.json').items()}
    static.update(load(BASE/'provenance.json')['external_bound_files'])
    static.update(m['tool_bindings']);static[str(tcl.resolve())]=sha(tcl)
    static[m['root_admission']]=m['root_admission_sha256']
    launch=load(BASE/'launch-admission.json');static[launch['review_path']]=launch['review_sha256']
    static[str((BASE/'launch-admission.json').resolve())]=sha(BASE/'launch-admission.json')
    if kind=='fit':static[str((stage/'seed-start-files.json').resolve())]=sha(stage/'seed-start-files.json')
    def inputs():return {**{n:sha(tree/n) for n in bound},**{p:sha(Path(p)) for p in static}}
    before=inputs();g=module(BASE/'quartus_job_guard.py','seed05_'+kind+'_guard')
    exe=QUARTUS/'bin64'/('quartus_sta.exe' if kind=='sta' else 'quartus_sh.exe');command=[str(exe),'-t',str(tcl)]
    g.LAB=LAB;g.BASE=stage;g.TREE=tree;g.BASELINE=SOURCE;g.QUARTUS=QUARTUS;g.EXE=exe
    g.COMMAND=command;g.RUN_KIND='row-predecessor-seed05-aggressive-hold-'+kind+'-no-wall';g.LIMITS=dict(LIMITS);g.inputs=inputs
    save(stage/'stage-manifest.json',dict(operation=kind,seed=SEED,source_commit=SOURCE,command=command,limits=LIMITS,
        bound_inputs=before,tcl_sha256=sha(tcl),root_admission_sha256=m['root_admission_sha256'],manual_root_review=False))
    assert g.run(before)==0,'Guard/native stage failure; do not advance'
    result=terminal(stage);no_overlap();after=inputs();changed={n for n in before if before[n]!=after[n]}
    allowed={'db/STV_DS.tiscmp.fastest_slow_1100mv_85c.ddb'} if kind=='sta' else set()
    assert changed<=allowed,'Protected input changed: '+repr(changed)
    assert all(sha(Path(p))==h for p,h in static.items()),'Static adapter/tool/admission changed'
    return result

def native_summary(text):
    found=re.search(r'Report Timing: Found (\d+) (\w+) paths \((\d+) violated\)\.\s+Worst case slack is ([+\-0-9.]+)',text)
    assert found and int(found[1])>0 and int(found[3])>=0 and math.isfinite(float(found[4])),'Native timing summary missing'
    return dict(reported_paths=int(found[1]),check=found[2],violated=int(found[3]),display_slack_ns=float(found[4]))

def ignored_assignment_rows(text):
    lines=text.splitlines();start=next(i for i,s in enumerate(lines) if s.startswith('; Ignored Assignments'))
    rows=[];header=False
    for line in lines[start+1:]:
        if not line.strip() and header:break
        if not line.startswith(';'):continue
        cells=[' '.join(v.split()) for v in line.strip().strip(';').split(';')]
        if cells[0]=='Name':assert len(cells)==6;header=True;continue
        if header:assert len(cells)==6;rows.append(cells)
    assert header,'Native Ignored Assignments table missing'
    return sorted(rows)

def setting_acceptance(stage):
    proof=load(BASE/'provenance.json');log=(stage/'fullflow.log').read_text(encoding='utf-8',errors='replace')
    report=stage/'tree/output_files/STV_DS.fit.rpt';text=report.read_text(encoding='latin-1')
    baseline=Path(proof['baseline_seed05_fit_report_path']).read_text(encoding='latin-1')
    before=ignored_assignment_rows(baseline);after=ignored_assignment_rows(text)
    label=re.compile(r'TDC_AGGRESSIVE_HOLD_CLOSURE_EFFORT|aggressive[\s_-]+hold(?:[\s_-]+timing)?[\s_-]+closure',re.I)
    rejected=[dict(source='Ignored Assignments',text=' ; '.join(r)) for r in after if label.search(' '.join(r))]
    for origin,content in [('combined native stdout/stderr',log),('fit report',text)]:
        lines=content.splitlines()
        for i,line in enumerate(lines):
            context='\n'.join(lines[max(0,i-2):i+3])
            if label.search(line) and re.search(r'warning|error',context,re.I) and re.search(r'ignored|unsupported|not supported|not applicable|unknown|unrecognized|not recognized|invalid|illegal|no effect',context,re.I):
                rejected.append(dict(source=origin,text=context))
    readback=re.findall(r'^SHIENRYU_AGGRESSIVE_HOLD_STORED_READBACK=([^\r\n]+)',log,re.M)
    stored=len(readback)==1 and readback[0].strip().upper()=='ON'
    transfer=[s for s in text.splitlines() if re.search(r'\b10929\b|Ignored Clock Transfers Due to Huge Delay Added for Hold',s)]
    sections=[];lines=text.splitlines()
    for i,line in enumerate(lines):
        if line.startswith('; Ignored Clock Transfers Due to Huge Delay Added for Hold'):
            block=[]
            for entry in lines[i:]:
                if not entry.strip() and block:break
                block.append(entry)
            sections.append('\n'.join(block))
    return dict(requested_assignment='TDC_AGGRESSIVE_HOLD_CLOSURE_EFFORT ON',stored_native_readback=readback,
        readback_ON=stored,explicit_setting_rejections=rejected,accepted_input_no_rejection_observed=stored and not rejected,
        normalized_baseline_ignored_rows=before,normalized_actual_ignored_rows=after,
        ignored_rows_added=[r for r in after if r not in before],ignored_rows_removed=[r for r in before if r not in after],
        disabled_hold_transfer_10929_or_table_messages=transfer,
        ignored_hold_transfer_report_sections=sections,
        baseline_fit_report_sha256=sha(Path(proof['baseline_seed05_fit_report_path'])),actual_fit_report_sha256=sha(report),
        combined_native_output_sha256=sha(stage/'fullflow.log'),
        generic171167_or176250_not_rejection_by_ID_alone=True,
        backend_effort_use='NOT_SEPARATELY_OBSERVABLE; input acceptance is not backend-use or efficacy proof',
        efficacy='Must be assessed from actual all8 results versus original seed5; no promised repair.')

def timing_and_targets(stage):
    checks=module(BASE/'checks.py','seed05_timing');q=checks.timing(stage,load(PARENT/'coverage-reference.json'))
    reports=stage/'reports';target=checks.rows(reports/'row-predecessor-check-coverage.tsv')
    assert len(target)==16 and {(int(r['corner']),r['check']) for r in target}=={(i,k) for i in range(1,9) for k in ('setup','hold')}
    for r in target:
        assert r['source_expression']=='ascal|o_vacpt_minus1*' and r['destination_expression']=='ascal|o_adrs_pre*'
        assert int(r['source_count'])>0 and int(r['destination_count'])>0 and r['returned_path_count']=='1'
        assert math.isfinite(float(r['worst_slack_ns'])) and r['classification']=='PATH_FOUND_REQUIRES_TIMING_REVIEW'
        assert r['report_file']==f"corner-{int(r['corner']):02d}-row-predecessor-{r['check']}.rpt"
    # Existing APIs write slack directly. Existing Python clean check did not inspect
    # report_timing's violation count; retain it so rounded0.000 cannot imply pass.
    diagnostics={};all_native_nonviolating=True
    groups=[(r,f"corner-{int(r['corner']):02d}-{r['check']}.rpt") for r in checks.rows(reports/'global-check-coverage.tsv')]
    groups += [(r,r['report_file']) for r in checks.rows(reports/'old-mode-check-coverage.tsv')+target]
    for r,name in groups:
        text=(reports/name).read_text(encoding='latin-1');d=native_summary(text)
        assert d['check']==r['check'] and abs(d['display_slack_ns']-float(r['worst_slack_ns']))<=0.00051
        diagnostics[name]=dict(**d,sha256=sha(reports/name));all_native_nonviolating &= d['violated']==0
        if 'row-predecessor' in name:
            for field,expression in (('From Node','o_vacpt_minus1'),('To Node','o_adrs_pre')):
                node=re.search(r'(?m)^;\s*'+field+r'\s*;\s*([^;\r\n]+)',text)
                assert node and expression in node[1],'Actual predecessor endpoint differs'
    for row in q['timing_condition_matrix']:
        co=row['native_corner']
        for k,v in row['checks'].items():
            d=diagnostics[f'corner-{co:02d}-{k}.rpt'];v['native_report_violated_paths']=d['violated'];v['pass'] &= d['violated']==0
        pw=row['minimum_pulse_width'];row['status']='PASS' if all(v['pass'] for v in row['checks'].values()) and pw['slack_ns']>=0 and pw['violated']==0 else 'FAIL'
    q['qualified_clean_candidate'] &= all_native_nonviolating and all(float(r['worst_slack_ns'])>=0 for r in target)
    q['row_predecessor_coverage']=dict(rows=target,all16_target_paths_present=True,no_empty_path_is_a_pass=True)
    q['native_timing_summary_diagnostics']=diagnostics;q['zero_display_with_native_violation_never_passes']=True
    return q

def run():
    m=validate();launch=load(BASE/'launch-admission.json');frozen_review(launch['review_path'],launch['review_sha256'])
    action=load(BASE/'scheduler-action-start.json');assert action['pid']==os.getppid() and action['parent_name'].lower() in ('svchost.exe','taskeng.exe')
    assert not (BASE/'stages').exists() and not (BASE/'experiment-result.json').exists(),'No automatic retry/resume'
    original=load(BASE/'parent-files.json');no_overlap();check_snapshot(PARENT/'stages/full/tree',original)
    checks=module(BASE/'checks.py','seed05_checks');parser=module(Path(load(BASE/'provenance.json')['fit_parser_path']),'seed05_fit_parser')
    summary=dict(state='RUNNING',source_commit=SOURCE,variant_exact_sha256=VARIANT,seed=SEED,BUILD_DATE='261025',
        root_admission_sha256=m['root_admission_sha256'],timing_acceptance=False,hardware_acceptance=False,task_cleanup_pending=True)
    code=1
    try:
        fit=BASE/'stages/fit';asm=BASE/'stages/asm';sta=BASE/'stages/sta'
        copy_checkpoint(PARENT/'stages/full/tree',fit/'tree',original)
        qsf=fit/'tree/STV_DS.qsf';raw=qsf.read_bytes();needle=b'set_global_assignment -name SEED 4\r\n'
        assert raw.count(needle)==1
        pre=raw.replace(needle,b'set_global_assignment -name SEED 5\r\n',1)
        assert hashlib.sha256(pre).hexdigest()==BASELINE_QSF5 and pre.endswith(b'\r\n') and b'TDC_AGGRESSIVE_HOLD_CLOSURE_EFFORT' not in pre
        qsf.write_bytes(pre+HOLD_LINE)
        assert sha(qsf)==m['seed_start_QSF_sha256']
        start=snapshot(fit/'tree');assert set(start)==set(original) and {n for n in start if start[n]!=original[n]}=={'STV_DS.qsf'}
        save(fit/'seed-start-files.json',start);guarded(fit,'fit',m);fit_end=snapshot(fit/'tree')
        protected=set().union(*(set(m['roles'][k]) for k in ('source_names','generated_names','map_database_names')))
        assert all(fit_end[n]==start[n] for n in protected)
        fq=checks.fit(fit,SEED,parser);fq['experimental_setting_acceptance']=setting_acceptance(fit)
        fq['passed'] &= fq['experimental_setting_acceptance']['accepted_input_no_rejection_observed']
        save(fit/'qualification.json',fq)
        assert fq['passed'],'Native fitter mechanism or requested setting acceptance failed; not timing failure'
        check_snapshot(PARENT/'stages/full/tree',original);save(fit/'checkpoint.json',fit_end)
        copy_checkpoint(fit/'tree',asm/'tree',fit_end);pre=checks.output_stats(asm/'tree')
        ar=guarded(asm,'asm',m);asm_end=snapshot(asm/'tree');immutable=protected|{PRIMARY}
        assert all(asm_end[n]==fit_end[n] for n in immutable)
        aq=checks.assembly(asm,SEED,ar,pre,fit_end);assert aq['passed'],'Fresh standalone ASM qualification failed'
        check_snapshot(fit/'tree',fit_end);save(asm/'checkpoint.json',asm_end);save(asm/'qualification.json',aq)
        copy_checkpoint(asm/'tree',sta/'tree',asm_end);(sta/'reports').mkdir();guarded(sta,'sta',m)
        after=snapshot(sta/'tree');assert all(after[n]==asm_end[n] for n in immutable|set(BINARIES))
        check_snapshot(fit/'tree',fit_end);check_snapshot(asm/'tree',asm_end);check_snapshot(PARENT/'stages/full/tree',original)
        sq=timing_and_targets(sta);save(sta/'qualification.json',sq)
        summary.update(state='COMPLETED_MEASUREMENT_REQUIRES_ROOT_REVIEW',fit_qualification=fq,assembly_qualification=aq,**sq,
            RBF=aq['outputs'][BINARIES[0]],SOF=aq['outputs'][BINARIES[1]])
        code=0
    except Exception as error:summary.update(state='STOPPED_INFRASTRUCTURE_OR_INTEGRITY_REQUIRES_ROOT_REVIEW',error=repr(error),resource_stop_is_inconclusive_not_timing_failure=True)
    finally:
        try:
            no_overlap()
            for p in (BASE/'stages').glob('*/result.json'):
                r=load(p)
                if r.get('state')=='deferred-before-launch' and r.get('no_child_launched') is True:continue
                assert r['state']=='terminal' and r['all_job_processes_terminal'] and r['all_handles_closed'] and r['final_job_active_processes']==0
            check_snapshot(PARENT/'stages/full/tree',original)
            save(BASE/'preservation-index.json',dict(members=snapshot(BASE/'stages'),source_commit=SOURCE,seed=SEED,
                root_admission_sha256=m['root_admission_sha256'],limits=LIMITS,tool_bindings=m['tool_bindings'],
                completed_native_sequence=code==0,manual_root_review=False,identical_rebuild_unproven=True))
            summary['preservation_index_sha256']=sha(BASE/'preservation-index.json')
        except Exception as error:summary['preservation_pending_safe_terminal_proof']=repr(error);code=1
        summary.update(exit_code=code,ended_utc=stamp());save(BASE/'experiment-result.json',summary)
    return code

def main():
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group();g.add_argument('--freeze');g.add_argument('--run',action='store_true');p.add_argument('--admission-sha256');a=p.parse_args()
    assert Path(sys.executable).resolve()==PYTHON.resolve()
    if a.freeze:print(json.dumps(freeze(a.freeze,a.admission_sha256),indent=2));return 0
    if a.run:return run()
    template_pins();print(json.dumps(dict(state='UNFROZEN_TEMPLATE_ONLY_NO_PARENT_DB_READ_COPY_FREEZE_TASK_OR_NATIVE',source_commit=SOURCE,
        seed=SEED,BUILD_DATE='261025',limits=LIMITS,template_pins_sha256=sha(BASE/'template-pins.json')),indent=2));return 0

if __name__=='__main__':raise SystemExit(main())
