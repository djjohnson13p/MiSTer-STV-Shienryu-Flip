"""Root actual-member and native-result audit for a closed STA-only diagnostic."""
import datetime, importlib.util, json, sys
from pathlib import Path
B=Path(__file__).resolve().parent
version=sys.argv[1];assert version in ('r2','r3')
D=B/('row-predecessor-seed05-hold-budget-diagnostic-'+version)
spec=importlib.util.spec_from_file_location('terminal_budget_audit',D/'diagnostic.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.validate();m.no_overlap()
index=m.load(D/'preservation-index.json'); actual=m.snapshot(D/'stages')
assert actual==index['members']
m.check_snapshot(m.PARENT/'stages/asm/tree',m.load(D/'parent-files.json'))
native=m.terminal(D/'stages/sta');c=m.load(D/'terminal-task-cleanup.json')
assert c['exact_task_unregistered'] and c['errors']==[]
r=m.load(D/'experiment-result.json');parent=m.load(m.PARENT/'experiment-result.json')
def timing_values(rows):
 return [(x['model'],x['temperature_C'],x['status'],x['checks'],{k:v for k,v in x['minimum_pulse_width'].items() if k!='sha256'}) for x in rows]
assert timing_values(r['timing_condition_matrix'])==timing_values(parent['timing_condition_matrix'])
budget=m.budget_coverage(D/'stages/sta')
assert budget==r['budget']
out=B/('ROOT-SEED05-HOLD-BUDGET-'+version.upper()+'-TERMINAL-REVIEW.json')
receipt=dict(reviewer='root',utc=m.stamp(),operation='STA_ONLY_HOLD_BUDGET',
 state='NATIVE_TERMINAL_MEMBERS_AND_REPORTS_VERIFIED',diagnostic_complete=r['diagnostic_complete'],
 result_sha256=m.sha(D/'experiment-result.json'),seal_sha256=m.sha(D/'preservation-index.json'),
 cleanup_sha256=m.sha(D/'terminal-task-cleanup.json'),frozen_pins_sha256=m.sha(D/'frozen-pins.json'),
 actual_stage_members_verified=len(actual),actual_stage_bytes=sum(x['bytes'] for x in actual.values()),
 immutable_parent1051_verified=True,native_only_STA=r['native_modules']==['Timing Analyzer'],
 native_elapsed_seconds=native['elapsed_seconds'],native_exit_code=native['flow_exit_code'],
 global_all8_numeric_matrix_equals_parent=True,target_rows=budget['actual_rows'],
 unresolved_rows=len(budget['unresolved_rows']),native_target_reports_reparsed=len(budget['native_report_diagnostics']),
 qualified_clean_candidate=False,followup_fitter_requires_joint_decision=True,
 no_new_RTL_clock_constraint_seed_or_bitstream=True)
m.save(out,receipt)
print(json.dumps(dict(receipt=str(out),sha256=m.sha(out),members=len(actual),diagnostic_complete=r['diagnostic_complete'],unresolved=receipt['unresolved_rows'])))
