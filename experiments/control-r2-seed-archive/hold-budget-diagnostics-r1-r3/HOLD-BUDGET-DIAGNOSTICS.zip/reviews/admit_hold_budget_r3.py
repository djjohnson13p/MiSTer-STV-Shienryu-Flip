"""Root admission of the minimal default-mode name lookup; no native job start."""
import datetime, importlib.util, json
from pathlib import Path
B=Path(__file__).resolve().parent
A=B/'row-predecessor-seed05-hold-budget-diagnostic-r2'
D=B/'row-predecessor-seed05-hold-budget-diagnostic-r3'
spec=importlib.util.spec_from_file_location('root_budget_r3',D/'diagnostic.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.template_pins();m.no_overlap()
assert m.sha(D/'template-pins.json')=='a749caf44563edbcc7e64e5fe8351ee3e51ecbe5e4cb5dfbde15c113f5b20cc9'
assert (D/'diagnostic.py').read_text()==(A/'diagnostic.py').read_text().replace("TASK='CoreLab-Shienryu-Seed05-HoldBudget-STA-Q251-R2'","TASK='CoreLab-Shienryu-Seed05-HoldBudget-STA-Q251-R3'")
for n in ('checks.py','launch_task.py','quartus_job_guard.py'):assert (A/n).read_bytes()==(D/n).read_bytes()
old='''                use_timequest_style_escaping -off
                set status [catch {get_keepers -no_duplicates -nowarn [list [escape_brackets $key]]} collection options]
                use_timequest_style_escaping -on
                if {$status} {return -options $options $collection}'''
new='                set collection [get_keepers -no_duplicates -nowarn [list $key]]'
tcl=(D/'sta_all_corners.tcl').read_text()
assert tcl==(A/'sta_all_corners.tcl').read_text().replace(old,new)
assert 'use_timequest_style_escaping' not in tcl and 'escape_brackets' not in tcl
assert m.sha(D/'sta_all_corners.tcl')=='f92b7b191206cdf412142a5155a24f8ca81d45c2ea85af0899f301856a9e408a'
for n,h in m.load(A/'frozen-pins.json').items():assert m.sha(A/n)==h
assert m.load(A/'terminal-task-cleanup.json')['exact_task_unregistered']
a=m.load(A/'ROOT-DRAFT-ADMISSION.json')
for k in ('independent_template_review_path','independent_template_review_sha256'):
 if k in a:a['prior_'+k]=a.pop(k)
a.update(utc=m.stamp(),template_pins_sha256=m.sha(D/'template-pins.json'),
 prior_inconclusive_diagnostic_sha256=m.sha(A/'experiment-result.json'),
 reporting_correction='Direct get_keepers collection with default natural numeric bus naming; no text-mode change or manual escaping; original ID/name and size1 guards unchanged.',
 independent_current_diff_review='Agent shienryu_source_review reviewed only exact R2-to-R3 delta and final pins; native qualification pending.',
 root_complete_actual_Tcl_diff_reviewed=True,root_exact_controller_task_only_change_verified=True)
for p,h in a['tool_bindings'].items():assert m.sha(Path(p))==h
p=D/'ROOT-DRAFT-ADMISSION.json';m.save(p,a)
frozen=m.freeze(str(p.resolve()),m.sha(p))
for n,h in m.load(D/'frozen-pins.json').items():assert m.sha(D/n)==h
resources=m.resources();assert resources['admission_pass']
r=m.load(A/'ROOT-FROZEN-LAUNCH-ADMISSION.json')
if 'independent_template_review_sha256' in r:r['prior_independent_template_review_sha256']=r.pop('independent_template_review_sha256')
r.update(utc=m.stamp(),task=m.TASK,frozen_pins_sha256=m.sha(D/'frozen-pins.json'),
 template_pins_sha256=m.sha(D/'template-pins.json'),root_draft_admission_sha256=m.sha(p),resources=resources,
 root_actual_frozen_external_tools_rehashed={'frozen':len(m.load(D/'frozen-pins.json')),'external':len(m.load(D/'provenance.json')['external_bound_files']),'tools':len(a['tool_bindings'])},
 independent_current_diff_review=a['independent_current_diff_review'])
q=D/'ROOT-FROZEN-LAUNCH-ADMISSION.json';m.save(q,r)
print(json.dumps({'state':frozen['state'],'review':str(q),'sha256':m.sha(q),'frozen_pins':m.sha(D/'frozen-pins.json'),'resources':resources}))
