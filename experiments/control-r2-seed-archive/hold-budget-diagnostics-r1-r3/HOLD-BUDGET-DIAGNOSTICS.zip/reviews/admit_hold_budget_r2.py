"""Root's reviewed R1-to-R2 reporting-only admission; never starts a native job."""
import datetime, hashlib, importlib.util, json, sys
from pathlib import Path
B=Path(__file__).resolve().parent
A=B/'row-predecessor-seed05-hold-budget-diagnostic-r1'
D=B/'row-predecessor-seed05-hold-budget-diagnostic-r2'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
peer=Path(sys.argv[1]).resolve(); assert peer.is_file()
spec=importlib.util.spec_from_file_location('root_hold_budget_r2',D/'diagnostic.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.template_pins();m.no_overlap()
assert sha(D/'template-pins.json')=='dc0c8aeab56cacaaee42276e598359305acaf8474ced50f7c6c3296352a09b36'
expected=(A/'diagnostic.py').read_text().replace("TASK='CoreLab-Shienryu-Seed05-HoldBudget-STA-Q251-R1'","TASK='CoreLab-Shienryu-Seed05-HoldBudget-STA-Q251-R2'").replace('SINGLETON_OBJECT_UNRESOLVED_REQUIRES_REVIEW','SINGLETON_COLLECTION_IDENTITY_UNRESOLVED_REQUIRES_REVIEW')
assert (D/'diagnostic.py').read_text()==expected
for n in ('checks.py','quartus_job_guard.py','launch_task.py'):assert (D/n).read_bytes()==(A/n).read_bytes()
for n,h in load(A/'frozen-pins.json').items():assert sha(A/n)==h
assert sha(D/'proposed/hold_budget.tcl')=='57202d38e2abd29dd4404569a9cb9ec7751c9abb49d516d469949b0bdd7e4c13'
assert load(A/'terminal-task-cleanup.json')['exact_task_unregistered']
a=load(A/'ROOT-DRAFT-ADMISSION.json')
a.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 template_pins_sha256=sha(D/'template-pins.json'),
 independent_template_review_path=str(peer),independent_template_review_sha256=sha(peer),
 prior_inconclusive_diagnostic_sha256=sha(A/'experiment-result.json'),
 reporting_correction='Real singleton collection; bracket escaping mode restored On immediately; exact original ID/name check.',
 root_complete_actual_Tcl_diff_reviewed=True,root_exact_controller_two_literal_changes_verified=True,
 root_prior_frozen_inputs_untouched=True,user_authorization='Complete selected Option1 diagnostic; reporting correction only, no fitter.')
for p,h in a['tool_bindings'].items():assert sha(Path(p))==h
p=D/'ROOT-DRAFT-ADMISSION.json';m.save(p,a)
frozen=m.freeze(str(p.resolve()),sha(p))
for n,h in load(D/'frozen-pins.json').items():assert sha(D/n)==h
resources=m.resources();assert resources['admission_pass']
r=load(A/'ROOT-FROZEN-LAUNCH-ADMISSION.json')
r.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),task=m.TASK,
 frozen_pins_sha256=sha(D/'frozen-pins.json'),template_pins_sha256=sha(D/'template-pins.json'),
 root_draft_admission_sha256=sha(p),independent_template_review_sha256=sha(peer),resources=resources,
 user_authorization='Complete selected Option1 saved-fit analysis; same design, reporting correction only.')
r.pop('root_actual14frozen20external2tool_rehash',None)
r['root_actual_frozen_external_tools_rehashed']={'frozen':len(load(D/'frozen-pins.json')),'external':len(load(D/'provenance.json')['external_bound_files']),'tools':len(a['tool_bindings'])}
q=D/'ROOT-FROZEN-LAUNCH-ADMISSION.json';m.save(q,r)
print(json.dumps({'state':frozen['state'],'review':str(q),'sha256':sha(q),'frozen_pins':sha(D/'frozen-pins.json'),'resources':resources}))
