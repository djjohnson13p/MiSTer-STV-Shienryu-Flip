"""Package closed STA analysis evidence; reuse the separately preserved parent fit."""
import hashlib,json,zipfile
from pathlib import Path
B=Path(__file__).resolve().parent
LEAF=B.parents[1]/'cores/Shienryu_B75_Preservation/experiments/control-r2-seed-archive/hold-budget-diagnostics-r1-r3'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(data):return hashlib.sha256(data).hexdigest()
payload={};trials={}
for version in ('r1','r2','r3'):
 d=B/('row-predecessor-seed05-hold-budget-diagnostic-'+version)
 r=load(d/'experiment-result.json');c=load(d/'terminal-task-cleanup.json');native=load(d/'stages/sta/result.json')
 assert c['exact_task_unregistered'] and c['errors']==[]
 assert native['all_job_processes_terminal'] and native['all_handles_closed'] and native['final_job_active_processes']==0
 assert native['flow_exit_code']==0 and r['exit_code']==0
 report_count=0
 for p in sorted(d.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(d).as_posix()
  if rel.startswith('stages/sta/tree/') or '__pycache__' in p.parts:continue
  assert not p.is_symlink()
  payload[version+'/'+rel]=p.read_bytes()
  if rel.startswith('stages/sta/reports/') and p.suffix=='.rpt':report_count+=1
 trials[version]=dict(diagnostic_complete=r['diagnostic_complete'],native_elapsed_seconds=native['elapsed_seconds'],
  report_count=report_count,result_sha256=digest((d/'experiment-result.json').read_bytes()),
  derived_working_tree_excluded=True,working_cache_changed=r['working_cache_changed'],working_cache_added=r['working_cache_added'])
extras=[
 'ROOT-SEED05-HOLD-BUDGET-R1-TERMINAL-REVIEW.json','ROOT-SEED05-HOLD-BUDGET-R2-TERMINAL-REVIEW.json',
 'ROOT-SEED05-HOLD-BUDGET-R3-TERMINAL-REVIEW.json','INDEPENDENT-SEED05-HOLD-BUDGET-TERMINAL-REVIEW.json',
 'INDEPENDENT-SEED05-HOLD-BUDGET-ADAPTER-REVIEW.json','INDEPENDENT-SEED05-HOLD-BUDGET-R2-ADAPTER-REVIEW.json',
 'INDEPENDENT-SEED05-HOLD-BUDGET-R3-BUDGET-REVIEW.json','SHIENRYU-HOLD-BUDGET-DISCUSSION.md',
 'GITHUB-ROW-PREDECESSOR-SEED05-NATIVE-PRESERVATION.json',
 'review_hold_budget_r1.py','review_hold_budget_terminal.py','admit_hold_budget_r2.py','admit_hold_budget_r3.py',
 'write_hold_budget_discussion.py','pack_hold_budget_diagnostics.py']
for n in extras:payload['reviews/'+n]=(B/n).read_bytes()
members={n:dict(bytes=len(data),sha256=digest(data)) for n,data in sorted(payload.items())}
metadata=dict(operation='STA_ONLY_HOLD_BUDGET',source_commit='6eb9367e2d64c18b0b109d221a0bc07d35d493b4',seed=5,
 parent_archive_commit='269b33b22ff31de4e54421130bf6dac278e5de7d',
 parent_archive_leaf='experiments/control-r2-seed-archive/row-predecessor-native-seed05-r1',
 no_new_source_seed_fitter_ASM_or_bitstream=True,trials=trials,members=members,
 exclusions='The three copied working trees and their redundant derived timing caches remain local. The exact1051-file parent ASM/source/map/fit/RBF/SOF is already remotely preserved by the referenced archive. This analysis ZIP preserves every actual report and the complete stage-member indexes, not three independent fitted-tree backups.',
 reproducibility_limit='Exact archived binaries/checkpoints can be restored; relocated native DB reuse and bit-identical fresh recompilation are not claimed.')
assert not LEAF.exists(),'Never overwrite an occupied evidence package'
LEAF.mkdir(parents=True)
(LEAF/'.gitattributes').write_text('* -text\n',encoding='utf-8')
(LEAF/'PACKAGE-INDEX.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
archive=LEAF/'HOLD-BUDGET-DIAGNOSTICS.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,data in sorted(payload.items()):z.writestr(n,data)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(members)
 for n,row in members.items():
  data=z.read(n);assert len(data)==row['bytes'] and digest(data)==row['sha256']
assert archive.stat().st_size<90*1024**2
sha=digest(archive.read_bytes())
(LEAF/'SHA256SUMS').write_text(sha+'  '+archive.name+'\n',encoding='utf-8')
print(json.dumps({'leaf':str(LEAF),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'members':len(members),'trials':trials}))
