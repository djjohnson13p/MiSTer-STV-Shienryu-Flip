"""Root read-only terminal audit; writes only a new review receipt."""
import datetime, hashlib, importlib.util, json
from pathlib import Path
BASE = Path(__file__).resolve().parent
D = BASE / 'row-predecessor-seed05-hold-budget-diagnostic-r1'
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
spec = importlib.util.spec_from_file_location('diagnostic_review',D/'diagnostic.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
m.validate(); m.no_overlap()
index=load(D/'preservation-index.json')
actual=m.snapshot(D/'stages')
assert actual==index['members']
m.check_snapshot(m.PARENT/'stages/asm/tree',load(D/'parent-files.json'))
r=load(D/'experiment-result.json'); native=m.terminal(D/'stages/sta')
c=load(D/'terminal-task-cleanup.json')
assert c['exact_task_unregistered'] and c['errors']==[]
assert r['diagnostic_complete'] is False and len(r['budget']['rows'])==144
assert {x['classification'] for x in r['budget']['rows']}=={'SINGLETON_OBJECT_UNRESOLVED_REQUIRES_REVIEW'}
assert all(x['worst_slack_ns']=='NA' for x in r['budget']['rows'])
parent=load(m.PARENT/'experiment-result.json')
def timing_values(rows):
    return [(x['model'],x['temperature_C'],x['status'],x['checks'],
             {k:v for k,v in x['minimum_pulse_width'].items() if k!='sha256'}) for x in rows]
assert timing_values(r['timing_condition_matrix'])==timing_values(parent['timing_condition_matrix'])
receipt=dict(reviewer='root',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 state='NATIVE_COMPLETED_CLEANUP_VERIFIED_TARGET_BUDGET_INCONCLUSIVE',
 actual_stage_members_verified=len(actual),actual_stage_bytes=sum(x['bytes'] for x in actual.values()),
 frozen_external_tools_and_parent1051_verified=True,native_only_STA=True,
 native_elapsed_seconds=native['elapsed_seconds'],native_exit_code=native['flow_exit_code'],
 actual_matrix_unchanged=True,budget_rows_unresolved=144,no_numeric_budget_claim=True,
 result_sha256=sha(D/'experiment-result.json'),seal_sha256=sha(D/'preservation-index.json'),
 cleanup_sha256=sha(D/'terminal-task-cleanup.json'),originals_and_core_artifacts_untouched=True,
 reporting_defect='foreach_in_collection returns node IDs; get_collection_size does not accept such an individual ID as a collection.',
 action='Correct reporting-only singleton collection construction in separate r2; retain r1. No fitter/RTL/clock/constraint/newbitstream is authorized.')
out=BASE/'ROOT-SEED05-HOLD-BUDGET-R1-TERMINAL-REVIEW.json'
with out.open('x',encoding='utf-8') as f: json.dump(receipt,f,indent=2); f.write('\n')
print(json.dumps({'receipt':str(out),'sha256':sha(out),'members':len(actual),'budget':'INCONCLUSIVE'}))
