"""Write the joint-decision brief from closed, reviewed native measurements."""
import json
from pathlib import Path
B=Path(__file__).resolve().parent
D=B/'row-predecessor-seed05-hold-budget-diagnostic-r3'
r=json.loads((D/'experiment-result.json').read_text());assert r['diagnostic_complete']
rows=r['budget']['rows'];assert len(rows)==144
lines=['# Shienryu: measured hold-repair feasibility','',
'The saved source6eb/seed5 layout has enough measured setup headroom to justify one targeted hold-repair experiment. No new synthesis, fit, assembly, seed, source, clock, constraint or bitstream was created by this diagnostic. Baseline7e9/seed4 remains the preferred installed core, with the user’s physical audio/video/flip confirmation.','',
'The five failing paths need at most0.723ns additional minimum delay. Across all valid launches into the four affected destination registers, the smallest setup margin is2.793ns. The failing source-to-destination pairs themselves have at least6.367ns setup margin. All72 hold-query rows fit within the corresponding scalar destination setup headroom. These are useful feasibility bounds, not guaranteed inserted-route budgets: minimum/maximum delay models, clock skew, shared fanout and placement can change together.','',
'## Every analyzed condition','',
'All1.1V; slack in ns. These global timing results exactly match the existing seed5 fit, not a new improved core. Recovery, removal and minimum pulse width pass all8; every condition still fails hold.','',
'| Model | C | Global setup | Setup | Global hold | Hold | Least setup margin into affected destinations | Largest required hold delay |',
'|---|---:|---:|---|---:|---|---:|---:|']
for c in r['timing_condition_matrix']:
 a=[x for x in rows if x['corner']==str(c['native_corner'])]
 margin=min(float(x['worst_slack_ns']) for x in a if x['query_kind']=='destination' and x['check']=='setup')
 need=max(float(x['hold_delay_requirement_ns']) for x in a if x['check']=='hold')
 s=c['checks']['setup'];h=c['checks']['hold']
 lines.append(f"| {c['model']} | {c['temperature_C']} | {s['slack_ns']:+.3f} | {'Pass' if s['pass'] else 'FAIL'} | {h['slack_ns']:+.3f} | {'Pass' if h['pass'] else 'FAIL'} | {margin:.3f} | {need:.3f} |")
lines+=['','## Affected destinations across all8','',
'| Destination | Smallest setup margin, all launches | Largest hold delay needed |',
'|---|---:|---:|']
for i in range(1,5):
 a=[x for x in rows if x['query_kind']=='destination' and x['target_id']==f'D{i}']
 s=min(float(x['worst_slack_ns']) for x in a if x['check']=='setup')
 h=max(float(x['hold_delay_requirement_ns']) for x in a if x['check']=='hold')
 lines.append(f"| {a[0]['destination_requested']} | {s:.3f}ns | {h:.3f}ns |")
lines+=['','## Proposed next decision','',
'Recommend one controlled hold-repair trial using the same source and seed5, enabling TDC_AGGRESSIVE_HOLD_CLOSURE_EFFORT ON. Ordinary AllPaths hold repair, multi-corner optimization and MAXIMUM routing effort are already enabled. The installed25.1 Standard/Lite metadata recognizes this additional option; actual CycloneV fitter use/effect has not been demonstrated. Verify native acceptance/use before attributing any improvement to it. If ignored/unsupported or hold does not improve without unacceptable setup regressions, stop this approach and keep accepted baseline4. Do not resume a seed sweep.','',
'Full eight-condition closure also requires resolving the separate -0.017ns Slow-40C ascal vertical-counter feedback setup path. That is not one of these five hold paths and this analysis does not prove it repaired. The user excludes freezing conditions from intended operation; disclose the residual and judge any improved candidate honestly as experimental.','',
'No later fitter/RTL/seed action is authorized by selecting this diagnostic. Present this concrete proposal for the joint next-step decision first. Preserve the original and baseline4 unchanged. No Shienryu PR, release or author contact is authorized.','',
'## Evidence and qualifications','',
'R3 completed native0 in391.062s; all144 target reports have unique literal endpoint matches, finite paths and native arrival/required/slack arithmetic checks. Root rehashed all1335 actual stage members (598323147B), verified the immutable1051-file parent and unchanged global all8 numeric values. Exact task removed after Ready/exit0/native handles closed.','',
'R1 andR2 are preserved inconclusive reporting attempts: R1 used a node ID as a collection; R2 tried to change escaping mode after loading a netlist. Neither established a target budget. R3 uses a genuine collection under unchanged default natural bus naming and verifies exact original node ID/name.','',
'Raw144 reports, coverage TSV and complete stage-member hashes accompany the archive. The copied source/map/fit/programming parent is already recoverable from lab archive commit269b33b22ff31de4e54421130bf6dac278e5de7d. Redundant per-analysis working timing caches remain local, explicitly excluded from this small analysis ZIP. No bit-identical fresh recompilation or relocated native DB usability claim is made.','']
p=B/'SHIENRYU-HOLD-BUDGET-DISCUSSION.md'
with p.open('x',encoding='utf-8') as f:f.write('\n'.join(lines))
print(p)
