# Saved fitted database only. No map/fit/assembly, assignment export or SDC edit.
set out [file normalize [file join [file dirname [info script]] reports]]
if {![file isdirectory $out]} {error "Prepared report directory is missing"}
set inventory ""
set coverage ""
set global_summary ""
set mode_coverage ""
set row_coverage ""
set opened 0
set netlist 0
set failed [catch {
    project_open STV_DS -revision STV_DS
    set opened 1
    create_timing_netlist
    set netlist 1
    read_sdc
    update_timing_netlist
    set conditions [get_available_operating_conditions -all]
    set condition_count [get_collection_size $conditions]
    if {$condition_count < 2} {error "All available corner coverage is not established"}
    set inventory [open [file join $out corner-inventory.tsv] {WRONLY CREAT EXCL}]
    puts $inventory "index\toperating_condition\tmodel\tgrade\tspeed\ttemperature_C\tvoltage_mV\tclock_count"
    set coverage [open [file join $out clock-check-coverage.tsv] {WRONLY CREAT EXCL}]
    puts $coverage "corner\tclock\tclock_object\tperiod_ns\tpositive_registers\tnegative_registers\tcheck\treturned_path_count\tworst_slack_ns\tclassification"
    set global_summary [open [file join $out global-check-coverage.tsv] {WRONLY CREAT EXCL}]
    puts $global_summary "corner\tcheck\treturned_path_count\tworst_slack_ns\tclassification"
    # OLD_MODE_DIAGNOSTICS_OPEN_BEGIN
    set mode_coverage [open [file join $out old-mode-check-coverage.tsv] {WRONLY CREAT EXCL}]
    puts $mode_coverage "corner\tsource_expression\tcollection_variant\tkeepers_count\tregisters_count\tcheck\treturned_path_count\tworst_slack_ns\tclassification\treport_file"
    set row_coverage [open [file join $out row-predecessor-check-coverage.tsv] {WRONLY CREAT EXCL}]
    puts $row_coverage "corner\tsource_expression\tdestination_expression\tsource_count\tdestination_count\tcheck\treturned_path_count\tworst_slack_ns\tclassification\treport_file"
    # OLD_MODE_DIAGNOSTICS_OPEN_END
    set index 0
    set expected_clocks -1
    foreach_in_collection condition $conditions {
        incr index
        set_operating_conditions $condition
        update_timing_netlist
        set current [get_operating_conditions]
        set label [get_operating_conditions_info -display_name $current]
        set model [get_operating_conditions_info -model $current]
        set grade [get_operating_conditions_info -grade $current]
        set speed [get_operating_conditions_info -speed $current]
        set temperature [get_operating_conditions_info -temperature $current]
        set voltage [get_operating_conditions_info -voltage $current]
        set clocks [get_clocks]
        set clock_count [get_collection_size $clocks]
        if {$clock_count < 1} {error "No actual clocks at $label"}
        if {$expected_clocks < 0} {set expected_clocks $clock_count}
        if {$clock_count != $expected_clocks} {error "Clock inventory changed across operating conditions"}
        puts $inventory "$index\t$label\t$model\t$grade\t$speed\t$temperature\t$voltage\t$clock_count"
        flush $inventory
        set prefix [file join $out [format "corner-%02d" $index]]
        report_clocks -file ${prefix}-constraints.rpt
        foreach kind {setup hold recovery removal} {
            report_clock_transfers -$kind -append -file ${prefix}-constraints.rpt
        }
        report_sdc -append -file ${prefix}-constraints.rpt
        report_sdc -ignored -append -file ${prefix}-constraints.rpt
        check_timing -append -file ${prefix}-constraints.rpt
        report_ucp -append -file ${prefix}-constraints.rpt
        report_clock_fmax_summary -file ${prefix}-fmax.rpt
        foreach kind {setup hold recovery removal} {
            report_timing -$kind -npaths 50 -detail full_path -file ${prefix}-${kind}.rpt
            set global_paths [get_timing_paths -$kind -npaths 1]
            set global_count [get_collection_size $global_paths]
            set global_slack NA
            set global_class NO_PATHS_REQUIRES_REVIEW
            foreach_in_collection path $global_paths {
                set global_slack [get_path_info -slack $path]
                set global_class PATH_FOUND_REQUIRES_TIMING_REVIEW
            }
            puts $global_summary "$index\t$kind\t$global_count\t$global_slack\t$global_class"
            set clocks_with_paths 0
            set clock_index 0
            foreach_in_collection clock $clocks {
                incr clock_index
                set name [get_clock_info -name $clock]
                set period [get_clock_info -period $clock]
                set positive [get_clock_info -nreg_pos $clock]
                set negative [get_clock_info -nreg_neg $clock]
                # Preserve the actual clock object. Never reinterpret names containing [] as globs.
                set paths [get_timing_paths -$kind -to_clock $clock -npaths 1]
                set count [get_collection_size $paths]
                set slack NA
                set classification NO_PATHS_REQUIRES_REVIEW
                foreach_in_collection path $paths {
                    set destination [get_path_info -to_clock $path]
                    if {$destination eq ""} {error "Clock-bound path has no destination clock: $name / $kind"}
                    set destination_name [get_clock_info -name $destination]
                    if {$destination_name ne $name} {error "Clock binding mismatch: expected $name, got $destination_name"}
                    set slack [get_path_info -slack $path]
                    set classification EXACT_CLOCK_PATH_REQUIRES_TIMING_REVIEW
                }
                if {$count > 0} {incr clocks_with_paths}
                puts $coverage "$index\t$name\t$clock\t$period\t$positive\t$negative\t$kind\t$count\t$slack\t$classification"
                if {$count > 0 && $slack < 0.0} {
                    # Clock object stays exact; only the numeric index enters the filename.
                    report_timing -$kind -to_clock $clock -npaths 1 -detail full_path -file [format "%s-%s-clock-%03d-negative.rpt" $prefix $kind $clock_index]
                }
            }
            if {$global_count > 0 && $clocks_with_paths == 0} {error "Global paths exist but all clock-bound queries are empty: $label / $kind"}
            flush $coverage
            flush $global_summary
        }
        report_min_pulse_width -nworst 50 -detail full_path -file ${prefix}-min-pulse-width.rpt
        # OLD_MODE_DIAGNOSTICS_BEGIN
        # Exact original sys_top.sdc source expression; default matching includes replicas.
        set mode_expression {ascal|o_flip_180}
        set mode_default_keepers [get_keepers $mode_expression]
        set mode_unique_keepers [get_keepers -no_duplicates $mode_expression]
        set mode_default_registers [get_registers $mode_expression]
        set mode_unique_registers [get_registers -no_duplicates $mode_expression]
        foreach {variant mode_keepers mode_registers} [list default $mode_default_keepers $mode_default_registers no_duplicates $mode_unique_keepers $mode_unique_registers] {
            set keeper_count [get_collection_size $mode_keepers]
            set register_count [get_collection_size $mode_registers]
            foreach kind {setup hold} {
                set mode_count 0
                set mode_slack NA
                set mode_class NO_MATCHING_KEEPERS_REQUIRES_REVIEW
                set mode_report NA
                # Never pass an empty collection to -from: it must not become all paths.
                if {$keeper_count > 0} {
                    set mode_paths [get_timing_paths -$kind -from $mode_keepers -npaths 1]
                    set mode_count [get_collection_size $mode_paths]
                    set mode_class NO_PATHS_REQUIRES_REVIEW
                    foreach_in_collection path $mode_paths {
                        set mode_slack [get_path_info -slack $path]
                        set mode_class PATH_FOUND_REQUIRES_TIMING_REVIEW
                    }
                    set mode_report [format "corner-%02d-old-mode-%s-%s.rpt" $index $variant $kind]
                    report_timing -$kind -from $mode_keepers -npaths 50 -detail full_path -file [file join $out $mode_report]
                }
                puts $mode_coverage "$index\t$mode_expression\t$variant\t$keeper_count\t$register_count\t$kind\t$mode_count\t$mode_slack\t$mode_class\t$mode_report"
            }
        }
        flush $mode_coverage
        # OLD_MODE_DIAGNOSTICS_END
        # Reporting only: the new registered predecessor into the existing row-product endpoint.
        set row_source_expression {ascal|o_vacpt_minus1*}
        set row_destination_expression {ascal|o_adrs_pre*}
        set row_sources [get_keepers $row_source_expression]
        set row_destinations [get_keepers $row_destination_expression]
        set row_source_count [get_collection_size $row_sources]
        set row_destination_count [get_collection_size $row_destinations]
        foreach kind {setup hold} {
            set row_count 0
            set row_slack NA
            set row_class NO_MATCHING_KEEPERS_REQUIRES_REVIEW
            set row_report NA
            if {$row_source_count > 0 && $row_destination_count > 0} {
                set row_paths [get_timing_paths -$kind -from $row_sources -to $row_destinations -npaths 1]
                set row_count [get_collection_size $row_paths]
                set row_class NO_PATHS_REQUIRES_REVIEW
                foreach_in_collection path $row_paths {
                    set row_slack [get_path_info -slack $path]
                    set row_class PATH_FOUND_REQUIRES_TIMING_REVIEW
                }
                set row_report [format "corner-%02d-row-predecessor-%s.rpt" $index $kind]
                report_timing -$kind -from $row_sources -to $row_destinations -npaths 50 -detail full_path -file [file join $out $row_report]
            }
            puts $row_coverage "$index\t$row_source_expression\t$row_destination_expression\t$row_source_count\t$row_destination_count\t$kind\t$row_count\t$row_slack\t$row_class\t$row_report"
        }
        flush $row_coverage
        # Reporting only; source after each condition's update_timing ($index,$out).
        if {![info exists hb_channel]} {
            proc hb_key {n} {regsub -all {(^|\|)[^|:]+:} $n {\1} n; return $n}
            proc hb_finite {x} {if {![string is double -strict $x] || [catch {expr {abs($x)<1.0e100}} ok] || !$ok} {error "Nonfinite budget value: $x"}; return $x}
            proc hb_singleton {node key} {
                use_timequest_style_escaping -off
                set status [catch {get_keepers -no_duplicates -nowarn [list [escape_brackets $key]]} collection options]
                use_timequest_style_escaping -on
                if {$status} {return -options $options $collection}
                if {[get_collection_size $collection]!=1} {error "Exact keeper collection is not singleton: $key"}
                foreach_in_collection selected $collection {
                    if {$selected ne $node || [hb_key [get_node_info -name $selected]] ne $key} {error "Exact keeper identity mismatch: $key"}
                }
                return $collection
            }
            set hb_channel [open [file join $out hold-budget.tsv] {WRONLY CREAT EXCL}]
            puts $hb_channel "corner\tquery_kind\ttarget_id\tsource_requested\tdestination_requested\tsource_matches\tdestination_matches\tcheck\treturned_path_count\tworst_slack_ns\tclassification\treport_file\tmatched_from\tmatched_to\tdestination_setup_headroom_ns\thold_delay_requirement_ns\tscalar_comparison"
            set hb_destinations [list {emu:emu|sdram1:sdram1|raddr23[1][15]} {emu:emu|sdram1:sdram1|raddr23[1][14]} {emu:emu|ddram:ddram|cart_rcache_addr[24]} {emu:emu|sdram1:sdram1|raddr23[1][8]}]
            set hb_sources [list {emu:emu|Saturn:saturn|VDP2:VDP2|VRAMB1_A[15]_OTERM1391} {emu:emu|Saturn:saturn|VDP2:VDP2|VRAMB1_A[14]_OTERM1417} {emu:emu|Saturn:saturn|STV_CART:cart|MEM_A[24]} {emu:emu|Saturn:saturn|VDP2:VDP2|VRAMB1_A[8]_OTERM1383} {emu:emu|Saturn:saturn|VDP2:VDP2|VRAMB1_A[14]_OTERM1419}]
        }
        # Never retain object IDs across a condition/netlist update.
        array unset hb_hits
        array set hb_hits {}
        foreach n [concat $hb_destinations $hb_sources] {set hb_hits([hb_key $n]) {}}
        foreach_in_collection n [get_keepers *] {
            set key [hb_key [get_node_info -name $n]]
            if {[info exists hb_hits($key)]} {lappend hb_hits($key) $n}
        }
        array unset hb_setup
        array set hb_setup {}
        set hb_queries {}
        for {set i 0} {$i<4} {incr i} {lappend hb_queries [list destination D[expr {$i+1}] {} [lindex $hb_destinations $i]]}
        for {set i 0} {$i<5} {incr i} {lappend hb_queries [list pair P[expr {$i+1}] [lindex $hb_sources $i] [lindex $hb_destinations [lindex {0 1 2 3 1} $i]]]}
        foreach query $hb_queries {
            lassign $query scope id wanted_from wanted_to
            set dk [hb_key $wanted_to]; set dc [llength $hb_hits($dk)]; set sc ALL_FROM
            if {$scope eq "pair"} {set sk [hb_key $wanted_from]; set sc [llength $hb_hits($sk)]}
            foreach kind {setup hold} {
                set count 0; set slack NA; set cls UNRESOLVED_COLLECTION_REQUIRES_REVIEW; set file NA
                set mf NA; set mt NA; set head NA; set need NA; set comparison NO_BUDGET
                if {$dc==1 && ($scope eq "destination" || $sc==1)} {
                    set dst_id [lindex $hb_hits($dk) 0]; set valid 1; set mf ALL_VALID_LAUNCHES; set mt [get_node_info -name $dst_id]
                    if {[catch {set dst [hb_singleton $dst_id $dk]} issue]} {set valid 0; puts stderr "Budget $id $kind destination unresolved: $issue"}
                    if {$scope eq "pair"} {
                        set src_id [lindex $hb_hits($sk) 0]; set mf [get_node_info -name $src_id]
                        if {[catch {set src [hb_singleton $src_id $sk]} issue]} {set valid 0; puts stderr "Budget $id $kind source unresolved: $issue"}
                    }
                    set cls SINGLETON_COLLECTION_IDENTITY_UNRESOLVED_REQUIRES_REVIEW
                    if {$valid} {
                        set args [list -$kind -to $dst -npaths 1]
                        if {$scope eq "pair"} {lappend args -from $src}
                        set paths [get_timing_paths {*}$args]; set count [get_collection_size $paths]; set cls NO_PATHS_REQUIRES_REVIEW
                        if {$count>1} {error "Budget npaths1 returned multiple paths"}
                        foreach_in_collection path $paths {
                            set slack [hb_finite [get_path_info -slack $path]]
                            set cls FINITE_SLACK_PATH_REQUIRES_NATIVE_REPORT_REVIEW
                            set file [format "corner-%02d-budget-%s-%s.rpt" $index $id $kind]
                            if {[file exists [file join $out $file]]} {error "Budget report already exists"}
                            report_timing {*}$args -detail full_path -file [file join $out $file]
                            if {$scope eq "destination" && $kind eq "setup"} {set hb_setup($dk) [expr {max(0.0,$slack)}]}
                            if {$kind eq "hold"} {set need [expr {max(0.0,-$slack)}]}
                        }
                    }
                }
                if {[info exists hb_setup($dk)]} {set head $hb_setup($dk)}
                if {$head ne "NA" && $need ne "NA"} {set comparison [expr {$need<=$head ? "WITHIN_SCALAR_HEADROOM_NOT_ROUTE_BUDGET" : "EXCEEDS_SCALAR_HEADROOM"}]}
                set requested $wanted_from; if {$scope eq "destination"} {set requested ALL_VALID_LAUNCHES}
                puts $hb_channel [join [list $index $scope $id $requested $wanted_to $sc $dc $kind $count $slack $cls $file $mf $mt $head $need $comparison] "\t"]
            }
        }
        flush $hb_channel

    }
    if {$index != $condition_count} {error "Not all available operating conditions were analyzed"}
} message options]
if {[info exists hb_channel]} {catch {close $hb_channel}}
foreach channel [list $inventory $coverage $global_summary $mode_coverage $row_coverage] {
    if {$channel ne ""} {catch {close $channel}}
}
if {$netlist} {catch {delete_timing_netlist}}
if {$opened} {catch {project_close -dont_export_assignments}}
if {$failed} {
    puts stderr $message
    if {[dict exists $options -errorinfo]} {puts stderr [dict get $options -errorinfo]}
    qexit -error
}
puts "SUPERBOND_SAVED_FIT_ALL_AVAILABLE_CORNERS_REPORTS_COMPLETE_NOT_TIMING_ACCEPTANCE"
qexit -success
