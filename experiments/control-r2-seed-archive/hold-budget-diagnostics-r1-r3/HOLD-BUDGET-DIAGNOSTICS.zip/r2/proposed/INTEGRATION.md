# R2 reporting-only singleton collection correction

Agent: /root/shienryu_constraints_review. R1 remains unchanged. Final snippet hold_budget.tcl SHA256 57202d38e2abd29dd4404569a9cb9ec7751c9abb49d516d469949b0bdd7e4c13.

R1 found all literal node identities but passed each foreach keeper node ID to get_collection_size. The documented argument is a collection, so every targeted query was skipped. R2 constructs a real collection with get_keepers, then requires exactly one member with the same original broad-scan node ID and canonical hierarchy name. Rebuild the broad scan after every condition/netlist update. Empty/multiple/identity mismatch remains unresolved and never invokes timing queries.

Installed bundled help documents get_keepers as returning a collection, with a Tcl-list wildcard filter; -no_duplicates excludes automatic replicas. escape_brackets escapes brackets and backslashes for literal string matching. use_timequest_style_escaping is On by default and automatically adds escaping for list/string matching. To avoid double-escaping ambiguity, hb_singleton turns it Off only around the caught get_keepers call and immediately restores On, including the lookup-error path. The parent QSF/SDC/Tcl has no escaping-mode override (root verified). This controls lookup text only: no timing constraint, clock, exception, source or report-path requirement changes.

The same 4 destination and 5 exact-pair specifications, 18 queries/corner, 144 TSV rows, 17-column header and outer hb_channel cleanup remain. Source P4 is VDP2 VRAMB1_A[8]_OTERM1383, not cart MEM_A[8]. Only get_node_info -name and get_path_info -slack getters are used; full native reports supply actual path identity/clocks/budgets. get_timing_paths receives no -detail option; report_timing uses -detail full_path.

Static validation only: Tcl info complete and all 9 canonical literal bracket patterns matched with standard Tcl list/string-match handling. No Quartus package, utility, project, snippet body or timing netlist was executed. Native collection acceptance and 144 finite, real paths remain qualification requirements; scalar comparisons are not guaranteed route budgets.

Primary evidence is installed25.1 bundled help (page metadata may describe an older help revision):

- C:\altera_lite\25.1std\quartus\common\help\webhelp\tafs\tafs\tcl_pkg_sdc_ext_ver_1.0_cmd_get_keepers.htm; SHA256 62fb604f2083a0d254d86fde29001bf595d0960ceda38856aa262481b9aafe60
- C:\altera_lite\25.1std\quartus\common\help\webhelp\tafs\tafs\tcl_pkg_misc_ver_1.0_cmd_get_collection_size.htm; SHA256 01641292ac8f0db2c8da7afaddcc70324cef3339b879d81aa9c7c85c090c95d1
- C:\altera_lite\25.1std\quartus\common\help\webhelp\tafs\tafs\tcl_pkg_misc_ver_1.0_cmd_escape_brackets.htm; SHA256 500cb69568e92a0530c58290764768127b6ccf8386e5a312e1462a71d07dbad7
- C:\altera_lite\25.1std\quartus\common\help\webhelp\tafs\tafs\tcl_pkg_sta_ver_1.0_cmd_use_timequest_style_escaping.htm; SHA256 29a7e6561a8299a8dd8f8fcbd1842c2de0eb35253dda8dd4828ecd939bbeb9f6
