# Reporting only; source after each condition's update_timing ($index,$out).
if {![info exists hb_channel]} {
    proc hb_key {n} {regsub -all {(^|\|)[^|:]+:} $n {\1} n; return $n}
    proc hb_finite {x} {if {![string is double -strict $x] || [catch {expr {abs($x)<1.0e100}} ok] || !$ok} {error "Nonfinite budget value: $x"}; return $x}
    proc hb_singleton {node key} {
        use_timequest_style_escaping -off
        set status [catch {get_keepers -no_duplicates -nowarn [list [escape_brackets $key]]} collection options]
        use_timequest_style_escaping -on
        if {$status} {return -options $options $collection}
        if {[get_collection_size $collection]!=1} {error "Exact keeper collection is not singleton: $key"}
        foreach_in_collection selected $collection {
            if {$selected ne $node || [hb_key [get_node_info -name $selected]] ne $key} {error "Exact keeper identity mismatch: $key"}
        }
        return $collection
    }
    set hb_channel [open [file join $out hold-budget.tsv] {WRONLY CREAT EXCL}]
    puts $hb_channel "corner\tquery_kind\ttarget_id\tsource_requested\tdestination_requested\tsource_matches\tdestination_matches\tcheck\treturned_path_count\tworst_slack_ns\tclassification\treport_file\tmatched_from\tmatched_to\tdestination_setup_headroom_ns\thold_delay_requirement_ns\tscalar_comparison"
    set hb_destinations [list {emu:emu|sdram1:sdram1|raddr23[1][15]} {emu:emu|sdram1:sdram1|raddr23[1][14]} {emu:emu|ddram:ddram|cart_rcache_addr[24]} {emu:emu|sdram1:sdram1|raddr23[1][8]}]
    set hb_sources [list {emu:emu|Saturn:saturn|VDP2:VDP2|VRAMB1_A[15]_OTERM1391} {emu:emu|Saturn:saturn|VDP2:VDP2|VRAMB1_A[14]_OTERM1417} {emu:emu|Saturn:saturn|STV_CART:cart|MEM_A[24]} {emu:emu|Saturn:saturn|VDP2:VDP2|VRAMB1_A[8]_OTERM1383} {emu:emu|Saturn:saturn|VDP2:VDP2|VRAMB1_A[14]_OTERM1419}]
}
# Never retain object IDs across a condition/netlist update.
array unset hb_hits
array set hb_hits {}
foreach n [concat $hb_destinations $hb_sources] {set hb_hits([hb_key $n]) {}}
foreach_in_collection n [get_keepers *] {
    set key [hb_key [get_node_info -name $n]]
    if {[info exists hb_hits($key)]} {lappend hb_hits($key) $n}
}
array unset hb_setup
array set hb_setup {}
set hb_queries {}
for {set i 0} {$i<4} {incr i} {lappend hb_queries [list destination D[expr {$i+1}] {} [lindex $hb_destinations $i]]}
for {set i 0} {$i<5} {incr i} {lappend hb_queries [list pair P[expr {$i+1}] [lindex $hb_sources $i] [lindex $hb_destinations [lindex {0 1 2 3 1} $i]]]}
foreach query $hb_queries {
    lassign $query scope id wanted_from wanted_to
    set dk [hb_key $wanted_to]; set dc [llength $hb_hits($dk)]; set sc ALL_FROM
    if {$scope eq "pair"} {set sk [hb_key $wanted_from]; set sc [llength $hb_hits($sk)]}
    foreach kind {setup hold} {
        set count 0; set slack NA; set cls UNRESOLVED_COLLECTION_REQUIRES_REVIEW; set file NA
        set mf NA; set mt NA; set head NA; set need NA; set comparison NO_BUDGET
        if {$dc==1 && ($scope eq "destination" || $sc==1)} {
            set dst_id [lindex $hb_hits($dk) 0]; set valid 1; set mf ALL_VALID_LAUNCHES; set mt [get_node_info -name $dst_id]
            if {[catch {set dst [hb_singleton $dst_id $dk]} issue]} {set valid 0; puts stderr "Budget $id $kind destination unresolved: $issue"}
            if {$scope eq "pair"} {
                set src_id [lindex $hb_hits($sk) 0]; set mf [get_node_info -name $src_id]
                if {[catch {set src [hb_singleton $src_id $sk]} issue]} {set valid 0; puts stderr "Budget $id $kind source unresolved: $issue"}
            }
            set cls SINGLETON_COLLECTION_IDENTITY_UNRESOLVED_REQUIRES_REVIEW
            if {$valid} {
                set args [list -$kind -to $dst -npaths 1]
                if {$scope eq "pair"} {lappend args -from $src}
                set paths [get_timing_paths {*}$args]; set count [get_collection_size $paths]; set cls NO_PATHS_REQUIRES_REVIEW
                if {$count>1} {error "Budget npaths1 returned multiple paths"}
                foreach_in_collection path $paths {
                    set slack [hb_finite [get_path_info -slack $path]]
                    set cls FINITE_SLACK_PATH_REQUIRES_NATIVE_REPORT_REVIEW
                    set file [format "corner-%02d-budget-%s-%s.rpt" $index $id $kind]
                    if {[file exists [file join $out $file]]} {error "Budget report already exists"}
                    report_timing {*}$args -detail full_path -file [file join $out $file]
                    if {$scope eq "destination" && $kind eq "setup"} {set hb_setup($dk) [expr {max(0.0,$slack)}]}
                    if {$kind eq "hold"} {set need [expr {max(0.0,-$slack)}]}
                }
            }
        }
        if {[info exists hb_setup($dk)]} {set head $hb_setup($dk)}
        if {$head ne "NA" && $need ne "NA"} {set comparison [expr {$need<=$head ? "WITHIN_SCALAR_HEADROOM_NOT_ROUTE_BUDGET" : "EXCEEDS_SCALAR_HEADROOM"}]}
        set requested $wanted_from; if {$scope eq "destination"} {set requested ALL_VALID_LAUNCHES}
        puts $hb_channel [join [list $index $scope $id $requested $wanted_to $sc $dc $kind $count $slack $cls $file $mf $mt $head $need $comparison] "\t"]
    }
}
flush $hb_channel
# Outer proven catch/cleanup must add: if {[info exists hb_channel]} {catch {close $hb_channel}}
