"""STA-only saved-fit budget diagnostic. Default validates static template only."""
import argparse,datetime as dt,hashlib,importlib.util,json,math,os,re,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
LAB=BASE.parents[2]
PARENT=BASE.parent/'row-predecessor-seed05-fit-sta-r1'
SOURCE='6eb9367e2d64c18b0b109d221a0bc07d35d493b4'
VARIANT='73ca65c64ef89e037e3995ca1faa56e3f7b8a1480b1a2f20190fb3d17b41ef57'
SEED=5
TASK='CoreLab-Shienryu-Seed05-HoldBudget-STA-Q251-R1'
PS='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
PYTHON=Path('C:/Users/djjoh/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
QUARTUS=Path('C:/altera_lite/25.1std/quartus')
GUARD_SHA='5d287472358720e99822c57a5b576508af60ef5c41db5131ffe2ea5b78ec04c9'
GIB=1024**3
LIMITS=dict(wall_seconds=None,cleanup_reserve_seconds=20,job_private_bytes=10*GIB,tree_rss_bytes=9*GIB,admission_free_commit_bytes=12*GIB,continuous_free_commit_floor_bytes=2*GIB)
PRIMARY='db/STV_DS.cmp.cdb'
BINARIES=['output_files/STV_DS.rbf','output_files/STV_DS.sof']
FILES=('diagnostic.py','checks.py','launch_task.py','quartus_job_guard.py','sta_all_corners.tcl','scheduler-action-inline.ps1','register-start-inline.ps1','PLAN.md','provenance.json','reuse-adapter.diff','local-validation.json','budget-spec.json')

def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def load(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')

def stamp():return dt.datetime.now(dt.timezone.utc).isoformat()

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def no_overlap():
    value=subprocess.check_output([PS,'-NoProfile','-NonInteractive','-Command',
        "$ErrorActionPreference='Stop'; @(Get-Process | Where-Object {$_.ProcessName -match '^quartus_'} | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],text=True).strip()
    assert not value or not json.loads(value),'Quartus active: no parent-tree access/copy or next stage'

def snapshot(tree):
    result={}
    for p in sorted(tree.rglob('*')):
        assert not p.is_symlink(),'Symlink forbidden'
        if p.is_file():result[p.relative_to(tree).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p))
    return result

def check_snapshot(tree,expected):assert snapshot(tree)==expected,'Immutable checkpoint changed: '+str(tree)

def safe_name(name):
    assert isinstance(name,str) and name and not Path(name).is_absolute() and '\\' not in name
    assert all(part not in ('','.','..') for part in name.split('/'));return name

def copy_checkpoint(parent,target,expected):
    no_overlap();check_snapshot(parent,expected)
    assert not target.exists(),'Never replay/overwrite a seed or stage'
    assert shutil.disk_usage(BASE).free>=sum(x['bytes'] for x in expected.values())+2*GIB,'Copy disk headroom below2GiB'
    target.mkdir(parents=True)
    for name,row in expected.items():
        safe_name(name);dst=target/name;dst.parent.mkdir(parents=True,exist_ok=True)
        with (parent/name).open('rb') as a,dst.open('xb') as b:shutil.copyfileobj(a,b)
        assert sha(dst)==row['sha256']
    check_snapshot(parent,expected);check_snapshot(target,expected)

def terminal(directory):
    r=load(directory/'result.json')
    assert r['state']=='terminal' and r['flow_exit_code']==0 and r['launcher_success'] and r['errors']==[]
    assert r['all_job_processes_terminal'] and r['all_handles_closed'] and r['final_job_active_processes']==0
    return r

def resources():
    g=module(BASE/'quartus_job_guard.py','batch_resource_guard');api=g.Windows();v=g.Performance(cb=g.C.sizeof(g.Performance))
    api.checked(api.p.GetPerformanceInfo(g.C.byref(v),v.cb),'GetPerformanceInfo')
    free=(v.limit-v.commit)*v.page;return dict(free_commit_bytes=free,admission_pass=free>=LIMITS['admission_free_commit_bytes'])

def native_summary(text):
    found=re.search(r'Report Timing: Found (\d+) (\w+) paths \((\d+) violated\)\.\s+Worst case slack is ([+\-0-9.]+)',text)
    assert found and int(found[1])>0 and int(found[3])>=0 and math.isfinite(float(found[4])),'Native timing summary missing'
    return dict(reported_paths=int(found[1]),check=found[2],violated=int(found[3]),display_slack_ns=float(found[4]))

def timing_and_targets(stage):
    checks=module(BASE/'checks.py','seed05_timing');q=checks.timing(stage,load(Path(load(BASE/'provenance.json')['coverage_reference_path'])))
    reports=stage/'reports';target=checks.rows(reports/'row-predecessor-check-coverage.tsv')
    assert len(target)==16 and {(int(r['corner']),r['check']) for r in target}=={(i,k) for i in range(1,9) for k in ('setup','hold')}
    for r in target:
        assert r['source_expression']=='ascal|o_vacpt_minus1*' and r['destination_expression']=='ascal|o_adrs_pre*'
        assert int(r['source_count'])>0 and int(r['destination_count'])>0 and r['returned_path_count']=='1'
        assert math.isfinite(float(r['worst_slack_ns'])) and r['classification']=='PATH_FOUND_REQUIRES_TIMING_REVIEW'
        assert r['report_file']==f"corner-{int(r['corner']):02d}-row-predecessor-{r['check']}.rpt"
    # Existing APIs write slack directly. Existing Python clean check did not inspect
    # report_timing's violation count; retain it so rounded0.000 cannot imply pass.
    diagnostics={};all_native_nonviolating=True
    groups=[(r,f"corner-{int(r['corner']):02d}-{r['check']}.rpt") for r in checks.rows(reports/'global-check-coverage.tsv')]
    groups += [(r,r['report_file']) for r in checks.rows(reports/'old-mode-check-coverage.tsv')+target]
    for r,name in groups:
        text=(reports/name).read_text(encoding='latin-1');d=native_summary(text)
        assert d['check']==r['check'] and abs(d['display_slack_ns']-float(r['worst_slack_ns']))<=0.00051
        diagnostics[name]=dict(**d,sha256=sha(reports/name));all_native_nonviolating &= d['violated']==0
        if 'row-predecessor' in name:
            for field,expression in (('From Node','o_vacpt_minus1'),('To Node','o_adrs_pre')):
                node=re.search(r'(?m)^;\s*'+field+r'\s*;\s*([^;\r\n]+)',text)
                assert node and expression in node[1],'Actual predecessor endpoint differs'
    for row in q['timing_condition_matrix']:
        co=row['native_corner']
        for k,v in row['checks'].items():
            d=diagnostics[f'corner-{co:02d}-{k}.rpt'];v['native_report_violated_paths']=d['violated'];v['pass'] &= d['violated']==0
        pw=row['minimum_pulse_width'];row['status']='PASS' if all(v['pass'] for v in row['checks'].values()) and pw['slack_ns']>=0 and pw['violated']==0 else 'FAIL'
    q['qualified_clean_candidate'] &= all_native_nonviolating and all(float(r['worst_slack_ns'])>=0 for r in target)
    q['row_predecessor_coverage']=dict(rows=target,all16_target_paths_present=True,no_empty_path_is_a_pass=True)
    q['native_timing_summary_diagnostics']=diagnostics;q['zero_display_with_native_violation_never_passes']=True
    return q

def template_pins():
    pins=load(BASE/'template-pins.json');assert set(pins)==set(FILES)
    for n,h in pins.items():assert sha(BASE/safe_name(n))==h,'Template changed: '+n
    assert sha(BASE/'quartus_job_guard.py')==sha(LAB/'scripts/quartus_job_guard.py')==GUARD_SHA
    for p,h in load(BASE/'provenance.json')['external_bound_files'].items():assert sha(Path(p))==h,'Reference changed: '+p
    return pins

def parent_proofs():
    e=load(PARENT/'experiment-result.json');assert e['source_commit']==SOURCE and e['seed']==SEED and e['BUILD_DATE']=='261025'
    assert e['state']=='COMPLETED_MEASUREMENT_REQUIRES_ROOT_REVIEW' and e['exit_code']==0
    assert sha(PARENT/'preservation-index.json')==e['preservation_index_sha256']
    for s in ('fit','asm','sta'):terminal(PARENT/'stages'/s)
    a=load(PARENT/'stages/asm/qualification.json');assert a['passed'] and a['fresh_RBF_and_SOF']
    c=load(PARENT/'terminal-task-cleanup.json')
    assert c['task_name']=='CoreLab-Shienryu-RowPredecessor-Seed05-FitASMSTA-Q251-R1'
    assert c['exact_registered_action_verified'] and c['exact_task_unregistered'] and c['last_task_result']==0
    assert c['all_job_processes_terminal'] and c['all_handles_closed'] and c['remaining_owned_or_quartus_processes']==[] and c['errors']==[]
    assert load(PARENT/'scheduler-action-exit.json')['exit_code']==0
    m=load(PARENT/'trial-manifest.json');assert m['source_commit']==SOURCE and m['seed']==SEED and m['variant_exact_sha256']==VARIANT
    return m

def admission(path,digest):
    assert Path(path).is_absolute() and re.fullmatch('[0-9a-f]{64}',digest or '') and sha(Path(path))==digest
    a=load(Path(path));assert a['reviewer']=='root' and a['decision']=='ACCEPTED_SEED05_READONLY_HOLD_BUDGET_DIAGNOSTIC'
    assert a['operation']=='STA_ONLY_HOLD_BUDGET' and a['source_commit']==SOURCE and a['seed']==SEED
    assert a['limits']==LIMITS and a['template_pins_sha256']==sha(BASE/'template-pins.json')
    assert a['parent_checkpoint_sha256']==sha(PARENT/'stages/asm/checkpoint.json')
    p=load(BASE/'provenance.json');assert a['parent_member_review_sha256']==p['external_bound_files'][p['parent_member_review_path']]
    assert a['analysis_only'] is True and a['followup_fit_requires_joint_decision'] is True
    assert a['timing_acceptance'] is False and a['hardware_acceptance'] is False
    parent_proofs();return a

def freeze(path,digest):
    template_pins();a=admission(path,digest);no_overlap()
    for n in ('diagnostic-manifest.json','parent-files.json','frozen-pins.json','stages','experiment-result.json'):
        assert not (BASE/n).exists(),'Occupied analysis: '+n
    original=load(PARENT/'stages/asm/checkpoint.json');assert len(original)==1051
    check_snapshot(PARENT/'stages/asm/tree',original)
    parent=parent_proofs();roles=parent['roles']
    assert len(roles['source_names'])==203 and len(roles['generated_names'])==2 and len(roles['map_database_names'])==4
    assert roles['primary_cmp_names']==[PRIMARY] and all(n in original for names in roles.values() for n in names)
    assert sha(PARENT/'stages/asm/tree/sys/ascal.vhd')==VARIANT
    assert (PARENT/'stages/asm/tree/build_id.v').read_bytes()==b'`define BUILD_DATE "261025"'
    tools={str(PYTHON),str(QUARTUS/'bin64/quartus_sta.exe')};assert set(a['tool_bindings'])==tools
    for p,h in a['tool_bindings'].items():assert sha(Path(p))==h
    save(BASE/'parent-files.json',original)
    save(BASE/'diagnostic-manifest.json',dict(operation='STA_ONLY_HOLD_BUDGET',source_commit=SOURCE,seed=SEED,BUILD_DATE='261025',
        parent_directory=str(PARENT/'stages/asm/tree'),parent_checkpoint_sha256=sha(PARENT/'stages/asm/checkpoint.json'),
        parent_files_sha256=sha(BASE/'parent-files.json'),roles=roles,tool_bindings=a['tool_bindings'],limits=LIMITS,
        root_admission=str(Path(path).resolve()),root_admission_sha256=digest,template_pins_sha256=sha(BASE/'template-pins.json'),
        analysis_only=True,manual_root_review=False))
    save(BASE/'frozen-pins.json',{**template_pins(),**{n:sha(BASE/n) for n in ('parent-files.json','diagnostic-manifest.json')}})
    return dict(state='FROZEN_NO_TREE_COPY_TASK_OR_STA',frozen_pins_sha256=sha(BASE/'frozen-pins.json'),root_frozen_review_still_required=True)

def validate():
    template_pins()
    for n,h in load(BASE/'frozen-pins.json').items():assert sha(BASE/n)==h
    m=load(BASE/'diagnostic-manifest.json');assert m['operation']=='STA_ONLY_HOLD_BUDGET' and m['source_commit']==SOURCE and m['seed']==SEED
    assert m['limits']==LIMITS and m['parent_checkpoint_sha256']==sha(PARENT/'stages/asm/checkpoint.json')
    assert m['parent_files_sha256']==sha(BASE/'parent-files.json')
    admission(m['root_admission'],m['root_admission_sha256'])
    for p,h in m['tool_bindings'].items():assert sha(Path(p))==h
    return m

def frozen_review(path,digest):
    assert Path(path).is_absolute() and re.fullmatch('[0-9a-f]{64}',digest or '') and sha(Path(path))==digest
    r=load(Path(path));assert r['reviewer']=='root' and r['decision']=='ACCEPTED_FROZEN_HOLD_BUDGET_STA_FOR_LAUNCH'
    assert r['task']==TASK and r['source_commit']==SOURCE and r['seed']==SEED and r['operation']=='STA_ONLY_HOLD_BUDGET'
    assert r['frozen_pins_sha256']==sha(BASE/'frozen-pins.json');return r

def guarded(stage,m):
    no_overlap();tree=stage/'tree';bound=sorted(set().union(*(set(v) for v in m['roles'].values()))|set(BINARIES))
    tcl=stage/'sta_all_corners.tcl'
    with tcl.open('xb') as f:f.write((BASE/'sta_all_corners.tcl').read_bytes())
    static={str((BASE/n).resolve()):h for n,h in load(BASE/'frozen-pins.json').items()}
    static.update(load(BASE/'provenance.json')['external_bound_files']);static.update(m['tool_bindings'])
    static[str(tcl.resolve())]=sha(tcl);static[m['root_admission']]=m['root_admission_sha256']
    launch=load(BASE/'launch-admission.json');static[launch['review_path']]=launch['review_sha256']
    static[str((BASE/'launch-admission.json').resolve())]=sha(BASE/'launch-admission.json')
    def inputs():return {**{n:sha(tree/n) for n in bound},**{p:sha(Path(p)) for p in static}}
    before=inputs();g=module(BASE/'quartus_job_guard.py','hold_budget_guard');exe=QUARTUS/'bin64/quartus_sta.exe';command=[str(exe),'-t',str(tcl)]
    g.LAB=LAB;g.BASE=stage;g.TREE=tree;g.BASELINE=SOURCE;g.QUARTUS=QUARTUS;g.EXE=exe
    g.COMMAND=command;g.RUN_KIND='seed05-readonly-hold-budget-STA-no-wall';g.LIMITS=dict(LIMITS);g.inputs=inputs
    save(stage/'stage-manifest.json',dict(operation='STA_ONLY_HOLD_BUDGET',source_commit=SOURCE,seed=SEED,command=command,
        limits=LIMITS,bound_inputs=before,tcl_sha256=sha(tcl),root_admission_sha256=m['root_admission_sha256'],manual_root_review=False))
    assert g.run(before)==0,'Guard/STA failure; no further native work'
    r=terminal(stage);no_overlap();after=inputs();changed={n for n in before if before[n]!=after[n]}
    assert changed<={'db/STV_DS.tiscmp.fastest_slow_1100mv_85c.ddb'},'Protected input mutation: '+repr(changed)
    assert all(sha(Path(p))==h for p,h in static.items());return r

def budget_coverage(stage):
    # TSV contract and exact query identities are supplied by the reporting-only proposal.
    spec=load(BASE/'budget-spec.json');rows=module(BASE/'checks.py','hold_budget_rows').rows(stage/'reports'/spec['coverage_file'])
    expected={(str(c),q['query_kind'],q['target_id'],k) for c in range(1,9) for q in spec['queries'] for k in ('setup','hold')}
    assert len(expected)==144 and len(rows)==144
    assert {(r['corner'],r['query_kind'],r['target_id'],r['check']) for r in rows}==expected
    checks=module(BASE/'checks.py','budget_native_clocks')
    known_clocks={r['clock'] for r in checks.rows(stage/'reports/clock-check-coverage.tsv')}
    identity={(q['query_kind'],q['target_id']):q for q in spec['queries']};unresolved=[];native={}
    for r in rows:
        q=identity[(r['query_kind'],r['target_id'])]
        assert r['source_requested']==q['source'] and r['destination_requested']==q['destination']
        matches=int(r['destination_matches'])==1 and (r['query_kind']=='destination' or int(r['source_matches'])==1)
        if not matches or int(r['returned_path_count'])==0:
            assert r['worst_slack_ns']=='NA' and r['report_file']=='NA'
            assert r['classification'] in ('UNRESOLVED_COLLECTION_REQUIRES_REVIEW','SINGLETON_OBJECT_UNRESOLVED_REQUIRES_REVIEW','NO_PATHS_REQUIRES_REVIEW')
            unresolved.append(r);continue
        assert r['returned_path_count']=='1' and math.isfinite(float(r['worst_slack_ns'])) and r['classification']=='FINITE_SLACK_PATH_REQUIRES_NATIVE_REPORT_REVIEW'
        assert r['report_file']==f"corner-{int(r['corner']):02d}-budget-{r['target_id']}-{r['check']}.rpt"
        name=safe_name(r['report_file']);report=stage/'reports'/name;text=report.read_text(encoding='latin-1');d=native_summary(text)
        assert d['check']==r['check'] and abs(d['display_slack_ns']-float(r['worst_slack_ns']))<=0.00051
        def field(key):
            match=re.search(r'(?m)^;\s*'+re.escape(key)+r'\s*;\s*([^;\r\n]+)',text)
            assert match,'Missing actual native budget field: '+key
            return match[1].strip()
        def canonical(node):return '|'.join(part.split(':')[-1] for part in node.split('|'))
        actual_from=field('From Node');actual_to=field('To Node')
        assert canonical(actual_to)==canonical(r['matched_to'])==canonical(q['destination'])
        if r['query_kind']=='pair':assert canonical(actual_from)==canonical(r['matched_from'])==canonical(q['source'])
        launch=field('Launch Clock');latch=field('Latch Clock');assert launch in known_clocks and latch in known_clocks,'Target path lacks actual known clocks'
        values={key:float(field(label)) for key,label in [('arrival_ns','Data Arrival Time'),('required_ns','Data Required Time'),
            ('relationship_ns',r['check'].title()+' Relationship'),('clock_skew_ns','Clock Skew'),('data_delay_ns','Data Delay')]}
        assert all(math.isfinite(v) for v in values.values()),'NA/nonfinite native timing budget'
        calculated=values['required_ns']-values['arrival_ns'] if r['check']=='setup' else values['arrival_ns']-values['required_ns']
        assert abs(calculated-d['display_slack_ns'])<=0.0021,'Native arrival/required/slack inconsistent beyond display rounding'
        native[name]=dict(**d,**values,actual_from=actual_from,actual_to=actual_to,launch_clock=launch,latch_clock=latch,sha256=sha(report))
    setup={(r['corner'],r['destination_requested']):max(0.0,float(r['worst_slack_ns'])) for r in rows
        if r['query_kind']=='destination' and r['check']=='setup' and r['worst_slack_ns']!='NA'}
    for r in rows:
        head=r['destination_setup_headroom_ns'];need=r['hold_delay_requirement_ns'];key=(r['corner'],r['destination_requested'])
        if head!='NA':assert key in setup and math.isfinite(float(head)) and abs(float(head)-setup[key])<=1e-8
        if need!='NA':assert r['check']=='hold' and r['worst_slack_ns']!='NA' and abs(float(need)-max(0.0,-float(r['worst_slack_ns'])))<=1e-8
        expected='NO_BUDGET' if head=='NA' or need=='NA' else ('WITHIN_SCALAR_HEADROOM_NOT_ROUTE_BUDGET' if float(need)<=float(head) else 'EXCEEDS_SCALAR_HEADROOM')
        assert r['scalar_comparison']==expected,'Budget scalar label differs from recorded values'
    return dict(rows=rows,expected_rows=144,actual_rows=len(rows),all_targets_unique_and_timed=not unresolved,
        unresolved_rows=unresolved,native_report_diagnostics=native,NA_or_unresolved_is_never_a_pass=True,
        interpretation='Read-only timing budgets, not a fitter action, repair decision, timing acceptance or hardware result.')

def run():
    m=validate();launch=load(BASE/'launch-admission.json');frozen_review(launch['review_path'],launch['review_sha256'])
    a=load(BASE/'scheduler-action-start.json');assert a['pid']==os.getppid() and a['parent_name'].lower() in ('svchost.exe','taskeng.exe')
    assert not (BASE/'stages').exists() and not (BASE/'experiment-result.json').exists(),'No automatic retry/resume'
    original=load(BASE/'parent-files.json');summary=dict(state='RUNNING_READONLY_STA_DIAGNOSTIC',operation='STA_ONLY_HOLD_BUDGET',
        source_commit=SOURCE,seed=SEED,BUILD_DATE='261025',root_admission_sha256=m['root_admission_sha256'],
        analysis_only=True,timing_acceptance=False,hardware_acceptance=False,followup_fit_requires_joint_decision=True,task_cleanup_pending=True)
    code=1
    try:
        stage=BASE/'stages/sta';copy_checkpoint(PARENT/'stages/asm/tree',stage/'tree',original);(stage/'reports').mkdir()
        r=guarded(stage,m);after=snapshot(stage/'tree');prov=load(BASE/'provenance.json')
        changed={n for n in original if after.get(n)!=original[n]};added=set(after)-set(original);deleted=set(original)-set(after)
        assert not deleted and changed<=set(prov['established_STA_cache_changes']) and added<=set(prov['established_STA_cache_additions']), 'Unreviewed working-tree cache mutation'
        protected=set().union(*(set(m['roles'][k]) for k in ('source_names','generated_names','map_database_names','primary_cmp_names')))|set(BINARIES)
        assert all(after[n]==original[n] for n in protected),'Source/map/CMP/programming output changed'
        check_snapshot(PARENT/'stages/asm/tree',original)
        log=(stage/'fullflow.log').read_text(encoding='utf-8',errors='replace');modules=re.findall(r'Info: Running Quartus Prime ([^\r\n]+)',log)
        assert modules==['Timing Analyzer'],'STA-only module qualification failed: '+repr(modules)
        full=timing_and_targets(stage);budget=budget_coverage(stage)
        save(stage/'qualification.json',dict(analysis_only=True,full_coverage=full,budget=budget,native_modules=modules,
            working_cache_changed=sorted(changed),working_cache_added=sorted(added),working_deleted=[],manual_root_review=False))
        summary.update(state='COMPLETED_BUDGET_DIAGNOSTIC_REQUIRES_JOINT_REVIEW' if budget['all_targets_unique_and_timed'] else 'COMPLETED_DIAGNOSTIC_TARGET_MATCH_REVIEW_REQUIRED',
            diagnostic_complete=budget['all_targets_unique_and_timed'],budget=budget,timing_condition_matrix=full['timing_condition_matrix'],coverage=full['coverage'],
            working_cache_changed=sorted(changed),working_cache_added=sorted(added),native_modules=modules)
        code=0
    except Exception as error:summary.update(state='STOPPED_DIAGNOSTIC_INFRASTRUCTURE_OR_INTEGRITY_REVIEW_REQUIRED',error=repr(error),resource_stop_is_inconclusive_not_timing_failure=True)
    finally:
        try:
            no_overlap()
            for p in (BASE/'stages').glob('*/result.json'):
                r=load(p)
                if r.get('state')=='deferred-before-launch' and r.get('no_child_launched') is True:continue
                assert r['state']=='terminal' and r['all_job_processes_terminal'] and r['all_handles_closed'] and r['final_job_active_processes']==0
            check_snapshot(PARENT/'stages/asm/tree',original)
            save(BASE/'preservation-index.json',dict(members=snapshot(BASE/'stages'),operation='STA_ONLY_HOLD_BUDGET',source_commit=SOURCE,seed=SEED,
                root_admission_sha256=m['root_admission_sha256'],limits=LIMITS,tool_bindings=m['tool_bindings'],manual_root_review=False))
            summary['preservation_index_sha256']=sha(BASE/'preservation-index.json')
        except Exception as error:summary['preservation_pending_safe_terminal_proof']=repr(error);code=1
        summary.update(exit_code=code,ended_utc=stamp());save(BASE/'experiment-result.json',summary)
    return code

def main():
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group();g.add_argument('--freeze');g.add_argument('--run',action='store_true');p.add_argument('--admission-sha256');a=p.parse_args()
    assert Path(sys.executable).resolve()==PYTHON.resolve()
    if a.freeze:print(json.dumps(freeze(a.freeze,a.admission_sha256),indent=2));return 0
    if a.run:return run()
    template_pins();print(json.dumps(dict(state='UNFROZEN_STA_ONLY_TEMPLATE_NO_PARENT_DB_READ_COPY_TASK_OR_NATIVE',operation='STA_ONLY_HOLD_BUDGET',
        source_commit=SOURCE,seed=SEED,expected_budget_rows=144,limits=LIMITS,template_pins_sha256=sha(BASE/'template-pins.json')),indent=2));return 0

if __name__=='__main__':raise SystemExit(main())
